import { useEffect, useState, useMemo } from 'react';
import { BrowserRouter, Routes, Route, useSearchParams } from 'react-router-dom';
import { Navbar } from '@/components/Navbar';
import { HeroSection } from '@/components/HeroSection';
import { TrustBadge } from '@/components/TrustBadge';
import { CategoryFilter } from '@/components/CategoryFilter';
import { ProductCard } from '@/components/ProductCard';
import { ProductModal } from '@/components/ProductModal';
import { Footer } from '@/components/Footer';
import { TrustUXPlaybook } from '@/components/TrustUXPlaybook';
import { Toast } from '@/components/Toast';
import { products, Product } from '@/data/products';
import { AppProvider } from '@/context/AppContext';

// Pages
import { LoginPage } from '@/pages/LoginPage';
import { CartPage } from '@/pages/CartPage';
import { CheckoutPage } from '@/pages/CheckoutPage';
import { ProductPage } from '@/pages/ProductPage';
import { OrdersPage } from '@/pages/OrdersPage';
import { SellerDashboard } from '@/pages/SellerDashboard';
import { AdminPanel } from '@/pages/AdminPanel';
import { SettingsPage } from '@/pages/SettingsPage';
import { ChatPage } from '@/pages/ChatPage';
import { ChatWidget } from '@/components/ChatWidget';

function HomePage() {
  const [searchParams] = useSearchParams();
  const modeParam = searchParams.get('mode');
  
  const [currentMode, setCurrentMode] = useState<'new' | 'secondHand'>(
    modeParam === 'secondHand' ? 'secondHand' : 'new'
  );
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isPlaybookOpen, setIsPlaybookOpen] = useState(false);

  // Update mode when URL changes
  useEffect(() => {
    if (modeParam === 'secondHand') {
      setCurrentMode('secondHand');
    } else if (modeParam === 'new') {
      setCurrentMode('new');
    }
  }, [modeParam]);

  // Filter products based on mode, category, and search
  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      // Filter by mode
      if (currentMode === 'new' && product.isSecondHand) return false;
      if (currentMode === 'secondHand' && !product.isSecondHand) return false;

      // Filter by category
      if (selectedCategory && product.category !== selectedCategory) return false;

      // Filter by search
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        return (
          product.name.toLowerCase().includes(query) ||
          product.description.toLowerCase().includes(query) ||
          product.seller.toLowerCase().includes(query) ||
          product.location.toLowerCase().includes(query) ||
          product.category.toLowerCase().includes(query)
        );
      }

      return true;
    });
  }, [currentMode, selectedCategory, searchQuery]);

  // Featured products (for new mode)
  const featuredProducts = useMemo(() => {
    return products.filter(p => p.isFeatured && !p.isSecondHand);
  }, []);

  const handleProductClick = (product: Product) => {
    setSelectedProduct(product);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setTimeout(() => setSelectedProduct(null), 300);
  };

  useEffect(() => {
    const handler = () => setIsPlaybookOpen(true);
    window.addEventListener('bazaarco:open-trust-playbook', handler as EventListener);
    return () => window.removeEventListener('bazaarco:open-trust-playbook', handler as EventListener);
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="sticky top-0 z-50">
        <Navbar />
      </div>
      
      <HeroSection 
        onSearch={setSearchQuery}
        onModeChange={setCurrentMode}
        currentMode={currentMode}
      />

      <TrustBadge />

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Featured Section (only for new market) */}
        {currentMode === 'new' && featuredProducts.length > 0 && !selectedCategory && !searchQuery && (
          <section className="mb-10">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
                <span className="text-3xl">✨</span> Featured Products
              </h2>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {featuredProducts.map((product) => (
                <ProductCard 
                  key={product.id} 
                  product={product} 
                  onProductClick={handleProductClick}
                />
              ))}
            </div>
          </section>
        )}

        {/* Category Filter */}
        <CategoryFilter
          mode={currentMode}
          selectedCategory={selectedCategory}
          onSelectCategory={setSelectedCategory}
        />

        {/* Search Results Info */}
        {(searchQuery || selectedCategory) && (
          <div className="mb-4 flex items-center justify-between">
            <p className="text-gray-600">
              Showing {filteredProducts.length} product{filteredProducts.length !== 1 ? 's' : ''}
              {searchQuery && ` for "${searchQuery}"`}
              {selectedCategory && ` in ${selectedCategory.replace('-', ' ')}`}
            </p>
            {(searchQuery || selectedCategory) && (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory(null);
                }}
                className="text-red-600 hover:text-red-700 font-medium text-sm"
              >
                Clear Filters
              </button>
            )}
          </div>
        )}

        {/* Products Grid */}
        <section>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {filteredProducts.map((product) => (
              <ProductCard 
                key={product.id} 
                product={product} 
                onProductClick={handleProductClick}
              />
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="text-center py-16">
              <div className="text-6xl mb-4">🔍</div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">No products found</h3>
              <p className="text-gray-500">
                Try adjusting your search or filter criteria
              </p>
            </div>
          )}
        </section>

        {/* Call to Action */}
        <section className="mt-12 bg-gradient-to-r from-red-600 to-blue-600 rounded-2xl p-8 text-white text-center">
          <h2 className="text-2xl md:text-3xl font-bold mb-4">
            {currentMode === 'new' 
              ? 'Want to Sell Your Products?' 
              : 'Have Items to Sell?'}
          </h2>
          <p className="text-white/80 mb-6 max-w-2xl mx-auto">
            Join thousands of sellers across Nepal. List your products today and reach customers nationwide with BazaarCo's trusted platform.
          </p>
          <div className="flex justify-center gap-3 flex-wrap">
            <a href="/login" className="bg-white text-red-600 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
              Start Selling
            </a>
            <button 
              onClick={() => setIsPlaybookOpen(true)}
              className="bg-white/20 text-white px-6 py-3 rounded-lg font-semibold hover:bg-white/30 transition-colors"
            >
              Learn More
            </button>
          </div>
        </section>
      </main>

      <Footer />

      {/* Product Modal */}
      {isModalOpen && (
        <ProductModal product={selectedProduct} onClose={handleCloseModal} />
      )}

      {/* Trust UX Playbook */}
      {isPlaybookOpen && (
        <TrustUXPlaybook onClose={() => setIsPlaybookOpen(false)} />
      )}
    </div>
  );
}

function AppContent() {
  return (
    <>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/cart" element={<CartPage />} />
        <Route path="/checkout" element={<CheckoutPage />} />
        <Route path="/product/:id" element={<ProductPage />} />
        <Route path="/orders" element={<OrdersPage />} />
        <Route path="/seller/dashboard" element={<SellerDashboard />} />
        <Route path="/admin" element={<AdminPanel />} />
        <Route path="/settings" element={<SettingsPage />} />
        <Route path="/messages" element={<ChatPage />} />
      </Routes>
      <Toast />
      <ChatWidget />
    </>
  );
}

export function App() {
  return (
    <BrowserRouter>
      <AppProvider>
        <AppContent />
      </AppProvider>
    </BrowserRouter>
  );
}
