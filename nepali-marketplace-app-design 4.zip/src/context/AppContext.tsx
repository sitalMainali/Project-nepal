import { createContext, useContext, useReducer, useEffect, ReactNode } from 'react';
import { Product } from '@/data/products';

// Types
export interface User {
  id: string;
  email: string;
  name: string;
  phone: string;
  type: 'customer' | 'seller' | 'admin';
  avatar?: string;
  isVerified: boolean;
  createdAt: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedSize?: string;
  selectedColor?: string;
}

export interface WishlistItem {
  productId: string;
  addedAt: string;
}

export interface Order {
  id: string;
  items: CartItem[];
  status: 'pending' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled' | 'disputed';
  total: number;
  shippingAddress: ShippingAddress;
  paymentMethod: string;
  createdAt: string;
  updatedAt: string;
  trackingNumber?: string;
  estimatedDelivery?: string;
}

export interface ShippingAddress {
  fullName: string;
  phone: string;
  email: string;
  address: string;
  city: string;
  landmark?: string;
  instructions?: string;
}

export interface Notification {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
}

interface AppState {
  user: User | null;
  cart: CartItem[];
  wishlist: WishlistItem[];
  orders: Order[];
  notifications: Notification[];
  isLoading: boolean;
  searchQuery: string;
  recentSearches: string[];
}

type AppAction =
  | { type: 'SET_USER'; payload: User | null }
  | { type: 'ADD_TO_CART'; payload: CartItem }
  | { type: 'REMOVE_FROM_CART'; payload: string }
  | { type: 'UPDATE_CART_QUANTITY'; payload: { productId: string; quantity: number } }
  | { type: 'CLEAR_CART' }
  | { type: 'ADD_TO_WISHLIST'; payload: string }
  | { type: 'REMOVE_FROM_WISHLIST'; payload: string }
  | { type: 'ADD_ORDER'; payload: Order }
  | { type: 'UPDATE_ORDER_STATUS'; payload: { orderId: string; status: Order['status'] } }
  | { type: 'ADD_NOTIFICATION'; payload: Notification }
  | { type: 'MARK_NOTIFICATION_READ'; payload: string }
  | { type: 'CLEAR_NOTIFICATIONS' }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_SEARCH_QUERY'; payload: string }
  | { type: 'ADD_RECENT_SEARCH'; payload: string }
  | { type: 'LOAD_STATE'; payload: Partial<AppState> };

const initialState: AppState = {
  user: null,
  cart: [],
  wishlist: [],
  orders: [],
  notifications: [],
  isLoading: false,
  searchQuery: '',
  recentSearches: [],
};

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'SET_USER':
      return { ...state, user: action.payload };

    case 'ADD_TO_CART': {
      const existingIndex = state.cart.findIndex(
        item => item.product.id === action.payload.product.id
      );
      if (existingIndex >= 0) {
        const newCart = [...state.cart];
        newCart[existingIndex].quantity += action.payload.quantity;
        return { ...state, cart: newCart };
      }
      return { ...state, cart: [...state.cart, action.payload] };
    }

    case 'REMOVE_FROM_CART':
      return {
        ...state,
        cart: state.cart.filter(item => item.product.id !== action.payload),
      };

    case 'UPDATE_CART_QUANTITY':
      return {
        ...state,
        cart: state.cart.map(item =>
          item.product.id === action.payload.productId
            ? { ...item, quantity: action.payload.quantity }
            : item
        ),
      };

    case 'CLEAR_CART':
      return { ...state, cart: [] };

    case 'ADD_TO_WISHLIST':
      if (state.wishlist.some(item => item.productId === action.payload)) {
        return state;
      }
      return {
        ...state,
        wishlist: [
          ...state.wishlist,
          { productId: action.payload, addedAt: new Date().toISOString() },
        ],
      };

    case 'REMOVE_FROM_WISHLIST':
      return {
        ...state,
        wishlist: state.wishlist.filter(item => item.productId !== action.payload),
      };

    case 'ADD_ORDER':
      return { ...state, orders: [action.payload, ...state.orders] };

    case 'UPDATE_ORDER_STATUS':
      return {
        ...state,
        orders: state.orders.map(order =>
          order.id === action.payload.orderId
            ? { ...order, status: action.payload.status, updatedAt: new Date().toISOString() }
            : order
        ),
      };

    case 'ADD_NOTIFICATION':
      return { ...state, notifications: [action.payload, ...state.notifications] };

    case 'MARK_NOTIFICATION_READ':
      return {
        ...state,
        notifications: state.notifications.map(n =>
          n.id === action.payload ? { ...n, read: true } : n
        ),
      };

    case 'CLEAR_NOTIFICATIONS':
      return { ...state, notifications: [] };

    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };

    case 'SET_SEARCH_QUERY':
      return { ...state, searchQuery: action.payload };

    case 'ADD_RECENT_SEARCH':
      const searches = [action.payload, ...state.recentSearches.filter(s => s !== action.payload)].slice(0, 5);
      return { ...state, recentSearches: searches };

    case 'LOAD_STATE':
      return { ...state, ...action.payload };

    default:
      return state;
  }
}

interface AppContextType {
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
  // Helper functions
  addToCart: (product: Product, quantity?: number, size?: string, color?: string) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  getCartTotal: () => number;
  getCartCount: () => number;
  toggleWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;
  login: (user: User) => void;
  logout: () => void;
  placeOrder: (shippingAddress: ShippingAddress, paymentMethod: string) => Order;
  addNotification: (type: Notification['type'], title: string, message: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEY = 'bazaarco_state';

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  // Load state from localStorage on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        dispatch({ type: 'LOAD_STATE', payload: parsed });
      }
    } catch (e) {
      console.error('Failed to load state:', e);
    }
  }, []);

  // Save state to localStorage on changes
  useEffect(() => {
    try {
      const toSave = {
        user: state.user,
        cart: state.cart,
        wishlist: state.wishlist,
        orders: state.orders,
        recentSearches: state.recentSearches,
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(toSave));
    } catch (e) {
      console.error('Failed to save state:', e);
    }
  }, [state.user, state.cart, state.wishlist, state.orders, state.recentSearches]);

  // Helper functions
  const addToCart = (product: Product, quantity = 1, size?: string, color?: string) => {
    dispatch({
      type: 'ADD_TO_CART',
      payload: { product, quantity, selectedSize: size, selectedColor: color },
    });
    addNotification('success', 'Added to Cart', `${product.name} has been added to your cart.`);
  };

  const removeFromCart = (productId: string) => {
    dispatch({ type: 'REMOVE_FROM_CART', payload: productId });
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
    } else {
      dispatch({ type: 'UPDATE_CART_QUANTITY', payload: { productId, quantity } });
    }
  };

  const clearCart = () => {
    dispatch({ type: 'CLEAR_CART' });
  };

  const getCartTotal = () => {
    return state.cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  };

  const getCartCount = () => {
    return state.cart.reduce((sum, item) => sum + item.quantity, 0);
  };

  const toggleWishlist = (productId: string) => {
    if (state.wishlist.some(item => item.productId === productId)) {
      dispatch({ type: 'REMOVE_FROM_WISHLIST', payload: productId });
      addNotification('info', 'Removed from Wishlist', 'Item removed from your wishlist.');
    } else {
      dispatch({ type: 'ADD_TO_WISHLIST', payload: productId });
      addNotification('success', 'Added to Wishlist', 'Item added to your wishlist.');
    }
  };

  const isInWishlist = (productId: string) => {
    return state.wishlist.some(item => item.productId === productId);
  };

  const login = (user: User) => {
    dispatch({ type: 'SET_USER', payload: user });
    addNotification('success', 'Welcome!', `You are now logged in as ${user.name}.`);
  };

  const logout = () => {
    dispatch({ type: 'SET_USER', payload: null });
    addNotification('info', 'Logged Out', 'You have been logged out successfully.');
  };

  const placeOrder = (shippingAddress: ShippingAddress, paymentMethod: string): Order => {
    const order: Order = {
      id: `BZC-${Date.now().toString().slice(-6)}`,
      items: [...state.cart],
      status: 'pending',
      total: getCartTotal(),
      shippingAddress,
      paymentMethod,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      estimatedDelivery: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString(),
    };
    dispatch({ type: 'ADD_ORDER', payload: order });
    dispatch({ type: 'CLEAR_CART' });
    addNotification('success', 'Order Placed!', `Your order ${order.id} has been placed successfully.`);
    return order;
  };

  const addNotification = (type: Notification['type'], title: string, message: string) => {
    const notification: Notification = {
      id: `notif-${Date.now()}`,
      type,
      title,
      message,
      timestamp: new Date().toISOString(),
      read: false,
    };
    dispatch({ type: 'ADD_NOTIFICATION', payload: notification });
  };

  return (
    <AppContext.Provider
      value={{
        state,
        dispatch,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        getCartTotal,
        getCartCount,
        toggleWishlist,
        isInWishlist,
        login,
        logout,
        placeOrder,
        addNotification,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
