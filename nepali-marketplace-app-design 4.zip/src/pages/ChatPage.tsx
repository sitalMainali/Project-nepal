import { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import {
  MessageCircle, Send, ArrowLeft, Image, Shield, Phone,
  ChevronRight, Search, CheckCircle2
} from 'lucide-react';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { ChatService, type Conversation, type ChatMessage } from '@/services/api';
import { useApp } from '@/context/AppContext';

export function ChatPage() {
  const { state } = useApp();
  const user = state.user;
  const role: 'buyer' | 'seller' = user?.type === 'seller' ? 'seller' : 'buyer';
  const userId = user?.id || 'guest';

  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConv, setActiveConv] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (user) {
      const convs = user.type === 'seller'
        ? ChatService.getAllConversations()
        : ChatService.getConversations(userId, role);
      setConversations(convs);
    }
  }, [user, userId, role]);

  useEffect(() => {
    if (activeConv) {
      const msgs = ChatService.getMessages(activeConv);
      setMessages(msgs);
      ChatService.markRead(activeConv, role);
      setConversations(prev => prev.map(c =>
        c.id === activeConv ? { ...c, [role === 'buyer' ? 'unreadBuyer' : 'unreadSeller']: 0 } : c
      ));
      inputRef.current?.focus();
    }
  }, [activeConv, role]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = () => {
    if (!newMessage.trim() || !activeConv || !user) return;
    const msg = ChatService.sendMessage(activeConv, user.id, user.name, role, newMessage.trim());
    setMessages(prev => [...prev, msg]);
    setConversations(prev => prev.map(c =>
      c.id === activeConv ? { ...c, lastMessage: newMessage.trim(), lastMessageTime: msg.timestamp } : c
    ));
    setNewMessage('');
    inputRef.current?.focus();
  };

  const activeConversation = conversations.find(c => c.id === activeConv);
  const filteredConversations = searchQuery
    ? conversations.filter(c => {
        const name = role === 'buyer' ? c.sellerName : c.buyerName;
        return name.toLowerCase().includes(searchQuery.toLowerCase()) ||
               (c.productName || '').toLowerCase().includes(searchQuery.toLowerCase());
      })
    : conversations;

  const formatTime = (ts: string) => {
    const d = new Date(ts);
    const now = new Date();
    const diff = Math.floor((now.getTime() - d.getTime()) / 60000);
    if (diff < 1) return 'Just now';
    if (diff < 60) return `${diff}m ago`;
    const diffHrs = Math.floor(diff / 60);
    if (diffHrs < 24) return `${diffHrs}h ago`;
    return d.toLocaleDateString();
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="max-w-2xl mx-auto px-4 py-16 text-center">
          <MessageCircle className="w-16 h-16 mx-auto text-gray-300 mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Login to access messages</h1>
          <p className="text-gray-600 mb-6">You need to be logged in to chat with sellers.</p>
          <Link to="/login" className="inline-flex items-center gap-2 bg-red-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-red-700">
            Login <ChevronRight size={18} />
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navbar />
      <div className="flex-1 max-w-6xl mx-auto w-full px-4 py-6">
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden" style={{ height: 'calc(100vh - 180px)', minHeight: '500px' }}>
          <div className="flex h-full">
            {/* Sidebar */}
            <div className={`w-full md:w-80 border-r border-gray-200 flex flex-col ${activeConv ? 'hidden md:flex' : 'flex'}`}>
              <div className="p-4 border-b border-gray-100">
                <h2 className="font-bold text-gray-900 text-lg mb-3">Messages</h2>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input type="text" value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
                    placeholder="Search conversations..." className="w-full pl-9 pr-4 py-2 bg-gray-100 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-red-500" />
                </div>
              </div>
              <div className="flex-1 overflow-y-auto divide-y divide-gray-100">
                {filteredConversations.length === 0 ? (
                  <div className="p-8 text-center text-gray-500">
                    <MessageCircle className="w-10 h-10 mx-auto mb-2 text-gray-300" />
                    <p>No conversations yet</p>
                  </div>
                ) : (
                  filteredConversations.map(conv => {
                    const unread = role === 'buyer' ? conv.unreadBuyer : conv.unreadSeller;
                    const otherName = role === 'buyer' ? conv.sellerName : conv.buyerName;
                    return (
                      <button key={conv.id} onClick={() => setActiveConv(conv.id)}
                        className={`w-full p-4 flex gap-3 hover:bg-gray-50 transition-colors text-left ${activeConv === conv.id ? 'bg-red-50' : ''}`}>
                        <div className="w-10 h-10 bg-gradient-to-br from-red-400 to-red-500 rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
                          {otherName.charAt(0)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <span className="font-medium text-gray-900 text-sm">{otherName}</span>
                            <span className="text-xs text-gray-400">{formatTime(conv.lastMessageTime)}</span>
                          </div>
                          {conv.productName && <p className="text-xs text-blue-600 truncate">Re: {conv.productName}</p>}
                          <p className={`text-sm truncate mt-0.5 ${unread > 0 ? 'text-gray-900 font-medium' : 'text-gray-500'}`}>{conv.lastMessage}</p>
                        </div>
                        {unread > 0 && <span className="w-5 h-5 bg-red-600 text-white text-xs rounded-full flex items-center justify-center font-medium flex-shrink-0 self-center">{unread}</span>}
                      </button>
                    );
                  })
                )}
              </div>
            </div>

            {/* Chat Area */}
            <div className={`flex-1 flex flex-col ${!activeConv ? 'hidden md:flex' : 'flex'}`}>
              {!activeConv ? (
                <div className="flex-1 flex items-center justify-center text-gray-500">
                  <div className="text-center">
                    <MessageCircle className="w-16 h-16 mx-auto mb-3 text-gray-300" />
                    <p className="font-medium text-gray-600">Select a conversation</p>
                    <p className="text-sm">Choose from your existing chats or start a new one from a product page.</p>
                  </div>
                </div>
              ) : (
                <>
                  {/* Chat Header */}
                  <div className="p-4 border-b border-gray-200 flex items-center gap-3 bg-white">
                    <button onClick={() => setActiveConv(null)} className="md:hidden p-1 hover:bg-gray-100 rounded-full">
                      <ArrowLeft size={20} />
                    </button>
                    <div className="w-10 h-10 bg-gradient-to-br from-red-400 to-red-500 rounded-full flex items-center justify-center text-white font-bold">
                      {(role === 'buyer' ? activeConversation?.sellerName : activeConversation?.buyerName)?.charAt(0)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-gray-900 truncate">
                        {role === 'buyer' ? activeConversation?.sellerName : activeConversation?.buyerName}
                      </p>
                      <div className="flex items-center gap-2">
                        {activeConversation?.productName && (
                          <p className="text-xs text-blue-600 truncate">Re: {activeConversation.productName}</p>
                        )}
                        {activeConversation?.orderId && (
                          <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded">{activeConversation.orderId}</span>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="flex items-center gap-1 text-xs text-green-600"><CheckCircle2 size={12} /> Verified</span>
                      <button className="p-2 hover:bg-gray-100 rounded-full"><Phone size={18} className="text-gray-500" /></button>
                    </div>
                  </div>

                  {/* Trust Banner */}
                  <div className="bg-green-50 px-4 py-2 text-xs text-green-800 flex items-center gap-2 border-b border-green-100">
                    <Shield size={12} className="text-green-600" />
                    All chats are monitored. Never share payment details. Use BazaarCo checkout for protection.
                  </div>

                  {/* Messages */}
                  <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gray-50">
                    {messages.map(msg => {
                      const isMe = msg.senderId === user.id;
                      const isSystem = msg.senderType === 'system';
                      if (isSystem) {
                        return (
                          <div key={msg.id} className="text-center my-4">
                            <div className="inline-block bg-amber-100 border border-amber-200 rounded-lg px-4 py-2 text-xs text-amber-800 max-w-sm">
                              {msg.message}
                            </div>
                          </div>
                        );
                      }
                      return (
                        <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                          <div className={`max-w-[70%] rounded-2xl px-4 py-3 shadow-sm ${
                            isMe ? 'bg-red-600 text-white rounded-br-md' : 'bg-white text-gray-900 rounded-bl-md border border-gray-100'
                          }`}>
                            {!isMe && <p className="text-xs font-medium mb-1 text-gray-500">{msg.senderName}</p>}
                            <p className="text-sm leading-relaxed">{msg.message}</p>
                            <p className={`text-xs mt-1.5 ${isMe ? 'text-white/60' : 'text-gray-400'}`}>{formatTime(msg.timestamp)}</p>
                          </div>
                        </div>
                      );
                    })}
                    <div ref={messagesEndRef} />
                  </div>

                  {/* Input */}
                  <div className="p-4 border-t border-gray-200 flex items-center gap-3 bg-white">
                    <button className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full">
                      <Image size={20} />
                    </button>
                    <input
                      ref={inputRef}
                      type="text"
                      value={newMessage}
                      onChange={e => setNewMessage(e.target.value)}
                      onKeyDown={e => e.key === 'Enter' && handleSend()}
                      placeholder="Type a message..."
                      className="flex-1 px-4 py-2.5 bg-gray-100 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-red-500"
                    />
                    <button onClick={handleSend} disabled={!newMessage.trim()}
                      className="p-2.5 bg-red-600 text-white rounded-xl hover:bg-red-700 disabled:opacity-50 transition-colors">
                      <Send size={18} />
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
