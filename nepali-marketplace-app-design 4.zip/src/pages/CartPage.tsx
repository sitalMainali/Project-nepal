import { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Trash2, 
  Plus, 
  Minus, 
  Shield, 
  Truck, 
  RotateCcw,
  ShoppingBag,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  Tag,
  Clock,
  Heart
} from 'lucide-react';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { useApp } from '@/context/AppContext';

export function CartPage() {
  const { state, removeFromCart, updateCartQuantity, getCartTotal, toggleWishlist, isInWishlist } = useApp();
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);

  const cartItems = state.cart;

  const applyCoupon = () => {
    if (couponCode.toUpperCase() === 'NAMASTE10') {
      setAppliedCoupon('NAMASTE10');
    } else if (couponCode.toUpperCase() === 'NEWUSER20') {
      setAppliedCoupon('NEWUSER20');
    }
  };

  const subtotal = getCartTotal();
  const discountPercent = appliedCoupon === 'NAMASTE10' ? 10 : appliedCoupon === 'NEWUSER20' ? 20 : 0;
  const discount = Math.round(subtotal * (discountPercent / 100));
  const deliveryFee = subtotal > 2000 ? 0 : 100;
  const total = subtotal - discount + deliveryFee;
  
  const totalSavings = cartItems.reduce((sum, item) => {
    if (item.product.originalPrice) {
      return sum + (item.product.originalPrice - item.product.price) * item.quantity;
    }
    return sum;
  }, 0) + discount;

  const hasSecondHandItems = cartItems.some(item => item.product.isSecondHand);

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="max-w-4xl mx-auto px-4 py-16 text-center">
          <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <ShoppingBag className="w-12 h-12 text-gray-400" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Your cart is empty</h1>
          <p className="text-gray-600 mb-6">Looks like you haven't added anything to your cart yet.</p>
          <Link
            to="/"
            className="inline-flex items-center gap-2 bg-red-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-red-700 transition-colors"
          >
            Start Shopping
            <ArrowRight size={18} />
          </Link>
          
          {/* Show wishlist items if any */}
          {state.wishlist.length > 0 && (
            <div className="mt-12">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Items in your Wishlist</h3>
              <p className="text-gray-600 text-sm">
                You have {state.wishlist.length} item(s) saved. <Link to="/" className="text-red-600 hover:underline">Continue shopping</Link> to add them to cart.
              </p>
            </div>
          )}
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900">
            Shopping Cart ({cartItems.length} item{cartItems.length !== 1 ? 's' : ''})
          </h1>
          <Link to="/" className="text-red-600 hover:text-red-700 font-medium text-sm">
            Continue Shopping
          </Link>
        </div>

        {/* Trust Banner */}
        <div className="bg-green-50 border border-green-200 rounded-xl p-4 mb-6">
          <div className="flex flex-wrap items-center justify-center gap-6 text-sm">
            <div className="flex items-center gap-2 text-green-800">
              <Shield className="w-5 h-5 text-green-600" />
              <span>100% Purchase Protection</span>
            </div>
            <div className="flex items-center gap-2 text-green-800">
              <RotateCcw className="w-5 h-5 text-green-600" />
              <span>Easy 7-Day Returns</span>
            </div>
            <div className="flex items-center gap-2 text-green-800">
              <Truck className="w-5 h-5 text-green-600" />
              <span>Free Delivery over Rs. 2,000</span>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {cartItems.map((item) => (
              <div
                key={item.product.id}
                className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6"
              >
                <div className="flex gap-4">
                  {/* Image */}
                  <Link to={`/product/${item.product.id}`} className="relative flex-shrink-0">
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-24 h-24 md:w-32 md:h-32 object-cover rounded-lg"
                    />
                    {item.product.isSecondHand && (
                      <span className="absolute top-1 left-1 bg-amber-500 text-white text-xs px-2 py-0.5 rounded-full font-medium">
                        Grade {item.product.conditionGrade}
                      </span>
                    )}
                  </Link>

                  {/* Details */}
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between">
                      <div>
                        <Link to={`/product/${item.product.id}`}>
                          <h3 className="font-semibold text-gray-900 line-clamp-2 hover:text-red-600 transition-colors">
                            {item.product.name}
                          </h3>
                        </Link>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-sm text-gray-600">{item.product.seller}</span>
                          {item.product.isVerified && (
                            <span className="inline-flex items-center gap-1 text-xs text-green-700 bg-green-100 px-2 py-0.5 rounded-full">
                              <CheckCircle2 size={12} />
                              Verified
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-1">
                        <button
                          onClick={() => toggleWishlist(item.product.id)}
                          className={`p-2 rounded-full transition-colors ${
                            isInWishlist(item.product.id)
                              ? 'text-red-500 hover:bg-red-50'
                              : 'text-gray-400 hover:bg-gray-100'
                          }`}
                          aria-label="Toggle wishlist"
                        >
                          <Heart size={18} fill={isInWishlist(item.product.id) ? 'currentColor' : 'none'} />
                        </button>
                        <button
                          onClick={() => removeFromCart(item.product.id)}
                          className="text-gray-400 hover:text-red-600 transition-colors p-2 hover:bg-red-50 rounded-full"
                          aria-label="Remove item"
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </div>

                    {/* Variants */}
                    {(item.selectedColor || item.selectedSize) && (
                      <div className="flex gap-3 mt-2 text-sm text-gray-600">
                        {item.selectedColor && <span>Color: {item.selectedColor}</span>}
                        {item.selectedSize && <span>Size: {item.selectedSize}</span>}
                      </div>
                    )}

                    {/* Delivery */}
                    <div className="flex items-center gap-2 mt-2 text-sm">
                      <Truck size={14} className="text-blue-600" />
                      <span className="text-gray-600">
                        Delivery in <strong>{item.product.deliveryDays || '3-5'} days</strong>
                        {item.product.freeDelivery && <span className="text-green-600 ml-1">(FREE)</span>}
                      </span>
                    </div>

                    {/* Price & Quantity */}
                    <div className="flex items-center justify-between mt-4">
                      {/* Quantity */}
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                          disabled={item.quantity <= 1}
                          className="w-8 h-8 flex items-center justify-center border border-gray-300 rounded-lg hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          <Minus size={14} />
                        </button>
                        <span className="w-10 text-center font-medium">{item.quantity}</span>
                        <button
                          onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                          disabled={item.quantity >= (item.product.stock || 10)}
                          className="w-8 h-8 flex items-center justify-center border border-gray-300 rounded-lg hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          <Plus size={14} />
                        </button>
                        {item.product.stock && item.quantity >= item.product.stock && (
                          <span className="text-xs text-amber-600 ml-2">Max qty</span>
                        )}
                      </div>

                      {/* Price */}
                      <div className="text-right">
                        <div className="font-bold text-gray-900">
                          Rs. {(item.product.price * item.quantity).toLocaleString()}
                        </div>
                        {item.product.originalPrice && (
                          <div className="text-sm text-gray-500 line-through">
                            Rs. {(item.product.originalPrice * item.quantity).toLocaleString()}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}

            {/* Second-hand Notice */}
            {hasSecondHandItems && (
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-medium text-amber-900">Resale Item in Cart</h4>
                  <p className="text-sm text-amber-800 mt-1">
                    Second-hand items are protected by our escrow payment system. Payment is released to seller only after you confirm the item matches the description.
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 sticky top-24">
              <h2 className="text-lg font-bold text-gray-900 mb-4">Order Summary</h2>

              {/* Coupon */}
              <div className="mb-6">
                <label className="text-sm font-medium text-gray-700 mb-2 block">
                  Have a coupon?
                </label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Tag className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input
                      type="text"
                      value={couponCode}
                      onChange={(e) => setCouponCode(e.target.value)}
                      placeholder="Enter code"
                      disabled={!!appliedCoupon}
                      className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-red-500 focus:border-transparent disabled:bg-gray-100"
                    />
                  </div>
                  {appliedCoupon ? (
                    <button
                      onClick={() => {
                        setAppliedCoupon(null);
                        setCouponCode('');
                      }}
                      className="px-4 py-2 bg-red-100 text-red-700 rounded-lg text-sm font-medium hover:bg-red-200"
                    >
                      Remove
                    </button>
                  ) : (
                    <button
                      onClick={applyCoupon}
                      disabled={!couponCode}
                      className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      Apply
                    </button>
                  )}
                </div>
                {appliedCoupon && (
                  <div className="flex items-center gap-2 mt-2 text-sm text-green-700">
                    <CheckCircle2 size={14} />
                    <span>Coupon "{appliedCoupon}" applied! (-{discountPercent}%)</span>
                  </div>
                )}
                <p className="text-xs text-gray-500 mt-1">Try: NAMASTE10 or NEWUSER20</p>
              </div>

              {/* Price Breakdown */}
              <div className="space-y-3 border-t border-gray-100 pt-4">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Subtotal ({cartItems.length} items)</span>
                  <span className="text-gray-900">Rs. {subtotal.toLocaleString()}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-sm">
                    <span className="text-green-600">Coupon Discount ({discountPercent}%)</span>
                    <span className="text-green-600">-Rs. {discount.toLocaleString()}</span>
                  </div>
                )}
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Delivery</span>
                  {deliveryFee === 0 ? (
                    <span className="text-green-600">FREE</span>
                  ) : (
                    <span className="text-gray-900">Rs. {deliveryFee}</span>
                  )}
                </div>
                {deliveryFee > 0 && (
                  <p className="text-xs text-gray-500">
                    Add Rs. {(2000 - subtotal).toLocaleString()} more for free delivery
                  </p>
                )}
                <div className="flex justify-between font-bold text-lg pt-3 border-t border-gray-100">
                  <span>Total</span>
                  <span>Rs. {total.toLocaleString()}</span>
                </div>
              </div>

              {/* Savings */}
              {totalSavings > 0 && (
                <div className="bg-green-50 text-green-800 text-sm rounded-lg p-3 mt-4 text-center">
                  🎉 You're saving <strong>Rs. {totalSavings.toLocaleString()}</strong> on this order!
                </div>
              )}

              {/* Checkout Button */}
              <Link
                to="/checkout"
                className="w-full mt-6 bg-gradient-to-r from-red-600 to-red-700 text-white py-3 rounded-lg font-semibold hover:from-red-700 hover:to-red-800 transition-all flex items-center justify-center gap-2 shadow-lg shadow-red-600/25"
              >
                Proceed to Checkout
                <ArrowRight size={18} />
              </Link>

              {/* Trust Assurance */}
              <div className="mt-4 space-y-2">
                <div className="flex items-center gap-2 text-xs text-gray-600">
                  <Shield size={14} className="text-green-600" />
                  <span>Your payment is protected</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-gray-600">
                  <Clock size={14} className="text-blue-600" />
                  <span>Prices held for 30 minutes</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
