import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  LayoutDashboard, Users, Store, Package, ShoppingCart, AlertTriangle,
  CheckCircle2, XCircle, Clock, Shield, DollarSign, Ban,
  ChevronRight, Search, Menu, X, Bell, Settings,
  LogOut, Flag, Mail,
  ArrowUpRight, RefreshCw, FileText, Save
} from 'lucide-react';
import { useApp } from '@/context/AppContext';

type TabType = 'overview' | 'users' | 'sellers' | 'products' | 'orders' | 'disputes' | 'settings';

interface AdminUser { id: string; name: string; email: string; phone: string; type: 'customer' | 'seller'; status: 'active' | 'suspended' | 'banned'; joinedAt: string; orders: number; spent: number; }
interface AdminSeller { id: string; name: string; email: string; phone: string; status: 'pending' | 'verified' | 'suspended' | 'banned'; trustScore: number; totalSales: number; disputes: number; products: number; joinedAt: string; documents: boolean; }
interface AdminProduct { id: string; name: string; seller: string; price: number; image: string; status: 'approved' | 'pending' | 'flagged' | 'removed'; reason?: string; reports: number; createdAt: string; }
interface AdminOrder { id: string; buyer: string; seller: string; amount: number; status: 'pending' | 'confirmed' | 'shipped' | 'delivered' | 'disputed' | 'cancelled'; date: string; product: string; }
interface Dispute { id: string; orderId: string; buyer: string; seller: string; reason: string; description: string; status: 'open' | 'investigating' | 'waiting_seller' | 'proposed' | 'resolved' | 'escalated'; priority: 'low' | 'medium' | 'high'; createdAt: string; amount: number; resolution?: string; }

const initUsers: AdminUser[] = [
  { id: 'u1', name: 'Ram Bahadur Shrestha', email: 'ram@email.com', phone: '9841000001', type: 'customer', status: 'active', joinedAt: 'Jan 2023', orders: 15, spent: 45000 },
  { id: 'u2', name: 'Sita Kumari Thapa', email: 'sita@email.com', phone: '9841000002', type: 'customer', status: 'active', joinedAt: 'Mar 2023', orders: 8, spent: 23000 },
  { id: 'u3', name: 'John Doe', email: 'john@email.com', phone: '9841000003', type: 'customer', status: 'suspended', joinedAt: 'Jun 2023', orders: 3, spent: 5000 },
  { id: 'u4', name: 'Maya Tamang', email: 'maya@email.com', phone: '9841000004', type: 'customer', status: 'active', joinedAt: 'Sep 2023', orders: 22, spent: 78000 },
  { id: 'u5', name: 'Hari Prasad', email: 'hari@email.com', phone: '9841000005', type: 'customer', status: 'banned', joinedAt: 'Nov 2023', orders: 1, spent: 500 },
];
const initSellers: AdminSeller[] = [
  { id: 's1', name: 'Nepal Craft House', email: 'craft@email.com', phone: '01-4567890', status: 'verified', trustScore: 94, totalSales: 125600, disputes: 2, products: 24, joinedAt: 'Jan 2023', documents: true },
  { id: 's2', name: 'Himalayan Textiles', email: 'himalayan@email.com', phone: '01-4567891', status: 'verified', trustScore: 98, totalSales: 456000, disputes: 1, products: 56, joinedAt: 'Mar 2022', documents: true },
  { id: 's3', name: 'New Seller Shop', email: 'newseller@email.com', phone: '9842000001', status: 'pending', trustScore: 0, totalSales: 0, disputes: 0, products: 0, joinedAt: 'Today', documents: true },
  { id: 's4', name: 'Quick Fashion', email: 'quick@email.com', phone: '9842000002', status: 'pending', trustScore: 0, totalSales: 0, disputes: 0, products: 0, joinedAt: 'Yesterday', documents: false },
  { id: 's5', name: 'Fake Products Inc', email: 'fake@email.com', phone: '9842000003', status: 'suspended', trustScore: 25, totalSales: 12000, disputes: 15, products: 5, joinedAt: 'Jun 2023', documents: true },
  { id: 's6', name: 'Scam Store', email: 'scam@email.com', phone: '9842000004', status: 'banned', trustScore: 0, totalSales: 5000, disputes: 28, products: 0, joinedAt: 'Aug 2023', documents: false },
];
const initProducts: AdminProduct[] = [
  { id: 'ap1', name: 'Authentic Dhaka Topi', seller: 'Nepal Craft House', price: 850, image: '🎩', status: 'approved', reports: 0, createdAt: '2 weeks ago' },
  { id: 'ap2', name: 'Suspicious iPhone 15', seller: 'Quick Fashion', price: 25000, image: '📱', status: 'pending', reports: 0, createdAt: '1 day ago' },
  { id: 'ap3', name: 'Knockoff Pashmina', seller: 'Fake Products Inc', price: 500, image: '🧣', status: 'flagged', reason: 'Stock photos used, misleading description', reports: 5, createdAt: '5 days ago' },
  { id: 'ap4', name: '"Branded" Watch', seller: 'Scam Store', price: 2000, image: '⌚', status: 'removed', reason: 'Counterfeit product', reports: 12, createdAt: '1 week ago' },
  { id: 'ap5', name: 'Handmade Singing Bowl', seller: 'Himalayan Textiles', price: 3200, image: '🔔', status: 'approved', reports: 0, createdAt: '3 days ago' },
  { id: 'ap6', name: 'Yak Wool Blanket', seller: 'New Seller Shop', price: 4500, image: '🛏️', status: 'pending', reports: 0, createdAt: 'Today' },
];
const initOrders: AdminOrder[] = [
  { id: 'AO-001', buyer: 'Ram B.', seller: 'Nepal Craft House', amount: 850, status: 'pending', date: '2 hours ago', product: 'Dhaka Topi' },
  { id: 'AO-002', buyer: 'Sita K.', seller: 'Himalayan Textiles', amount: 4500, status: 'shipped', date: '1 day ago', product: 'Pashmina Shawl' },
  { id: 'AO-003', buyer: 'Maya T.', seller: 'Nepal Craft House', amount: 15000, status: 'delivered', date: '3 days ago', product: 'Thangka Painting' },
  { id: 'AO-004', buyer: 'Hari P.', seller: 'Fake Products Inc', amount: 500, status: 'disputed', date: '4 days ago', product: 'Knockoff Pashmina' },
  { id: 'AO-005', buyer: 'John D.', seller: 'Nepal Craft House', amount: 3200, status: 'cancelled', date: '5 days ago', product: 'Singing Bowl' },
];
const initDisputes: Dispute[] = [
  { id: 'DSP-001', orderId: 'AO-004', buyer: 'Hari P.', seller: 'Fake Products Inc', reason: 'Item not as described', description: 'The pashmina looks nothing like the photos. Material feels synthetic, not real cashmere.', status: 'open', priority: 'high', createdAt: '2 hours ago', amount: 500 },
  { id: 'DSP-002', orderId: 'AO-006', buyer: 'Sita M.', seller: 'Himalayan Goods', reason: 'Damaged on delivery', description: 'Singing bowl arrived cracked. Packaging was inadequate.', status: 'investigating', priority: 'medium', createdAt: '5 hours ago', amount: 2300 },
  { id: 'DSP-003', orderId: 'AO-007', buyer: 'Ram K.', seller: 'Kathmandu Bazaar', reason: 'Wrong item received', description: 'I ordered a blue shawl but received red. Wrong item entirely.', status: 'escalated', priority: 'high', createdAt: '1 day ago', amount: 4500 },
  { id: 'DSP-004', orderId: 'AO-008', buyer: 'Maya T.', seller: 'Pokhara Crafts', reason: 'Never delivered', description: 'Order shows delivered but I never received it.', status: 'resolved', priority: 'low', createdAt: '5 days ago', amount: 1200, resolution: 'Full refund issued to buyer' },
];

export function AdminPanel() {
  const { addNotification } = useApp();
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const [users, setUsers] = useState(initUsers);
  const [adminSellers, setAdminSellers] = useState(initSellers);
  const [adminProducts, setAdminProducts] = useState(initProducts);
  const [adminOrders, setAdminOrders] = useState(initOrders);
  const [disputes, setDisputes] = useState(initDisputes);

  const [sellerFilter, setSellerFilter] = useState<string>('all');
  const [productFilter, setProductFilter] = useState<string>('all');
  const [orderFilter, setOrderFilter] = useState<string>('all');
  const [disputeDetail, setDisputeDetail] = useState<string | null>(null);
  const [resolutionText, setResolutionText] = useState('');
  const [platformSettings, setPlatformSettings] = useState({ commission: '10', minTrustScore: '70', disputeWindow: '7', escrowHold: '48', maxListings: '100', requirePhotos: true, autoFlagThreshold: '3' });
  const [saving, setSaving] = useState(false);

  const stats = {
    totalUsers: users.length + adminSellers.length,
    totalSellers: adminSellers.length,
    totalOrders: adminOrders.length,
    totalRevenue: adminOrders.filter(o => o.status === 'delivered').reduce((s, o) => s + o.amount, 0),
    activeDisputes: disputes.filter(d => d.status !== 'resolved').length,
    pendingVerifications: adminSellers.filter(s => s.status === 'pending').length,
    pendingProducts: adminProducts.filter(p => p.status === 'pending').length,
    flaggedProducts: adminProducts.filter(p => p.status === 'flagged').length,
  };

  // User actions
  const updateUserStatus = (id: string, status: AdminUser['status']) => { setUsers(prev => prev.map(u => u.id === id ? { ...u, status } : u)); addNotification('success', 'User Updated', `User status changed to ${status}.`); };

  // Seller actions
  const updateSellerStatus = (id: string, status: AdminSeller['status']) => { setAdminSellers(prev => prev.map(s => s.id === id ? { ...s, status, trustScore: status === 'verified' ? 50 : status === 'banned' ? 0 : s.trustScore } : s)); addNotification('success', 'Seller Updated', `Seller status changed to ${status}.`); };

  // Product actions
  const updateProductStatus = (id: string, status: AdminProduct['status'], reason?: string) => { setAdminProducts(prev => prev.map(p => p.id === id ? { ...p, status, reason: reason || p.reason } : p)); addNotification('success', 'Product Updated', `Product ${status}.`); };

  // Order actions
  const updateOrderStatus = (id: string, status: AdminOrder['status']) => { setAdminOrders(prev => prev.map(o => o.id === id ? { ...o, status } : o)); addNotification('success', 'Order Updated', `Order status changed to ${status}.`); };

  // Dispute actions
  const updateDisputeStatus = (id: string, status: Dispute['status'], resolution?: string) => {
    setDisputes(prev => prev.map(d => d.id === id ? { ...d, status, resolution: resolution || d.resolution } : d));
    addNotification('success', 'Dispute Updated', `Dispute ${id} status changed to ${status}.`);
    setDisputeDetail(null);
    setResolutionText('');
  };

  const handleSaveSettings = async () => { setSaving(true); await new Promise(r => setTimeout(r, 800)); setSaving(false); addNotification('success', 'Settings Saved', 'Platform settings updated.'); };

  const getStatusColor = (status: string) => {
    const m: Record<string, string> = { active: 'bg-green-100 text-green-800', verified: 'bg-green-100 text-green-800', approved: 'bg-green-100 text-green-800', pending: 'bg-amber-100 text-amber-800', suspended: 'bg-red-100 text-red-800', banned: 'bg-gray-800 text-white', flagged: 'bg-orange-100 text-orange-800', removed: 'bg-gray-100 text-gray-800', open: 'bg-red-100 text-red-800', investigating: 'bg-amber-100 text-amber-800', waiting_seller: 'bg-blue-100 text-blue-800', proposed: 'bg-purple-100 text-purple-800', resolved: 'bg-green-100 text-green-800', escalated: 'bg-red-200 text-red-900', confirmed: 'bg-blue-100 text-blue-800', shipped: 'bg-purple-100 text-purple-800', delivered: 'bg-green-100 text-green-800', disputed: 'bg-red-100 text-red-800', cancelled: 'bg-gray-100 text-gray-800' };
    return m[status] || 'bg-gray-100 text-gray-800';
  };

  const navItems = [
    { id: 'overview', icon: LayoutDashboard, label: 'Overview' },
    { id: 'users', icon: Users, label: 'Users' },
    { id: 'sellers', icon: Store, label: 'Sellers', badge: stats.pendingVerifications },
    { id: 'products', icon: Package, label: 'Products', badge: stats.pendingProducts + stats.flaggedProducts },
    { id: 'orders', icon: ShoppingCart, label: 'Orders' },
    { id: 'disputes', icon: AlertTriangle, label: 'Disputes', badge: stats.activeDisputes },
    { id: 'settings', icon: Settings, label: 'Settings' },
  ];

  const filteredSellers = sellerFilter === 'all' ? adminSellers : adminSellers.filter(s => s.status === sellerFilter);
  const filteredProducts = productFilter === 'all' ? adminProducts : adminProducts.filter(p => p.status === productFilter);
  const filteredOrders = orderFilter === 'all' ? adminOrders : adminOrders.filter(o => o.status === orderFilter);
  const searchedUsers = searchQuery ? users.filter(u => u.name.toLowerCase().includes(searchQuery.toLowerCase()) || u.email.toLowerCase().includes(searchQuery.toLowerCase())) : users;

  return (
    <div className="min-h-screen bg-gray-100 flex">
      {sidebarOpen && <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />}
      <aside className={`fixed inset-y-0 left-0 z-50 w-64 bg-gray-900 transform transition-transform lg:translate-x-0 lg:static ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex flex-col h-full">
          <div className="p-4 border-b border-gray-800 flex items-center justify-between">
            <Link to="/" className="flex items-center gap-2"><div className="w-8 h-8 bg-red-600 rounded-lg flex items-center justify-center"><Shield className="w-5 h-5 text-white" /></div><span className="text-white font-bold">BazaarCo Admin</span></Link>
            <button onClick={() => setSidebarOpen(false)} className="lg:hidden p-2 hover:bg-gray-800 rounded-lg text-gray-400"><X size={20} /></button>
          </div>
          <nav className="flex-1 p-3 space-y-1 overflow-auto">
            {navItems.map(item => (
              <button key={item.id} onClick={() => { setActiveTab(item.id as TabType); setSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${activeTab === item.id ? 'bg-red-600 text-white' : 'text-gray-400 hover:bg-gray-800 hover:text-white'}`}>
                <item.icon size={18} />{item.label}
                {item.badge ? <span className={`ml-auto text-xs px-1.5 py-0.5 rounded-full ${activeTab === item.id ? 'bg-white text-red-600' : 'bg-red-600 text-white'}`}>{item.badge}</span> : null}
              </button>
            ))}
          </nav>
          <div className="p-3 border-t border-gray-800">
            <Link to="/" className="w-full flex items-center gap-3 px-3 py-2 text-gray-400 hover:bg-gray-800 hover:text-white rounded-lg text-sm"><LogOut size={18} />Back to Store</Link>
          </div>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        <header className="bg-white border-b border-gray-200 px-4 lg:px-6 py-3 flex items-center justify-between sticky top-0 z-30">
          <div className="flex items-center gap-3">
            <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-2 hover:bg-gray-100 rounded-lg"><Menu size={20} /></button>
            <h1 className="text-lg font-bold text-gray-900 hidden sm:block">{navItems.find(n => n.id === activeTab)?.label}</h1>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input type="text" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder="Search..." className="w-64 pl-9 pr-4 py-2 border border-gray-300 rounded-lg text-sm" />
            </div>
            <button className="relative p-2 hover:bg-gray-100 rounded-full"><Bell size={20} className="text-gray-600" /><span className="absolute top-1 right-1 w-2 h-2 bg-red-600 rounded-full" /></button>
            <div className="w-8 h-8 bg-gray-900 rounded-full flex items-center justify-center text-white text-sm font-medium">A</div>
          </div>
        </header>

        <main className="flex-1 p-4 lg:p-6 overflow-auto">
          {/* OVERVIEW */}
          {activeTab === 'overview' && (
            <>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                {[
                  { label: 'Total Users', value: stats.totalUsers, icon: Users, color: 'bg-blue-100 text-blue-600', change: '+12%' },
                  { label: 'Revenue', value: `Rs. ${(stats.totalRevenue / 1000).toFixed(0)}K`, icon: DollarSign, color: 'bg-green-100 text-green-600', change: '+8%' },
                  { label: 'Active Sellers', value: adminSellers.filter(s => s.status === 'verified').length, icon: Store, color: 'bg-purple-100 text-purple-600' },
                  { label: 'Active Disputes', value: stats.activeDisputes, icon: AlertTriangle, color: 'bg-red-100 text-red-600' },
                ].map((s, i) => (
                  <div key={i} className="bg-white rounded-xl shadow-sm p-4">
                    <div className="flex items-center justify-between mb-3"><div className={`w-10 h-10 ${s.color} rounded-lg flex items-center justify-center`}><s.icon className="w-5 h-5" /></div>{s.change && <span className="text-xs text-green-600 flex items-center gap-0.5"><ArrowUpRight size={12} />{s.change}</span>}</div>
                    <p className="text-2xl font-bold text-gray-900">{s.value}</p>
                    <p className="text-sm text-gray-600">{s.label}</p>
                  </div>
                ))}
              </div>

              <div className="grid md:grid-cols-3 gap-4 mb-6">
                {[
                  { label: `${stats.pendingVerifications} Pending`, desc: 'Seller verifications', color: 'amber', icon: Clock, action: () => { setActiveTab('sellers'); setSellerFilter('pending'); } },
                  { label: `${stats.activeDisputes} Active`, desc: 'Disputes to resolve', color: 'red', icon: Flag, action: () => setActiveTab('disputes') },
                  { label: `${stats.pendingProducts + stats.flaggedProducts} Review`, desc: 'Product listings', color: 'blue', icon: FileText, action: () => { setActiveTab('products'); setProductFilter('pending'); } },
                ].map((q, i) => (
                  <div key={i} className={`bg-${q.color}-50 border border-${q.color}-200 rounded-xl p-4`}>
                    <div className="flex items-center gap-3"><div className={`w-10 h-10 bg-${q.color}-100 rounded-lg flex items-center justify-center`}><q.icon className={`w-5 h-5 text-${q.color}-600`} /></div><div><p className={`font-semibold text-${q.color}-900`}>{q.label}</p><p className={`text-sm text-${q.color}-700`}>{q.desc}</p></div></div>
                    <button onClick={q.action} className={`mt-3 text-sm font-semibold text-${q.color}-900 hover:underline flex items-center gap-1`}>Review <ChevronRight size={14} /></button>
                  </div>
                ))}
              </div>

              {/* Recent Disputes Overview */}
              <div className="bg-white rounded-xl shadow-sm overflow-hidden">
                <div className="p-4 border-b border-gray-100 flex items-center justify-between"><h3 className="font-semibold text-gray-900">Recent Disputes</h3><button onClick={() => setActiveTab('disputes')} className="text-red-600 text-sm font-medium hover:underline">View All</button></div>
                <div className="divide-y divide-gray-100">
                  {disputes.slice(0, 3).map(d => (
                    <div key={d.id} className="p-4 hover:bg-gray-50 flex items-center justify-between">
                      <div>
                        <div className="flex items-center gap-2"><span className="font-medium text-gray-900 text-sm">{d.id}</span><span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColor(d.status)}`}>{d.status.replace('_', ' ')}</span></div>
                        <p className="text-gray-600 text-sm mt-0.5">{d.reason} — {d.buyer} vs {d.seller}</p>
                      </div>
                      <button onClick={() => { setActiveTab('disputes'); setDisputeDetail(d.id); }} className="text-red-600 text-sm font-medium hover:underline">Handle</button>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          {/* USERS */}
          {activeTab === 'users' && (
            <div className="bg-white rounded-xl shadow-sm overflow-hidden">
              <div className="p-4 border-b border-gray-100 flex items-center justify-between">
                <h3 className="font-semibold text-gray-900">All Users ({searchedUsers.length})</h3>
                <div className="relative"><Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" /><input type="text" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder="Search users..." className="pl-9 pr-4 py-2 border border-gray-300 rounded-lg text-sm w-60" /></div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full"><thead className="bg-gray-50"><tr>{['User','Phone','Status','Orders','Total Spent','Joined','Actions'].map(h => <th key={h} className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase">{h}</th>)}</tr></thead>
                  <tbody className="divide-y divide-gray-100">
                    {searchedUsers.map(u => (
                      <tr key={u.id} className="hover:bg-gray-50">
                        <td className="px-4 py-3"><div className="flex items-center gap-3"><div className="w-9 h-9 bg-gray-200 rounded-full flex items-center justify-center font-medium text-gray-600 text-sm">{u.name.charAt(0)}</div><div><p className="font-medium text-gray-900 text-sm">{u.name}</p><p className="text-xs text-gray-500">{u.email}</p></div></div></td>
                        <td className="px-4 py-3 text-sm text-gray-600">{u.phone}</td>
                        <td className="px-4 py-3"><span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColor(u.status)}`}>{u.status}</span></td>
                        <td className="px-4 py-3 text-sm font-medium">{u.orders}</td>
                        <td className="px-4 py-3 text-sm font-medium">Rs. {u.spent.toLocaleString()}</td>
                        <td className="px-4 py-3 text-sm text-gray-500">{u.joinedAt}</td>
                        <td className="px-4 py-3">
                          <div className="flex gap-1">
                            {u.status === 'active' && <button onClick={() => updateUserStatus(u.id, 'suspended')} className="p-1 hover:bg-red-100 rounded text-red-600" title="Suspend"><Ban size={16} /></button>}
                            {u.status === 'suspended' && <><button onClick={() => updateUserStatus(u.id, 'active')} className="p-1 hover:bg-green-100 rounded text-green-600" title="Reactivate"><CheckCircle2 size={16} /></button><button onClick={() => updateUserStatus(u.id, 'banned')} className="p-1 hover:bg-red-100 rounded text-red-600" title="Ban"><XCircle size={16} /></button></>}
                            {u.status === 'banned' && <button onClick={() => updateUserStatus(u.id, 'active')} className="p-1 hover:bg-green-100 rounded text-green-600" title="Unban"><RefreshCw size={16} /></button>}
                            <button className="p-1 hover:bg-gray-100 rounded text-gray-500" title="Message"><Mail size={16} /></button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* SELLERS */}
          {activeTab === 'sellers' && (
            <>
              <div className="flex flex-wrap gap-2 mb-6">
                {['all','pending','verified','suspended','banned'].map(f => (
                  <button key={f} onClick={() => setSellerFilter(f)} className={`px-3 py-1.5 rounded-lg text-sm font-medium ${sellerFilter === f ? 'bg-red-600 text-white' : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50'}`}>
                    {f.charAt(0).toUpperCase() + f.slice(1)} ({f === 'all' ? adminSellers.length : adminSellers.filter(s => s.status === f).length})
                  </button>
                ))}
              </div>
              <div className="bg-white rounded-xl shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full"><thead className="bg-gray-50"><tr>{['Seller','Status','Trust','Sales','Products','Disputes','Joined','Actions'].map(h => <th key={h} className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase">{h}</th>)}</tr></thead>
                    <tbody className="divide-y divide-gray-100">
                      {filteredSellers.map(s => (
                        <tr key={s.id} className="hover:bg-gray-50">
                          <td className="px-4 py-3"><div className="flex items-center gap-3"><div className="w-9 h-9 bg-gray-200 rounded-full flex items-center justify-center font-medium text-gray-600 text-sm">{s.name.charAt(0)}</div><div><p className="font-medium text-gray-900 text-sm">{s.name}</p><p className="text-xs text-gray-500">{s.email}</p>{!s.documents && <span className="text-xs text-amber-600">⚠ Missing docs</span>}</div></div></td>
                          <td className="px-4 py-3"><span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColor(s.status)}`}>{s.status}</span></td>
                          <td className="px-4 py-3"><div className="flex items-center gap-2"><div className="w-12 h-2 bg-gray-200 rounded-full overflow-hidden"><div className={`h-full rounded-full ${s.trustScore >= 80 ? 'bg-green-500' : s.trustScore >= 50 ? 'bg-amber-500' : 'bg-red-500'}`} style={{ width: `${s.trustScore}%` }} /></div><span className="text-xs font-medium">{s.trustScore}%</span></div></td>
                          <td className="px-4 py-3 text-sm">Rs. {s.totalSales.toLocaleString()}</td>
                          <td className="px-4 py-3 text-sm">{s.products}</td>
                          <td className="px-4 py-3 text-sm"><span className={s.disputes > 10 ? 'text-red-600 font-bold' : ''}>{s.disputes}</span></td>
                          <td className="px-4 py-3 text-sm text-gray-500">{s.joinedAt}</td>
                          <td className="px-4 py-3">
                            <div className="flex gap-1">
                              {s.status === 'pending' && (<><button onClick={() => updateSellerStatus(s.id, 'verified')} className="px-2 py-1 bg-green-100 text-green-700 rounded text-xs font-medium hover:bg-green-200 flex items-center gap-1"><CheckCircle2 size={12} />Approve</button><button onClick={() => updateSellerStatus(s.id, 'banned')} className="px-2 py-1 bg-red-100 text-red-700 rounded text-xs font-medium hover:bg-red-200 flex items-center gap-1"><XCircle size={12} />Reject</button></>)}
                              {s.status === 'verified' && <button onClick={() => updateSellerStatus(s.id, 'suspended')} className="px-2 py-1 bg-red-100 text-red-700 rounded text-xs font-medium hover:bg-red-200 flex items-center gap-1"><Ban size={12} />Suspend</button>}
                              {s.status === 'suspended' && (<><button onClick={() => updateSellerStatus(s.id, 'verified')} className="px-2 py-1 bg-green-100 text-green-700 rounded text-xs font-medium hover:bg-green-200">Reinstate</button><button onClick={() => updateSellerStatus(s.id, 'banned')} className="px-2 py-1 bg-gray-800 text-white rounded text-xs font-medium">Ban</button></>)}
                              {s.status === 'banned' && <button onClick={() => updateSellerStatus(s.id, 'pending')} className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs font-medium hover:bg-gray-200"><RefreshCw size={12} className="inline mr-1" />Review</button>}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}

          {/* PRODUCTS */}
          {activeTab === 'products' && (
            <>
              <div className="flex flex-wrap gap-2 mb-6">
                {['all','pending','approved','flagged','removed'].map(f => (
                  <button key={f} onClick={() => setProductFilter(f)} className={`px-3 py-1.5 rounded-lg text-sm font-medium ${productFilter === f ? 'bg-red-600 text-white' : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50'}`}>
                    {f.charAt(0).toUpperCase() + f.slice(1)} ({f === 'all' ? adminProducts.length : adminProducts.filter(p => p.status === f).length})
                  </button>
                ))}
              </div>
              <div className="space-y-3">
                {filteredProducts.map(p => (
                  <div key={p.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 flex items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <span className="text-3xl">{p.image}</span>
                      <div>
                        <div className="flex items-center gap-2"><h4 className="font-medium text-gray-900 text-sm">{p.name}</h4><span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColor(p.status)}`}>{p.status}</span></div>
                        <p className="text-gray-600 text-xs mt-0.5">by {p.seller} · Rs. {p.price.toLocaleString()} · {p.createdAt}</p>
                        {p.reason && <p className="text-red-600 text-xs mt-0.5">⚠ {p.reason}</p>}
                        {p.reports > 0 && <p className="text-amber-600 text-xs">{p.reports} reports</p>}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      {p.status === 'pending' && (<><button onClick={() => updateProductStatus(p.id, 'approved')} className="px-3 py-1.5 bg-green-100 text-green-700 rounded-lg text-xs font-medium hover:bg-green-200 flex items-center gap-1"><CheckCircle2 size={12} />Approve</button><button onClick={() => updateProductStatus(p.id, 'flagged', 'Needs review')} className="px-3 py-1.5 bg-amber-100 text-amber-700 rounded-lg text-xs font-medium hover:bg-amber-200 flex items-center gap-1"><Flag size={12} />Flag</button><button onClick={() => updateProductStatus(p.id, 'removed', 'Rejected by admin')} className="px-3 py-1.5 bg-red-100 text-red-700 rounded-lg text-xs font-medium hover:bg-red-200 flex items-center gap-1"><XCircle size={12} />Reject</button></>)}
                      {p.status === 'flagged' && (<><button onClick={() => updateProductStatus(p.id, 'approved')} className="px-3 py-1.5 bg-green-100 text-green-700 rounded-lg text-xs font-medium hover:bg-green-200">Approve</button><button onClick={() => updateProductStatus(p.id, 'removed', 'Removed after review')} className="px-3 py-1.5 bg-red-100 text-red-700 rounded-lg text-xs font-medium hover:bg-red-200">Remove</button></>)}
                      {p.status === 'approved' && <button onClick={() => updateProductStatus(p.id, 'flagged', 'Flagged by admin')} className="px-3 py-1.5 bg-amber-100 text-amber-700 rounded-lg text-xs font-medium hover:bg-amber-200"><Flag size={12} className="inline mr-1" />Flag</button>}
                      {p.status === 'removed' && <button onClick={() => updateProductStatus(p.id, 'approved')} className="px-3 py-1.5 bg-green-100 text-green-700 rounded-lg text-xs font-medium hover:bg-green-200">Restore</button>}
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}

          {/* ORDERS */}
          {activeTab === 'orders' && (
            <>
              <div className="flex flex-wrap gap-2 mb-6">
                {['all','pending','confirmed','shipped','delivered','disputed','cancelled'].map(f => (
                  <button key={f} onClick={() => setOrderFilter(f)} className={`px-3 py-1.5 rounded-lg text-sm font-medium ${orderFilter === f ? 'bg-red-600 text-white' : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50'}`}>{f.charAt(0).toUpperCase() + f.slice(1)}</button>
                ))}
              </div>
              <div className="bg-white rounded-xl shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full"><thead className="bg-gray-50"><tr>{['Order','Product','Buyer','Seller','Amount','Status','Date','Actions'].map(h => <th key={h} className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase">{h}</th>)}</tr></thead>
                    <tbody className="divide-y divide-gray-100">
                      {filteredOrders.map(o => (
                        <tr key={o.id} className="hover:bg-gray-50">
                          <td className="px-4 py-3 font-medium text-gray-900 text-sm">{o.id}</td>
                          <td className="px-4 py-3 text-gray-600 text-sm">{o.product}</td>
                          <td className="px-4 py-3 text-gray-600 text-sm">{o.buyer}</td>
                          <td className="px-4 py-3 text-gray-600 text-sm">{o.seller}</td>
                          <td className="px-4 py-3 font-medium text-sm">Rs. {o.amount.toLocaleString()}</td>
                          <td className="px-4 py-3"><span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColor(o.status)}`}>{o.status}</span></td>
                          <td className="px-4 py-3 text-gray-500 text-sm">{o.date}</td>
                          <td className="px-4 py-3">
                            {o.status === 'disputed' && <button onClick={() => setActiveTab('disputes')} className="text-red-600 text-xs font-medium hover:underline">View Dispute</button>}
                            {o.status === 'pending' && <button onClick={() => updateOrderStatus(o.id, 'cancelled')} className="text-gray-600 text-xs font-medium hover:underline">Cancel</button>}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}

          {/* DISPUTES */}
          {activeTab === 'disputes' && (
            <>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                {[
                  { label: 'Open', count: disputes.filter(d => d.status === 'open').length, color: 'text-red-600' },
                  { label: 'Investigating', count: disputes.filter(d => d.status === 'investigating').length, color: 'text-amber-600' },
                  { label: 'Escalated', count: disputes.filter(d => d.status === 'escalated').length, color: 'text-purple-600' },
                  { label: 'Resolved', count: disputes.filter(d => d.status === 'resolved').length, color: 'text-green-600' },
                ].map((s, i) => (
                  <div key={i} className="bg-white rounded-xl shadow-sm p-4 text-center"><p className={`text-2xl font-bold ${s.color}`}>{s.count}</p><p className="text-sm text-gray-600">{s.label}</p></div>
                ))}
              </div>

              {/* Dispute Detail Modal */}
              {disputeDetail && (() => {
                const d = disputes.find(x => x.id === disputeDetail);
                if (!d) return null;
                return (
                  <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
                    <div className="bg-white rounded-2xl max-w-lg w-full p-6 max-h-[90vh] overflow-y-auto">
                      <div className="flex items-center justify-between mb-4"><h2 className="text-lg font-bold text-gray-900">Dispute {d.id}</h2><button onClick={() => setDisputeDetail(null)} className="p-2 hover:bg-gray-100 rounded-full"><X size={20} /></button></div>
                      <div className="space-y-4">
                        <div className="flex items-center gap-2"><span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColor(d.status)}`}>{d.status.replace('_', ' ')}</span><span className={`text-xs font-medium ${d.priority === 'high' ? 'text-red-600' : d.priority === 'medium' ? 'text-amber-600' : 'text-gray-600'}`}>{d.priority.toUpperCase()}</span></div>
                        <div className="bg-gray-50 rounded-lg p-4 space-y-2 text-sm">
                          <p><strong>Order:</strong> {d.orderId}</p>
                          <p><strong>Buyer:</strong> {d.buyer}</p>
                          <p><strong>Seller:</strong> {d.seller}</p>
                          <p><strong>Amount:</strong> Rs. {d.amount.toLocaleString()}</p>
                          <p><strong>Reason:</strong> {d.reason}</p>
                          <p><strong>Details:</strong> {d.description}</p>
                          <p><strong>Filed:</strong> {d.createdAt}</p>
                          {d.resolution && <p className="text-green-700 font-medium"><strong>Resolution:</strong> {d.resolution}</p>}
                        </div>
                        {/* Timeline */}
                        <div>
                          <h4 className="font-medium text-gray-900 mb-3">Resolution Timeline</h4>
                          <div className="space-y-3">
                            {['open','investigating','waiting_seller','proposed','resolved'].map((step, i) => {
                              const stepLabels: Record<string, string> = { open: 'Issue Reported — Payout paused', investigating: 'Under Review — Evidence collected', waiting_seller: 'Waiting on Seller Response', proposed: 'Solution Proposed to Buyer', resolved: 'Resolved — Action taken' };
                              const isActive = ['open','investigating','waiting_seller','proposed','resolved'].indexOf(d.status) >= i;
                              return (
                                <div key={step} className="flex items-start gap-3">
                                  <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 ${isActive ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-400'}`}>{isActive ? <CheckCircle2 size={14} /> : <span className="text-xs">{i + 1}</span>}</div>
                                  <p className={`text-sm ${isActive ? 'text-gray-900 font-medium' : 'text-gray-400'}`}>{stepLabels[step]}</p>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                        {d.status !== 'resolved' && (
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Resolution Note</label>
                            <textarea value={resolutionText} onChange={e => setResolutionText(e.target.value)} rows={2} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" placeholder="Describe the resolution..." />
                            <div className="flex gap-2 mt-3">
                              {d.status === 'open' && <button onClick={() => updateDisputeStatus(d.id, 'investigating')} className="px-3 py-1.5 bg-amber-600 text-white rounded-lg text-xs font-medium hover:bg-amber-700">Start Investigation</button>}
                              {d.status === 'investigating' && <button onClick={() => updateDisputeStatus(d.id, 'waiting_seller')} className="px-3 py-1.5 bg-blue-600 text-white rounded-lg text-xs font-medium hover:bg-blue-700">Request Seller Response</button>}
                              {(d.status === 'waiting_seller' || d.status === 'investigating') && <button onClick={() => updateDisputeStatus(d.id, 'proposed')} className="px-3 py-1.5 bg-purple-600 text-white rounded-lg text-xs font-medium hover:bg-purple-700">Propose Solution</button>}
                              <button onClick={() => updateDisputeStatus(d.id, 'resolved', resolutionText || 'Resolved by admin')} className="px-3 py-1.5 bg-green-600 text-white rounded-lg text-xs font-medium hover:bg-green-700">Resolve — Full Refund</button>
                              {d.status !== 'escalated' && <button onClick={() => updateDisputeStatus(d.id, 'escalated')} className="px-3 py-1.5 bg-red-100 text-red-700 rounded-lg text-xs font-medium hover:bg-red-200">Escalate</button>}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })()}

              <div className="space-y-4">
                {disputes.map(d => (
                  <div key={d.id} className={`bg-white rounded-xl shadow-sm p-4 border-l-4 ${d.priority === 'high' ? 'border-l-red-500' : d.priority === 'medium' ? 'border-l-amber-500' : 'border-l-gray-300'}`}>
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-semibold text-gray-900 text-sm">{d.id}</span>
                          <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColor(d.status)}`}>{d.status.replace('_', ' ')}</span>
                          <span className={`text-xs font-medium ${d.priority === 'high' ? 'text-red-600' : d.priority === 'medium' ? 'text-amber-600' : 'text-gray-600'}`}>{d.priority.toUpperCase()}</span>
                        </div>
                        <p className="text-gray-700 text-sm mt-1">{d.reason}</p>
                        <p className="text-gray-500 text-xs mt-1">{d.buyer} vs {d.seller} · Rs. {d.amount.toLocaleString()} · {d.createdAt}</p>
                        {d.resolution && <p className="text-green-700 text-xs mt-1 font-medium">✓ {d.resolution}</p>}
                      </div>
                      <button onClick={() => setDisputeDetail(d.id)} className="px-3 py-1.5 bg-red-600 text-white rounded-lg text-xs font-medium hover:bg-red-700 whitespace-nowrap">
                        {d.status === 'resolved' ? 'View' : 'Handle'}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}

          {/* SETTINGS */}
          {activeTab === 'settings' && (
            <div className="max-w-2xl space-y-6">
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2"><DollarSign size={18} />Commission & Fees</h3>
                <div className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">Platform Commission (%)</label><input type="number" value={platformSettings.commission} onChange={e => setPlatformSettings({...platformSettings, commission: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" /></div>
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">Min Trust Score for Selling (%)</label><input type="number" value={platformSettings.minTrustScore} onChange={e => setPlatformSettings({...platformSettings, minTrustScore: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" /></div>
                  </div>
                </div>
              </div>
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2"><Shield size={18} />Trust & Safety</h3>
                <div className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">Dispute Window (days)</label><input type="number" value={platformSettings.disputeWindow} onChange={e => setPlatformSettings({...platformSettings, disputeWindow: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" /></div>
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">Escrow Hold (hours)</label><input type="number" value={platformSettings.escrowHold} onChange={e => setPlatformSettings({...platformSettings, escrowHold: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" /></div>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">Max Listings per Seller</label><input type="number" value={platformSettings.maxListings} onChange={e => setPlatformSettings({...platformSettings, maxListings: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" /></div>
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">Auto-flag Report Threshold</label><input type="number" value={platformSettings.autoFlagThreshold} onChange={e => setPlatformSettings({...platformSettings, autoFlagThreshold: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" /></div>
                  </div>
                  <label className="flex items-center gap-3 cursor-pointer p-3 bg-gray-50 rounded-lg">
                    <input type="checkbox" checked={platformSettings.requirePhotos} onChange={e => setPlatformSettings({...platformSettings, requirePhotos: e.target.checked})} className="w-4 h-4 text-red-600 rounded" />
                    <div><p className="font-medium text-gray-900 text-sm">Require Real Photos</p><p className="text-xs text-gray-600">Block listings with stock or AI-generated photos</p></div>
                  </label>
                </div>
              </div>
              <div className="flex justify-end">
                <button onClick={handleSaveSettings} disabled={saving} className="bg-red-600 text-white px-6 py-2.5 rounded-lg font-medium hover:bg-red-700 flex items-center gap-2 disabled:opacity-70">
                  {saving ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <Save size={16} />}
                  {saving ? 'Saving...' : 'Save Settings'}
                </button>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
