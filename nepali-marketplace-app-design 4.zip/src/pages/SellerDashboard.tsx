import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  LayoutDashboard, Package, ShoppingCart, TrendingUp, Star, AlertTriangle,
  CheckCircle2, Clock, DollarSign, Bell, Settings, HelpCircle, LogOut,
  Plus, Eye, Edit, Trash2, Shield, Award, BookOpen,
  MessageCircle, ArrowUpRight, Menu, X, Search, Truck, Save,
  Camera, XCircle, MapPin, Phone, Mail,
  Building2, CreditCard, Upload, Image
} from 'lucide-react';
import { BrandLogo } from '@/components/BrandLogo';
import { useApp } from '@/context/AppContext';

type TabType = 'overview' | 'products' | 'orders' | 'analytics' | 'messages' | 'settings';

interface SellerProduct {
  id: string;
  name: string;
  image: string;
  price: number;
  originalPrice?: number;
  stock: number;
  status: 'active' | 'low_stock' | 'out_of_stock' | 'pending_review' | 'rejected';
  views: number;
  sales: number;
  category: string;
  description: string;
}

interface SellerOrder {
  id: string;
  product: string;
  customer: string;
  amount: number;
  status: 'pending' | 'confirmed' | 'shipped' | 'delivered' | 'disputed' | 'cancelled';
  date: string;
  address: string;
  phone: string;
}

interface Message {
  id: string;
  customer: string;
  subject: string;
  message: string;
  date: string;
  read: boolean;
  orderId?: string;
}

const initialProducts: SellerProduct[] = [
  { id: '1', name: 'Dhaka Topi - Premium Handwoven', image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=100', price: 850, originalPrice: 1100, stock: 15, status: 'active', views: 234, sales: 28, category: 'fashion', description: 'Authentic handwoven dhaka topi.' },
  { id: '2', name: 'Pashmina Shawl - Pure Cashmere', image: 'https://images.unsplash.com/photo-1601924994987-69e26d50dc26?w=100', price: 4500, stock: 3, status: 'low_stock', views: 567, sales: 45, category: 'fashion', description: 'Luxurious cashmere shawl.' },
  { id: '3', name: 'Singing Bowl - Handcrafted 5"', image: 'https://images.unsplash.com/photo-1545048702-79362596cdc9?w=100', price: 2800, stock: 0, status: 'out_of_stock', views: 189, sales: 12, category: 'home', description: 'Traditional singing bowl.' },
  { id: '4', name: 'Nepali Tea Gift Set', image: 'https://images.unsplash.com/photo-1555660681-b82784959e8f?w=100', price: 1200, stock: 20, status: 'pending_review', views: 0, sales: 0, category: 'home', description: 'Organic tea set from Ilam.' },
  { id: '5', name: 'Lokta Paper Notebook', image: 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=100', price: 350, stock: 50, status: 'active', views: 98, sales: 8, category: 'books', description: 'Handmade lokta paper notebook.' },
  { id: '6', name: 'Thangka Painting - Buddha', image: 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=100', price: 15000, stock: 5, status: 'active', views: 312, sales: 3, category: 'home', description: 'Hand-painted thangka art.' },
];

const initialOrders: SellerOrder[] = [
  { id: 'ORD-7823', product: 'Dhaka Topi Premium', customer: 'Ram Bahadur', amount: 850, status: 'pending', date: '2 hours ago', address: 'Thamel, Kathmandu', phone: '9841XXXXXX' },
  { id: 'ORD-7822', product: 'Pashmina Shawl', customer: 'Sita Kumari', amount: 4500, status: 'confirmed', date: '5 hours ago', address: 'Patan, Lalitpur', phone: '9842XXXXXX' },
  { id: 'ORD-7821', product: 'Singing Bowl Set', customer: 'John Doe', amount: 3200, status: 'shipped', date: '1 day ago', address: 'Lakeside, Pokhara', phone: '9843XXXXXX' },
  { id: 'ORD-7820', product: 'Thangka Painting', customer: 'Maya Tamang', amount: 15000, status: 'delivered', date: '2 days ago', address: 'New Road, Kathmandu', phone: '9844XXXXXX' },
  { id: 'ORD-7819', product: 'Lokta Paper Notebook', customer: 'Hari Prasad', amount: 650, status: 'disputed', date: '3 days ago', address: 'Bhaktapur', phone: '9845XXXXXX' },
  { id: 'ORD-7818', product: 'Dhaka Topi Premium', customer: 'Bina Shah', amount: 850, status: 'cancelled', date: '4 days ago', address: 'Biratnagar', phone: '9846XXXXXX' },
];

const initialMessages: Message[] = [
  { id: '1', customer: 'Ram Bahadur', subject: 'Size query', message: 'What sizes are available for the Dhaka Topi?', date: '10 min ago', read: false, orderId: 'ORD-7823' },
  { id: '2', customer: 'John Doe', subject: 'Shipping update', message: 'When can I expect delivery to Pokhara?', date: '2 hours ago', read: false },
  { id: '3', customer: 'Sita Kumari', subject: 'Custom order', message: 'Can I order a custom color pashmina?', date: '1 day ago', read: true },
  { id: '4', customer: 'Hari Prasad', subject: 'Dispute explanation', message: 'The notebook paper quality seems different from photos.', date: '3 days ago', read: true, orderId: 'ORD-7819' },
];

export function SellerDashboard() {
  const { addNotification } = useApp();
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sellerProducts, setSellerProducts] = useState(initialProducts);
  const [sellerOrders, setSellerOrders] = useState(initialOrders);
  const [messages, setMessages] = useState(initialMessages);
  const [orderFilter, setOrderFilter] = useState<string>('all');
  const [productSearch, setProductSearch] = useState('');
  const [showProductForm, setShowProductForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState<SellerProduct | null>(null);
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');
  const [productForm, setProductForm] = useState({ name: '', price: '', originalPrice: '', stock: '', category: 'fashion', description: '', image: 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=100' });
  const [saving, setSaving] = useState(false);

  // Store settings state
  const [storeSettings, setStoreSettings] = useState({
    name: 'Nepal Craft House',
    description: 'Authentic Nepali handicrafts and traditional items, handmade with love.',
    address: 'Thamel, Kathmandu',
    phone: '01-4567890',
    email: 'shop@nepalcraft.com',
    bankName: 'Nepal Rastra Bank',
    accountNumber: '0123456789',
    accountName: 'Nepal Craft House Pvt Ltd',
    shippingPolicy: 'We ship within 24 hours of order confirmation. Free shipping on orders above Rs. 2000.',
    returnPolicy: '7-day return policy for damaged or wrong items.',
    handlingTime: '1-2',
  });

  // Computed stats
  const stats = {
    totalSales: sellerOrders.filter(o => o.status === 'delivered').reduce((s, o) => s + o.amount, 0),
    thisMonth: sellerOrders.filter(o => o.status !== 'cancelled').reduce((s, o) => s + o.amount, 0),
    pendingOrders: sellerOrders.filter(o => o.status === 'pending').length,
    totalProducts: sellerProducts.filter(p => p.status === 'active' || p.status === 'low_stock').length,
    trustScore: 94,
    unreadMessages: messages.filter(m => !m.read).length,
    disputeCount: sellerOrders.filter(o => o.status === 'disputed').length,
    totalViews: sellerProducts.reduce((s, p) => s + p.views, 0),
    totalUnitsSold: sellerProducts.reduce((s, p) => s + p.sales, 0),
  };

  const filteredOrders = orderFilter === 'all' ? sellerOrders : sellerOrders.filter(o => o.status === orderFilter);
  const filteredProducts = productSearch ? sellerProducts.filter(p => p.name.toLowerCase().includes(productSearch.toLowerCase())) : sellerProducts;

  // Order actions
  const updateOrderStatus = (orderId: string, newStatus: SellerOrder['status']) => {
    setSellerOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: newStatus } : o));
    addNotification('success', 'Order Updated', `Order ${orderId} status changed to ${newStatus}.`);
  };

  // Product actions
  const handleSaveProduct = () => {
    if (editingProduct) {
      setSellerProducts(prev => prev.map(p => p.id === editingProduct.id ? { ...p, name: productForm.name, price: Number(productForm.price), originalPrice: productForm.originalPrice ? Number(productForm.originalPrice) : undefined, stock: Number(productForm.stock), category: productForm.category, description: productForm.description } : p));
      addNotification('success', 'Product Updated', `"${productForm.name}" has been updated.`);
    } else {
      const newProduct: SellerProduct = { id: `p-${Date.now()}`, name: productForm.name, image: productForm.image, price: Number(productForm.price), originalPrice: productForm.originalPrice ? Number(productForm.originalPrice) : undefined, stock: Number(productForm.stock), status: 'pending_review', views: 0, sales: 0, category: productForm.category, description: productForm.description };
      setSellerProducts(prev => [newProduct, ...prev]);
      addNotification('success', 'Product Added', `"${productForm.name}" has been submitted for review.`);
    }
    setShowProductForm(false);
    setEditingProduct(null);
    setProductForm({ name: '', price: '', originalPrice: '', stock: '', category: 'fashion', description: '', image: 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=100' });
  };

  const startEditProduct = (product: SellerProduct) => {
    setEditingProduct(product);
    setProductForm({ name: product.name, price: String(product.price), originalPrice: product.originalPrice ? String(product.originalPrice) : '', stock: String(product.stock), category: product.category, description: product.description, image: product.image });
    setShowProductForm(true);
  };

  const deleteProduct = (id: string) => {
    setSellerProducts(prev => prev.filter(p => p.id !== id));
    addNotification('info', 'Product Removed', 'Product has been deleted.');
  };

  const toggleProductStatus = (id: string) => {
    setSellerProducts(prev => prev.map(p => p.id === id ? { ...p, status: p.status === 'active' ? 'out_of_stock' : 'active' } : p));
  };

  // Message actions
  const markAsRead = (id: string) => setMessages(prev => prev.map(m => m.id === id ? { ...m, read: true } : m));

  const sendReply = (id: string) => {
    if (!replyText.trim()) return;
    markAsRead(id);
    setReplyingTo(null);
    setReplyText('');
    addNotification('success', 'Reply Sent', 'Your reply has been sent to the customer.');
  };

  const handleSaveSettings = async () => {
    setSaving(true);
    await new Promise(r => setTimeout(r, 800));
    setSaving(false);
    addNotification('success', 'Settings Saved', 'Your store settings have been updated.');
  };

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = { pending: 'bg-amber-100 text-amber-800', confirmed: 'bg-blue-100 text-blue-800', shipped: 'bg-purple-100 text-purple-800', delivered: 'bg-green-100 text-green-800', disputed: 'bg-red-100 text-red-800', cancelled: 'bg-gray-100 text-gray-800', active: 'bg-green-100 text-green-800', low_stock: 'bg-amber-100 text-amber-800', out_of_stock: 'bg-red-100 text-red-800', pending_review: 'bg-blue-100 text-blue-800', rejected: 'bg-red-100 text-red-800' };
    return colors[status] || 'bg-gray-100 text-gray-800';
  };

  const navItems = [
    { id: 'overview', icon: LayoutDashboard, label: 'Overview' },
    { id: 'products', icon: Package, label: 'Products', badge: sellerProducts.filter(p => p.status === 'pending_review').length },
    { id: 'orders', icon: ShoppingCart, label: 'Orders', badge: stats.pendingOrders },
    { id: 'messages', icon: MessageCircle, label: 'Messages', badge: stats.unreadMessages },
    { id: 'analytics', icon: TrendingUp, label: 'Analytics' },
    { id: 'settings', icon: Settings, label: 'Settings' },
  ];

  // Analytics data for chart
  const monthlyData = [
    { month: 'Jan', sales: 12000 }, { month: 'Feb', sales: 18000 }, { month: 'Mar', sales: 15000 },
    { month: 'Apr', sales: 22000 }, { month: 'May', sales: 28000 }, { month: 'Jun', sales: 34500 },
  ];
  const maxSales = Math.max(...monthlyData.map(d => d.sales));

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      {sidebarOpen && <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />}
      <aside className={`fixed inset-y-0 left-0 z-50 w-64 bg-white border-r border-gray-200 transform transition-transform lg:translate-x-0 lg:static ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex flex-col h-full">
          <div className="p-4 border-b border-gray-100 flex items-center justify-between">
            <Link to="/"><BrandLogo /></Link>
            <button onClick={() => setSidebarOpen(false)} className="lg:hidden p-2 hover:bg-gray-100 rounded-lg"><X size={20} /></button>
          </div>
          <div className="p-4 border-b border-gray-100">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center text-white font-bold text-lg">NC</div>
              <div>
                <h3 className="font-semibold text-gray-900 text-sm">{storeSettings.name}</h3>
                <div className="flex items-center gap-1 text-xs"><CheckCircle2 size={12} className="text-green-600" /><span className="text-green-700">Verified</span></div>
              </div>
            </div>
            <div className="mt-3 bg-green-50 rounded-lg p-2 flex items-center justify-between">
              <span className="text-sm text-green-800">Trust Score</span>
              <span className="font-bold text-green-700">{stats.trustScore}%</span>
            </div>
          </div>
          <nav className="flex-1 p-3 space-y-1 overflow-auto">
            {navItems.map(item => (
              <button key={item.id} onClick={() => { setActiveTab(item.id as TabType); setSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${activeTab === item.id ? 'bg-red-50 text-red-700' : 'text-gray-600 hover:bg-gray-100'}`}>
                <item.icon size={18} />
                {item.label}
                {item.badge ? <span className="ml-auto bg-red-600 text-white text-xs px-1.5 py-0.5 rounded-full">{item.badge}</span> : null}
              </button>
            ))}
          </nav>
          <div className="p-3 border-t border-gray-100">
            <div className="bg-blue-50 rounded-xl p-3 mb-2">
              <div className="flex items-center gap-2 text-blue-800 font-medium text-sm mb-1"><BookOpen size={16} />Seller Tips</div>
              <p className="text-xs text-blue-700">Ship within 24h to improve your Trust Score.</p>
            </div>
            <Link to="/settings" className="w-full flex items-center gap-3 px-3 py-2 text-gray-600 hover:bg-gray-100 rounded-lg text-sm"><HelpCircle size={18} />Help Center</Link>
            <Link to="/" className="w-full flex items-center gap-3 px-3 py-2 text-gray-600 hover:bg-gray-100 rounded-lg text-sm"><LogOut size={18} />Back to Store</Link>
          </div>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        <header className="bg-white border-b border-gray-200 px-4 lg:px-6 py-3 flex items-center justify-between sticky top-0 z-30">
          <div className="flex items-center gap-3">
            <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-2 hover:bg-gray-100 rounded-lg"><Menu size={20} /></button>
            <h1 className="text-lg font-bold text-gray-900 hidden sm:block">{navItems.find(n => n.id === activeTab)?.label}</h1>
          </div>
          <div className="flex items-center gap-2">
            <button className="relative p-2 hover:bg-gray-100 rounded-full"><Bell size={20} className="text-gray-600" />{stats.unreadMessages > 0 && <span className="absolute top-1 right-1 w-2 h-2 bg-red-600 rounded-full" />}</button>
            <Link to="/settings" className="p-2 hover:bg-gray-100 rounded-full"><Settings size={20} className="text-gray-600" /></Link>
          </div>
        </header>

        <main className="flex-1 p-4 lg:p-6 overflow-auto">
          {/* Warning Banner */}
          {stats.disputeCount > 0 && (
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6 flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <h4 className="font-medium text-amber-900">Action Required: {stats.disputeCount} Active Dispute(s)</h4>
                <p className="text-sm text-amber-800 mt-1">Respond within 48 hours to avoid penalties to your Trust Score.</p>
              </div>
              <button onClick={() => { setActiveTab('orders'); setOrderFilter('disputed'); }} className="text-sm font-semibold text-amber-900 hover:underline whitespace-nowrap">View →</button>
            </div>
          )}

          {/* OVERVIEW */}
          {activeTab === 'overview' && (
            <>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                {[
                  { label: 'Revenue', value: `Rs. ${(stats.thisMonth / 1000).toFixed(1)}K`, icon: DollarSign, color: 'bg-green-100 text-green-600', change: '+12%' },
                  { label: 'Pending', value: stats.pendingOrders, icon: Clock, color: 'bg-amber-100 text-amber-600' },
                  { label: 'Products', value: stats.totalProducts, icon: Package, color: 'bg-blue-100 text-blue-600' },
                  { label: 'Rating', value: '4.8', icon: Star, color: 'bg-purple-100 text-purple-600' },
                ].map((s, i) => (
                  <div key={i} className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
                    <div className="flex items-center justify-between">
                      <div className={`w-10 h-10 ${s.color} rounded-lg flex items-center justify-center`}><s.icon className="w-5 h-5" /></div>
                      {s.change && <span className="flex items-center gap-1 text-xs text-green-600"><ArrowUpRight size={14} />{s.change}</span>}
                    </div>
                    <p className="text-2xl font-bold text-gray-900 mt-3">{s.value}</p>
                    <p className="text-sm text-gray-600">{s.label}</p>
                  </div>
                ))}
              </div>

              {/* Trust Score */}
              <div className="bg-gradient-to-r from-green-600 to-green-700 rounded-xl p-6 mb-6 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-2"><Shield className="w-6 h-6" /><h3 className="text-lg font-semibold">Your Trust Score</h3></div>
                    <div className="text-4xl font-bold mb-1">{stats.trustScore}%</div>
                    <p className="text-green-100">Excellent! You're a top-rated seller.</p>
                  </div>
                  <Award className="w-16 h-16 text-green-300 hidden md:block" />
                </div>
                <div className="mt-4 grid grid-cols-3 gap-3">
                  <div className="bg-white/10 rounded-lg p-3"><p className="text-green-100 text-xs">Response</p><p className="text-xl font-bold">98%</p></div>
                  <div className="bg-white/10 rounded-lg p-3"><p className="text-green-100 text-xs">On-time</p><p className="text-xl font-bold">96%</p></div>
                  <div className="bg-white/10 rounded-lg p-3"><p className="text-green-100 text-xs">Disputes</p><p className="text-xl font-bold">0.5%</p></div>
                </div>
              </div>

              {/* Recent Orders */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                <div className="p-4 border-b border-gray-100 flex items-center justify-between">
                  <h3 className="font-semibold text-gray-900">Recent Orders</h3>
                  <button onClick={() => setActiveTab('orders')} className="text-red-600 text-sm font-medium hover:underline">View All</button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50"><tr>
                      {['Order','Product','Customer','Amount','Status','Action'].map(h => <th key={h} className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase">{h}</th>)}
                    </tr></thead>
                    <tbody className="divide-y divide-gray-100">
                      {sellerOrders.slice(0, 5).map(order => (
                        <tr key={order.id} className="hover:bg-gray-50">
                          <td className="px-4 py-3 font-medium text-gray-900 text-sm">{order.id}</td>
                          <td className="px-4 py-3 text-gray-600 text-sm">{order.product}</td>
                          <td className="px-4 py-3 text-gray-600 text-sm">{order.customer}</td>
                          <td className="px-4 py-3 font-medium text-sm">Rs. {order.amount.toLocaleString()}</td>
                          <td className="px-4 py-3"><span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>{order.status}</span></td>
                          <td className="px-4 py-3">
                            {order.status === 'pending' && <button onClick={() => updateOrderStatus(order.id, 'confirmed')} className="text-blue-600 text-xs font-medium hover:underline">Confirm</button>}
                            {order.status === 'confirmed' && <button onClick={() => updateOrderStatus(order.id, 'shipped')} className="text-purple-600 text-xs font-medium hover:underline">Ship</button>}
                            {order.status === 'disputed' && <button onClick={() => { setActiveTab('orders'); setOrderFilter('disputed'); }} className="text-red-600 text-xs font-medium hover:underline">Respond</button>}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}

          {/* PRODUCTS */}
          {activeTab === 'products' && (
            <>
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
                <div className="relative flex-1 max-w-sm">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input type="text" value={productSearch} onChange={e => setProductSearch(e.target.value)} placeholder="Search products..." className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm" />
                </div>
                <button onClick={() => { setEditingProduct(null); setProductForm({ name: '', price: '', originalPrice: '', stock: '', category: 'fashion', description: '', image: 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=100' }); setShowProductForm(true); }}
                  className="bg-red-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-red-700 flex items-center gap-2 text-sm"><Plus size={16} />Add Product</button>
              </div>

              {/* Listing tips */}
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6 flex items-start gap-3">
                <Camera className="w-5 h-5 text-blue-600 mt-0.5" />
                <div className="text-sm text-blue-800">
                  <p className="font-medium">Listing Tips to Increase Sales:</p>
                  <p className="mt-1">✓ Use 4+ real photos (front, back, label, detail) ✓ Accurate size & weight ✓ Honest condition notes for better trust scores</p>
                </div>
              </div>

              {/* Product Form Modal */}
              {showProductForm && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
                  <div className="bg-white rounded-2xl max-w-lg w-full p-6 max-h-[90vh] overflow-y-auto">
                    <div className="flex items-center justify-between mb-6">
                      <h2 className="text-lg font-bold text-gray-900">{editingProduct ? 'Edit Product' : 'Add New Product'}</h2>
                      <button onClick={() => setShowProductForm(false)} className="p-2 hover:bg-gray-100 rounded-full"><X size={20} /></button>
                    </div>
                    <div className="space-y-4">
                      <div className="flex items-center gap-4">
                        <div className="w-20 h-20 bg-gray-100 rounded-xl flex items-center justify-center border-2 border-dashed border-gray-300">
                          {productForm.image ? <img src={productForm.image} className="w-full h-full object-cover rounded-xl" /> : <Image size={24} className="text-gray-400" />}
                        </div>
                        <div><button className="text-sm text-red-600 font-medium flex items-center gap-1"><Upload size={14} />Upload Photos</button><p className="text-xs text-gray-500 mt-1">Real photos only. 4+ recommended.</p></div>
                      </div>
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">Product Name *</label><input type="text" value={productForm.name} onChange={e => setProductForm({...productForm, name: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" placeholder="e.g. Handwoven Dhaka Topi" /></div>
                      <div className="grid grid-cols-2 gap-4">
                        <div><label className="block text-sm font-medium text-gray-700 mb-1">Price (Rs.) *</label><input type="number" value={productForm.price} onChange={e => setProductForm({...productForm, price: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" /></div>
                        <div><label className="block text-sm font-medium text-gray-700 mb-1">Original Price</label><input type="number" value={productForm.originalPrice} onChange={e => setProductForm({...productForm, originalPrice: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" placeholder="Optional" /></div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div><label className="block text-sm font-medium text-gray-700 mb-1">Stock *</label><input type="number" value={productForm.stock} onChange={e => setProductForm({...productForm, stock: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" /></div>
                        <div><label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                          <select value={productForm.category} onChange={e => setProductForm({...productForm, category: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                            <option value="fashion">Fashion</option><option value="home">Home & Kitchen</option><option value="electronics">Electronics</option><option value="beauty">Beauty</option><option value="books">Books</option><option value="sports">Sports</option>
                          </select>
                        </div>
                      </div>
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">Description *</label><textarea value={productForm.description} onChange={e => setProductForm({...productForm, description: e.target.value})} rows={3} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" placeholder="Describe your product in detail..." /></div>
                    </div>
                    <div className="mt-6 flex gap-3 justify-end">
                      <button onClick={() => setShowProductForm(false)} className="px-4 py-2 bg-gray-100 rounded-lg text-sm font-medium hover:bg-gray-200">Cancel</button>
                      <button onClick={handleSaveProduct} disabled={!productForm.name || !productForm.price || !productForm.stock}
                        className="px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-medium hover:bg-red-700 disabled:opacity-50 flex items-center gap-2"><Save size={14} />{editingProduct ? 'Save Changes' : 'Submit for Review'}</button>
                    </div>
                  </div>
                </div>
              )}

              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredProducts.map(product => (
                  <div key={product.id} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                    <div className="relative">
                      <img src={product.image} alt={product.name} className="w-full h-36 object-cover" />
                      <span className={`absolute top-2 right-2 px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColor(product.status)}`}>
                        {product.status.replace('_', ' ')}
                      </span>
                    </div>
                    <div className="p-4">
                      <h4 className="font-medium text-gray-900 line-clamp-1 text-sm">{product.name}</h4>
                      <p className="text-lg font-bold text-gray-900 mt-1">Rs. {product.price.toLocaleString()}
                        {product.originalPrice && <span className="text-sm text-gray-400 line-through ml-2">Rs. {product.originalPrice.toLocaleString()}</span>}
                      </p>
                      <div className="flex items-center gap-4 mt-2 text-xs text-gray-600">
                        <span className="flex items-center gap-1"><Eye size={12} />{product.views}</span>
                        <span className="flex items-center gap-1"><ShoppingCart size={12} />{product.sales} sold</span>
                        <span className={product.stock === 0 ? 'text-red-600 font-medium' : product.stock <= 5 ? 'text-amber-600 font-medium' : ''}>Stock: {product.stock}</span>
                      </div>
                      <div className="flex items-center gap-2 mt-3">
                        <button onClick={() => startEditProduct(product)} className="flex-1 bg-gray-100 text-gray-700 py-1.5 rounded-lg text-xs font-medium hover:bg-gray-200 flex items-center justify-center gap-1"><Edit size={12} />Edit</button>
                        <button onClick={() => toggleProductStatus(product.id)} className="flex-1 bg-gray-100 text-gray-700 py-1.5 rounded-lg text-xs font-medium hover:bg-gray-200 flex items-center justify-center gap-1">
                          {product.status === 'active' || product.status === 'low_stock' ? <><XCircle size={12} />Disable</> : <><CheckCircle2 size={12} />Enable</>}
                        </button>
                        <button onClick={() => deleteProduct(product.id)} className="p-1.5 hover:bg-red-50 rounded-lg text-red-500"><Trash2 size={16} /></button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              {filteredProducts.length === 0 && <div className="text-center py-12 text-gray-500"><Package className="w-12 h-12 mx-auto mb-3 text-gray-300" /><p>No products found.</p></div>}
            </>
          )}

          {/* ORDERS */}
          {activeTab === 'orders' && (
            <>
              <div className="flex flex-wrap gap-2 mb-6">
                {['all','pending','confirmed','shipped','delivered','disputed','cancelled'].map(f => (
                  <button key={f} onClick={() => setOrderFilter(f)}
                    className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${orderFilter === f ? 'bg-red-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-100 border border-gray-200'}`}>
                    {f.charAt(0).toUpperCase() + f.slice(1)}
                    {f !== 'all' && <span className="ml-1 opacity-70">({sellerOrders.filter(o => o.status === f).length})</span>}
                  </button>
                ))}
              </div>

              <div className="space-y-4">
                {filteredOrders.map(order => (
                  <div key={order.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-gray-900">{order.id}</span>
                          <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>{order.status}</span>
                        </div>
                        <p className="text-gray-600 text-sm mt-1">{order.product} · Rs. {order.amount.toLocaleString()}</p>
                        <p className="text-gray-500 text-xs mt-1">{order.customer} · {order.address} · {order.phone}</p>
                        <p className="text-gray-400 text-xs mt-1">{order.date}</p>
                      </div>
                      <div className="flex gap-2">
                        {order.status === 'pending' && (
                          <>
                            <button onClick={() => updateOrderStatus(order.id, 'confirmed')} className="px-3 py-1.5 bg-blue-600 text-white rounded-lg text-xs font-medium hover:bg-blue-700 flex items-center gap-1"><CheckCircle2 size={14} />Confirm</button>
                            <button onClick={() => updateOrderStatus(order.id, 'cancelled')} className="px-3 py-1.5 bg-gray-100 text-gray-600 rounded-lg text-xs font-medium hover:bg-gray-200">Cancel</button>
                          </>
                        )}
                        {order.status === 'confirmed' && (
                          <button onClick={() => updateOrderStatus(order.id, 'shipped')} className="px-3 py-1.5 bg-purple-600 text-white rounded-lg text-xs font-medium hover:bg-purple-700 flex items-center gap-1"><Truck size={14} />Mark Shipped</button>
                        )}
                        {order.status === 'shipped' && (
                          <button onClick={() => updateOrderStatus(order.id, 'delivered')} className="px-3 py-1.5 bg-green-600 text-white rounded-lg text-xs font-medium hover:bg-green-700 flex items-center gap-1"><CheckCircle2 size={14} />Mark Delivered</button>
                        )}
                        {order.status === 'disputed' && (
                          <button onClick={() => { setReplyingTo(order.id); setActiveTab('messages'); }} className="px-3 py-1.5 bg-red-600 text-white rounded-lg text-xs font-medium hover:bg-red-700 flex items-center gap-1"><MessageCircle size={14} />Respond</button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
                {filteredOrders.length === 0 && <div className="text-center py-12 text-gray-500"><ShoppingCart className="w-12 h-12 mx-auto mb-3 text-gray-300" /><p>No orders found for this filter.</p></div>}
              </div>
            </>
          )}

          {/* MESSAGES */}
          {activeTab === 'messages' && (
            <div className="space-y-4">
              {messages.map(msg => (
                <div key={msg.id} className={`bg-white rounded-xl shadow-sm border ${msg.read ? 'border-gray-100' : 'border-blue-200 bg-blue-50/30'} p-4`}>
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex gap-3">
                      <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center font-medium text-gray-600">{msg.customer.charAt(0)}</div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-gray-900">{msg.customer}</span>
                          {!msg.read && <span className="w-2 h-2 bg-blue-600 rounded-full" />}
                          {msg.orderId && <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded">{msg.orderId}</span>}
                        </div>
                        <p className="font-medium text-gray-800 text-sm mt-0.5">{msg.subject}</p>
                        <p className="text-gray-600 text-sm mt-1">{msg.message}</p>
                        <p className="text-gray-400 text-xs mt-2">{msg.date}</p>

                        {replyingTo === msg.id && (
                          <div className="mt-3 flex gap-2">
                            <input type="text" value={replyText} onChange={e => setReplyText(e.target.value)} placeholder="Type your reply..."
                              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm" onKeyDown={e => e.key === 'Enter' && sendReply(msg.id)} />
                            <button onClick={() => sendReply(msg.id)} className="px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-medium hover:bg-red-700">Send</button>
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      {!msg.read && <button onClick={() => markAsRead(msg.id)} className="text-xs text-gray-500 hover:underline">Mark read</button>}
                      <button onClick={() => { setReplyingTo(replyingTo === msg.id ? null : msg.id); markAsRead(msg.id); }} className="text-xs text-red-600 font-medium hover:underline">Reply</button>
                    </div>
                  </div>
                </div>
              ))}
              {messages.length === 0 && <div className="text-center py-12 text-gray-500"><MessageCircle className="w-12 h-12 mx-auto mb-3 text-gray-300" /><p>No messages yet.</p></div>}
            </div>
          )}

          {/* ANALYTICS */}
          {activeTab === 'analytics' && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { label: 'Total Revenue', value: `Rs. ${(stats.totalSales / 1000).toFixed(0)}K`, icon: DollarSign },
                  { label: 'Total Views', value: stats.totalViews.toLocaleString(), icon: Eye },
                  { label: 'Units Sold', value: stats.totalUnitsSold, icon: Package },
                  { label: 'Conversion', value: `${((stats.totalUnitsSold / Math.max(stats.totalViews, 1)) * 100).toFixed(1)}%`, icon: TrendingUp },
                ].map((s, i) => (
                  <div key={i} className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
                    <s.icon className="w-5 h-5 text-gray-400 mb-2" />
                    <p className="text-2xl font-bold text-gray-900">{s.value}</p>
                    <p className="text-sm text-gray-600">{s.label}</p>
                  </div>
                ))}
              </div>

              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 className="font-semibold text-gray-900 mb-6">Monthly Sales</h3>
                <div className="flex items-end gap-4 h-48">
                  {monthlyData.map(d => (
                    <div key={d.month} className="flex-1 flex flex-col items-center gap-2">
                      <span className="text-xs font-medium text-gray-900">Rs.{(d.sales / 1000).toFixed(0)}K</span>
                      <div className="w-full bg-gradient-to-t from-red-500 to-red-400 rounded-t-lg transition-all" style={{ height: `${(d.sales / maxSales) * 100}%`, minHeight: 8 }} />
                      <span className="text-xs text-gray-500">{d.month}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 className="font-semibold text-gray-900 mb-4">Top Products by Sales</h3>
                <div className="space-y-3">
                  {[...sellerProducts].sort((a, b) => b.sales - a.sales).slice(0, 5).map((p, i) => (
                    <div key={p.id} className="flex items-center gap-3">
                      <span className="w-6 h-6 bg-red-100 text-red-700 rounded-full flex items-center justify-center text-xs font-medium">{i + 1}</span>
                      <img src={p.image} alt="" className="w-10 h-10 rounded-lg object-cover" />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-gray-900 truncate text-sm">{p.name}</p>
                        <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1"><div className="bg-red-500 h-1.5 rounded-full" style={{ width: `${(p.sales / Math.max(...sellerProducts.map(x => x.sales), 1)) * 100}%` }} /></div>
                      </div>
                      <span className="text-sm font-medium text-gray-600">{p.sales} sold</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* SETTINGS */}
          {activeTab === 'settings' && (
            <div className="max-w-2xl space-y-6">
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2"><Building2 size={18} />Store Information</h3>
                <div className="space-y-4">
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">Store Name</label><input type="text" value={storeSettings.name} onChange={e => setStoreSettings({...storeSettings, name: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" /></div>
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">Description</label><textarea value={storeSettings.description} onChange={e => setStoreSettings({...storeSettings, description: e.target.value})} rows={3} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" /></div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div><label className="block text-sm font-medium text-gray-700 mb-1"><MapPin size={14} className="inline mr-1" />Address</label><input type="text" value={storeSettings.address} onChange={e => setStoreSettings({...storeSettings, address: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" /></div>
                    <div><label className="block text-sm font-medium text-gray-700 mb-1"><Phone size={14} className="inline mr-1" />Phone</label><input type="tel" value={storeSettings.phone} onChange={e => setStoreSettings({...storeSettings, phone: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" /></div>
                  </div>
                  <div><label className="block text-sm font-medium text-gray-700 mb-1"><Mail size={14} className="inline mr-1" />Email</label><input type="email" value={storeSettings.email} onChange={e => setStoreSettings({...storeSettings, email: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" /></div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2"><CreditCard size={18} />Payment/Bank Details</h3>
                <div className="space-y-4">
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">Bank Name</label><input type="text" value={storeSettings.bankName} onChange={e => setStoreSettings({...storeSettings, bankName: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" /></div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">Account Number</label><input type="text" value={storeSettings.accountNumber} onChange={e => setStoreSettings({...storeSettings, accountNumber: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" /></div>
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">Account Name</label><input type="text" value={storeSettings.accountName} onChange={e => setStoreSettings({...storeSettings, accountName: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" /></div>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2"><Truck size={18} />Shipping & Returns</h3>
                <div className="space-y-4">
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">Handling Time (days)</label>
                    <select value={storeSettings.handlingTime} onChange={e => setStoreSettings({...storeSettings, handlingTime: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                      <option value="1">Same day</option><option value="1-2">1-2 days</option><option value="2-3">2-3 days</option><option value="3-5">3-5 days</option>
                    </select>
                  </div>
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">Shipping Policy</label><textarea value={storeSettings.shippingPolicy} onChange={e => setStoreSettings({...storeSettings, shippingPolicy: e.target.value})} rows={2} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" /></div>
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">Return Policy</label><textarea value={storeSettings.returnPolicy} onChange={e => setStoreSettings({...storeSettings, returnPolicy: e.target.value})} rows={2} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" /></div>
                </div>
              </div>

              <div className="flex justify-end">
                <button onClick={handleSaveSettings} disabled={saving} className="bg-red-600 text-white px-6 py-2.5 rounded-lg font-medium hover:bg-red-700 flex items-center gap-2 disabled:opacity-70">
                  {saving ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <Save size={16} />}
                  {saving ? 'Saving...' : 'Save Settings'}
                </button>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
