import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  User, Shield, Bell, MapPin, CreditCard, ArrowLeft,
  Eye, EyeOff, Camera, Save, Plus, Trash2, CheckCircle2,
  Lock, Mail, Phone, Settings, Smartphone, Globe, Moon, Sun,
  Store, Building2, Truck, FileText, Award, DollarSign,
  AlertTriangle, Upload, Image, RefreshCw,
  Palette, Key, Download, LogOut,
  X, History,
  ShoppingBag, Zap, ExternalLink
} from 'lucide-react';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { useApp } from '@/context/AppContext';

// Shared Toggle component
const Toggle = ({ checked, onChange, disabled = false }: { checked: boolean; onChange: (v: boolean) => void; disabled?: boolean }) => (
  <button
    onClick={() => !disabled && onChange(!checked)}
    className={`relative w-12 h-6 rounded-full transition-colors ${checked ? 'bg-red-600' : 'bg-gray-300'} ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
  >
    <span className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${checked ? 'translate-x-6' : ''}`} />
  </button>
);

// ========== TYPES ==========
interface Address {
  id: string; label: string; fullName: string; phone: string; address: string; city: string; landmark: string; isDefault: boolean;
}
interface PaymentMethod {
  id: string; type: 'esewa' | 'khalti' | 'bank' | 'cod'; label: string; detail: string; isDefault: boolean;
}
interface LoginActivity {
  id: string; device: string; location: string; date: string; ip: string; current: boolean;
}

// ========== MAIN COMPONENT ==========
export function SettingsPage() {
  const { state, addNotification, dispatch, logout } = useApp();
  const navigate = useNavigate();
  const user = state.user;
  const userType = user?.type || 'customer';

  // Active tab
  const [activeTab, setActiveTab] = useState('profile');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteConfirmText, setDeleteConfirmText] = useState('');
  const [showExportModal, setShowExportModal] = useState(false);

  // ========== PROFILE STATE ==========
  const [profile, setProfile] = useState({
    name: user?.name || 'Guest User',
    email: user?.email || 'guest@example.com',
    phone: user?.phone || '98XXXXXXXX',
    bio: '',
    language: 'en',
    theme: 'light',
    avatar: '',
    dateOfBirth: '',
    gender: '',
    location: 'Kathmandu',
  });

  // ========== SECURITY STATE ==========
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [passwords, setPasswords] = useState({ current: '', newPass: '', confirm: '' });
  const [twoFA, setTwoFA] = useState(false);
  const [loginAlerts, setLoginAlerts] = useState(true);
  const [sessionTimeout, setSessionTimeout] = useState('30');
  const [loginActivities] = useState<LoginActivity[]>([
    { id: '1', device: 'Chrome on Windows', location: 'Kathmandu, Nepal', date: 'Now', ip: '103.xx.xx.xx', current: true },
    { id: '2', device: 'Safari on iPhone', location: 'Lalitpur, Nepal', date: '2 hours ago', ip: '103.xx.xx.xx', current: false },
    { id: '3', device: 'Firefox on MacOS', location: 'Pokhara, Nepal', date: '3 days ago', ip: '27.xx.xx.xx', current: false },
  ]);

  // ========== NOTIFICATION STATE ==========
  const [notifPrefs, setNotifPrefs] = useState({
    orderUpdates: true, promotions: false, priceDrops: true, sellerMessages: true,
    disputeUpdates: true, newsletter: false, pushEnabled: true, emailEnabled: true,
    smsEnabled: false, securityAlerts: true, reviewReminders: true,
    // Seller-specific
    newOrders: true, lowStock: true, payoutNotif: true, sellerTips: true,
    // Admin-specific
    newDisputes: true, sellerApps: true, systemAlerts: true, dailyReport: true,
  });

  // ========== ADDRESS STATE ==========
  const [addresses, setAddresses] = useState<Address[]>([
    { id: '1', label: 'Home', fullName: user?.name || 'Guest', phone: '9841234567', address: 'Thamel, Street 5', city: 'Kathmandu', landmark: 'Near Garden of Dreams', isDefault: true },
    { id: '2', label: 'Office', fullName: user?.name || 'Guest', phone: '9841234568', address: 'New Baneshwor, Everest Tower', city: 'Kathmandu', landmark: 'Opposite Civil Mall', isDefault: false },
  ]);
  const [editingAddress, setEditingAddress] = useState<Address | null>(null);
  const [showAddressForm, setShowAddressForm] = useState(false);
  const [addressForm, setAddressForm] = useState<Omit<Address, 'id' | 'isDefault'>>({ label: '', fullName: '', phone: '', address: '', city: '', landmark: '' });

  // ========== PAYMENT STATE ==========
  const [payments, setPayments] = useState<PaymentMethod[]>([
    { id: '1', type: 'esewa', label: 'eSewa Wallet', detail: '98412XXXXX', isDefault: true },
    { id: '2', type: 'khalti', label: 'Khalti', detail: '98412XXXXX', isDefault: false },
  ]);
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [paymentForm, setPaymentForm] = useState({ type: 'esewa' as PaymentMethod['type'], label: '', detail: '' });

  // ========== SELLER STORE STATE ==========
  const [storeSettings, setStoreSettings] = useState({
    storeName: 'Nepal Craft House', description: 'Authentic Nepali handicrafts and traditional items, handmade with love.',
    storeAddress: 'Thamel, Kathmandu', storePhone: '01-4567890', storeEmail: 'shop@nepalcraft.com',
    category: 'handicrafts', website: '', panNumber: '12345678', vatRegistered: true,
    logo: '', banner: '',
  });
  const [bankSettings, setBankSettings] = useState({
    bankName: 'Nepal Rastra Bank', accountNumber: '01234567890', accountName: 'Nepal Craft House Pvt Ltd',
    branchName: 'Thamel Branch', swiftCode: 'NRBNNPKA',
    esewaId: '9841234567', khaltiId: '9841234567', payoutFrequency: 'weekly', minPayout: '1000',
  });
  const [shippingSettings, setShippingSettings] = useState({
    handlingTime: '1-2', freeShippingThreshold: '2000',
    shippingPolicy: 'We ship within 24 hours of order confirmation. Free shipping on orders above Rs. 2000.',
    returnPolicy: '7-day return policy for damaged or wrong items. Buyer must send photos of the issue within 24 hours.',
    returnWindow: '7', autoAcceptReturns: false,
    shippingZones: [
      { zone: 'Inside Valley', price: '100', days: '1-2' },
      { zone: 'Outside Valley', price: '200', days: '3-5' },
      { zone: 'Remote Areas', price: '350', days: '5-7' },
    ],
  });
  const [verificationStatus] = useState({
    email: true, phone: true, identity: true, pan: true, bank: true, address: false,
  });

  // ========== ADMIN PLATFORM STATE ==========
  const [platformSettings, setPlatformSettings] = useState({
    siteName: 'BazaarCo', tagline: 'Shop without fear.',
    commission: '10', minTrustScore: '70', disputeWindow: '7', escrowHold: '48',
    maxListings: '100', requirePhotos: true, autoFlagThreshold: '3',
    maintenanceMode: false, registrationOpen: true, sellerRegistrationOpen: true,
    minSellerAge: '18', maxProductPrice: '500000', minProductPrice: '50',
    autoApproveVerifiedSellers: false, requireIdVerification: true,
  });
  const [moderationSettings, setModerationSettings] = useState({
    autoModerate: true, profanityFilter: true, spamDetection: true,
    imageModeration: true, reviewModeration: false,
    bannedWords: 'scam, fake, replica, knockoff',
    maxImagesPerProduct: '10', minDescriptionLength: '50',
    requireCategoryApproval: false,
  });
  const [emailSettings, setEmailSettings] = useState({
    smtpHost: 'smtp.gmail.com', smtpPort: '587', smtpUser: 'noreply@bazaarco.np',
    senderName: 'BazaarCo Nepal', supportEmail: 'support@bazaarco.np',
    welcomeEmailEnabled: true, orderConfirmEnabled: true, disputeEmailEnabled: true,
  });

  // ========== PRIVACY STATE ==========
  const [privacySettings, setPrivacySettings] = useState({
    profileVisibility: 'public',
    showPurchaseHistory: false,
    showWishlist: false,
    showReviews: true,
    allowMessaging: true,
    shareDataWithSellers: false,
    personalizedAds: false,
    analyticsTracking: true,
  });

  // ========== ORDER PREFERENCES ==========
  const [orderPrefs, setOrderPrefs] = useState({
    defaultPayment: 'esewa',
    autoApplyBestCoupon: true,
    saveOrderHistory: true,
    defaultShippingSpeed: 'standard',
    giftWrapping: false,
    orderUpdatesFrequency: 'every_update',
  });

  // Sync profile when user changes
  useEffect(() => {
    if (user) {
      setProfile(prev => ({ ...prev, name: user.name, email: user.email, phone: user.phone }));
    }
  }, [user]);

  // ========== HANDLERS ==========
  const simulateSave = async () => {
    setSaving(true);
    await new Promise(r => setTimeout(r, 800));
    setSaving(false);
    setSaved(true);
    addNotification('success', 'Settings Saved', 'Your settings have been updated successfully.');
    setTimeout(() => setSaved(false), 2000);
  };

  const handleProfileSave = async () => {
    if (!profile.name.trim()) { addNotification('error', 'Error', 'Name cannot be empty.'); return; }
    if (!profile.email.trim() || !profile.email.includes('@')) { addNotification('error', 'Error', 'Enter a valid email.'); return; }
    await simulateSave();
    if (user) {
      dispatch({ type: 'SET_USER', payload: { ...user, name: profile.name, email: profile.email, phone: profile.phone } });
    }
  };

  const handlePasswordChange = async () => {
    if (!passwords.current) { addNotification('error', 'Error', 'Enter your current password.'); return; }
    if (passwords.newPass.length < 8) { addNotification('error', 'Error', 'Password must be at least 8 characters.'); return; }
    if (passwords.newPass !== passwords.confirm) { addNotification('error', 'Error', 'Passwords do not match.'); return; }
    if (!/(?=.*[0-9])(?=.*[A-Z])/.test(passwords.newPass)) { addNotification('warning', 'Weak Password', 'Consider adding numbers and uppercase letters.'); }
    await simulateSave();
    setPasswords({ current: '', newPass: '', confirm: '' });
  };

  const handleSetDefaultAddress = (id: string) => { setAddresses(prev => prev.map(a => ({ ...a, isDefault: a.id === id }))); addNotification('success', 'Default Address', 'Default shipping address updated.'); };
  const handleDeleteAddress = (id: string) => { setAddresses(prev => prev.filter(a => a.id !== id)); addNotification('info', 'Address Removed', 'Address has been deleted.'); };
  const handleSaveAddress = () => {
    if (!addressForm.label || !addressForm.fullName || !addressForm.phone || !addressForm.address || !addressForm.city) { addNotification('error', 'Error', 'Please fill in all required fields.'); return; }
    if (editingAddress) {
      setAddresses(prev => prev.map(a => a.id === editingAddress.id ? { ...editingAddress, ...addressForm } : a));
      setEditingAddress(null);
    } else {
      setAddresses(prev => [...prev, { ...addressForm, id: `addr-${Date.now()}`, isDefault: prev.length === 0 }]);
    }
    setShowAddressForm(false);
    setAddressForm({ label: '', fullName: '', phone: '', address: '', city: '', landmark: '' });
    addNotification('success', 'Address Saved', 'Your address has been saved.');
  };
  const handleSetDefaultPayment = (id: string) => { setPayments(prev => prev.map(p => ({ ...p, isDefault: p.id === id }))); addNotification('success', 'Default Payment', 'Default payment method updated.'); };
  const handleDeletePayment = (id: string) => { setPayments(prev => prev.filter(p => p.id !== id)); addNotification('info', 'Payment Removed', 'Payment method has been removed.'); };
  const handleAddPayment = () => {
    if (!paymentForm.detail) { addNotification('error', 'Error', 'Please enter payment details.'); return; }
    setPayments(prev => [...prev, { ...paymentForm, id: `pay-${Date.now()}`, label: paymentForm.label || paymentForm.type, isDefault: prev.length === 0 }]);
    setShowPaymentForm(false);
    setPaymentForm({ type: 'esewa', label: '', detail: '' });
    addNotification('success', 'Payment Added', 'New payment method has been added.');
  };

  const handleDeleteAccount = async () => {
    if (deleteConfirmText !== 'DELETE') { addNotification('error', 'Error', 'Please type DELETE to confirm.'); return; }
    setSaving(true);
    await new Promise(r => setTimeout(r, 1500));
    logout();
    navigate('/');
  };

  const handleExportData = async () => {
    setSaving(true);
    await new Promise(r => setTimeout(r, 1500));
    setSaving(false);
    setShowExportModal(false);
    addNotification('success', 'Data Export', 'Your data export has been prepared. Check your email for the download link.');
  };

  const getPasswordStrength = (pass: string) => {
    let score = 0;
    if (pass.length >= 8) score++;
    if (pass.length >= 12) score++;
    if (/[A-Z]/.test(pass)) score++;
    if (/[0-9]/.test(pass)) score++;
    if (/[^A-Za-z0-9]/.test(pass)) score++;
    return score;
  };

  // ========== TAB DEFINITIONS ==========
  const getTabs = () => {
    const common = [
      { id: 'profile', icon: User, label: 'Profile' },
      { id: 'security', icon: Shield, label: 'Security' },
      { id: 'notifications', icon: Bell, label: 'Notifications' },
    ];
    if (userType === 'customer') {
      return [...common,
        { id: 'addresses', icon: MapPin, label: 'Addresses' },
        { id: 'payments', icon: CreditCard, label: 'Payments' },
        { id: 'orders', icon: ShoppingBag, label: 'Order Prefs' },
        { id: 'privacy', icon: Eye, label: 'Privacy' },
        { id: 'data', icon: Download, label: 'Data & Account' },
      ];
    }
    if (userType === 'seller') {
      return [...common,
        { id: 'store', icon: Store, label: 'Store Info' },
        { id: 'bank', icon: Building2, label: 'Bank & Payout' },
        { id: 'shipping', icon: Truck, label: 'Shipping & Returns' },
        { id: 'verification', icon: Award, label: 'Verification' },
        { id: 'addresses', icon: MapPin, label: 'Addresses' },
        { id: 'payments', icon: CreditCard, label: 'Payments' },
        { id: 'data', icon: Download, label: 'Data & Account' },
      ];
    }
    // admin
    return [...common,
      { id: 'platform', icon: Settings, label: 'Platform' },
      { id: 'moderation', icon: Shield, label: 'Moderation' },
      { id: 'email', icon: Mail, label: 'Email Config' },
      { id: 'data', icon: Download, label: 'Data & Account' },
    ];
  };

  const tabs = getTabs();

  const SaveButton = ({ onClick, label = 'Save Changes' }: { onClick: () => void; label?: string }) => (
    <button onClick={onClick} disabled={saving} className="bg-red-600 text-white px-6 py-2.5 rounded-lg font-medium hover:bg-red-700 flex items-center gap-2 disabled:opacity-70 transition-colors">
      {saving ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : saved ? <CheckCircle2 size={16} /> : <Save size={16} />}
      {saving ? 'Saving...' : saved ? 'Saved!' : label}
    </button>
  );

  // ========== RENDER ==========
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <main className="max-w-6xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <Link to={userType === 'seller' ? '/seller/dashboard' : userType === 'admin' ? '/admin' : '/'} className="p-2 hover:bg-gray-100 rounded-lg transition-colors"><ArrowLeft size={20} /></Link>
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
            <p className="text-gray-600 text-sm">Manage your {userType === 'admin' ? 'platform' : 'account'} settings and preferences</p>
          </div>
          {!user && (
            <Link to="/login" className="bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-red-700 flex items-center gap-2">
              <LogOut size={16} /> Login to manage settings
            </Link>
          )}
        </div>

        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar */}
          <div className="lg:w-64 flex-shrink-0">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden sticky top-20">
              {/* User Card */}
              <div className="p-4 border-b border-gray-100 text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-3 relative">
                  {profile.name.charAt(0).toUpperCase()}
                  <div className={`absolute bottom-0 right-0 w-5 h-5 rounded-full border-2 border-white flex items-center justify-center ${user ? 'bg-green-500' : 'bg-gray-400'}`}>
                    {user && <CheckCircle2 size={10} className="text-white" />}
                  </div>
                </div>
                <h3 className="font-semibold text-gray-900">{profile.name}</h3>
                <p className="text-sm text-gray-500">{profile.email}</p>
                <span className={`inline-block mt-2 text-xs px-3 py-1 rounded-full font-medium ${
                  userType === 'admin' ? 'bg-purple-100 text-purple-800' : userType === 'seller' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'
                }`}>
                  {userType === 'seller' ? '🏪 Seller Account' : userType === 'admin' ? '🛡️ Administrator' : '🛍️ Customer'}
                </span>
              </div>
              <nav className="p-2 max-h-[60vh] overflow-y-auto">
                {tabs.map(tab => (
                  <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors ${activeTab === tab.id ? 'bg-red-50 text-red-700' : 'text-gray-600 hover:bg-gray-50'}`}>
                    <tab.icon size={18} />{tab.label}
                  </button>
                ))}
              </nav>
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0 space-y-6">

            {/* ==================== PROFILE ==================== */}
            {activeTab === 'profile' && (
              <>
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2"><User size={20} /> Profile Information</h2>
                  <div className="space-y-4">
                    {/* Avatar */}
                    <div className="flex items-center gap-6 mb-6">
                      <div className="relative">
                        <div className="w-24 h-24 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center text-white text-3xl font-bold">
                          {profile.name.charAt(0).toUpperCase()}
                        </div>
                        <button className="absolute bottom-0 right-0 w-8 h-8 bg-white rounded-full shadow-md flex items-center justify-center text-gray-600 hover:bg-gray-100 border border-gray-200"><Camera size={14} /></button>
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">Profile Photo</p>
                        <p className="text-sm text-gray-500 mt-1">JPG, PNG or GIF. Max 2MB.</p>
                        <button className="mt-2 text-sm text-red-600 font-medium hover:underline flex items-center gap-1"><Upload size={14} /> Upload Photo</button>
                      </div>
                    </div>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Full Name *</label>
                        <div className="relative">
                          <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                          <input type="text" value={profile.name} onChange={e => setProfile({...profile, name: e.target.value})}
                            className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent" />
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number *</label>
                        <div className="relative">
                          <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                          <input type="tel" value={profile.phone} onChange={e => setProfile({...profile, phone: e.target.value})}
                            className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent" />
                        </div>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Email Address *</label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        <input type="email" value={profile.email} onChange={e => setProfile({...profile, email: e.target.value})}
                          className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent" />
                      </div>
                    </div>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Date of Birth</label>
                        <input type="date" value={profile.dateOfBirth} onChange={e => setProfile({...profile, dateOfBirth: e.target.value})}
                          className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Gender</label>
                        <select value={profile.gender} onChange={e => setProfile({...profile, gender: e.target.value})}
                          className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent">
                          <option value="">Prefer not to say</option>
                          <option value="male">Male</option>
                          <option value="female">Female</option>
                          <option value="other">Other</option>
                        </select>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Bio</label>
                      <textarea value={profile.bio} onChange={e => setProfile({...profile, bio: e.target.value})} rows={3} maxLength={200}
                        className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent" placeholder="Tell us about yourself..." />
                      <p className="text-xs text-gray-400 mt-1">{profile.bio.length}/200 characters</p>
                    </div>
                    <div className="grid md:grid-cols-3 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1"><Globe size={14} className="inline mr-1" />Language</label>
                        <select value={profile.language} onChange={e => setProfile({...profile, language: e.target.value})}
                          className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent">
                          <option value="en">English</option>
                          <option value="ne">नेपाली (Nepali)</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1"><MapPin size={14} className="inline mr-1" />Location</label>
                        <select value={profile.location} onChange={e => setProfile({...profile, location: e.target.value})}
                          className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent">
                          {['Kathmandu','Lalitpur','Bhaktapur','Pokhara','Biratnagar','Birgunj','Dharan','Butwal','Dhangadhi','Nepalgunj'].map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1"><Palette size={14} className="inline mr-1" />Theme</label>
                        <div className="flex gap-2">
                          <button onClick={() => setProfile({...profile, theme: 'light'})} className={`flex-1 flex items-center justify-center gap-1 py-2.5 rounded-lg border-2 text-sm font-medium ${profile.theme === 'light' ? 'border-red-500 bg-red-50 text-red-700' : 'border-gray-200 hover:bg-gray-50'}`}><Sun size={14} />Light</button>
                          <button onClick={() => setProfile({...profile, theme: 'dark'})} className={`flex-1 flex items-center justify-center gap-1 py-2.5 rounded-lg border-2 text-sm font-medium ${profile.theme === 'dark' ? 'border-red-500 bg-red-50 text-red-700' : 'border-gray-200 hover:bg-gray-50'}`}><Moon size={14} />Dark</button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="mt-6 flex justify-end"><SaveButton onClick={handleProfileSave} /></div>
                </div>
                {userType === 'customer' && (
                  <div className="bg-gradient-to-r from-blue-50 to-red-50 border border-blue-200 rounded-xl p-4 flex items-center gap-4">
                    <Store className="w-8 h-8 text-blue-600 flex-shrink-0" />
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">Want to start selling?</p>
                      <p className="text-sm text-gray-600 mt-0.5">Register as a seller and reach customers across Nepal with trust protection.</p>
                    </div>
                    <Link to="/login" className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 flex-shrink-0">Start Selling</Link>
                  </div>
                )}
              </>
            )}

            {/* ==================== SECURITY ==================== */}
            {activeTab === 'security' && (
              <>
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2"><Lock size={20} /> Change Password</h2>
                  <div className="space-y-4 max-w-md">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Current Password</label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        <input type={showCurrentPassword ? 'text' : 'password'} value={passwords.current} onChange={e => setPasswords({...passwords, current: e.target.value})}
                          className="w-full pl-10 pr-12 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent" placeholder="Enter current password" />
                        <button onClick={() => setShowCurrentPassword(!showCurrentPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">{showCurrentPassword ? <EyeOff size={18} /> : <Eye size={18} />}</button>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">New Password</label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        <input type={showNewPassword ? 'text' : 'password'} value={passwords.newPass} onChange={e => setPasswords({...passwords, newPass: e.target.value})}
                          className="w-full pl-10 pr-12 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent" placeholder="Enter new password" />
                        <button onClick={() => setShowNewPassword(!showNewPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">{showNewPassword ? <EyeOff size={18} /> : <Eye size={18} />}</button>
                      </div>
                      {passwords.newPass && (
                        <div className="mt-2">
                          <div className="flex gap-1">{[1,2,3,4,5].map(i => <div key={i} className={`h-1.5 flex-1 rounded-full ${getPasswordStrength(passwords.newPass) >= i ? (getPasswordStrength(passwords.newPass) >= 4 ? 'bg-green-500' : getPasswordStrength(passwords.newPass) >= 3 ? 'bg-amber-500' : 'bg-red-500') : 'bg-gray-200'}`} />)}</div>
                          <p className="text-xs text-gray-500 mt-1">{getPasswordStrength(passwords.newPass) < 2 ? '⚠️ Weak — add numbers, uppercase' : getPasswordStrength(passwords.newPass) < 4 ? '🔶 Good — add special characters' : '✅ Strong password'}</p>
                        </div>
                      )}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Confirm New Password</label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        <input type="password" value={passwords.confirm} onChange={e => setPasswords({...passwords, confirm: e.target.value})}
                          className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent" placeholder="Confirm new password" />
                      </div>
                      {passwords.confirm && passwords.confirm !== passwords.newPass && <p className="text-xs text-red-600 mt-1">⚠️ Passwords do not match</p>}
                      {passwords.confirm && passwords.confirm === passwords.newPass && passwords.confirm.length > 0 && <p className="text-xs text-green-600 mt-1">✓ Passwords match</p>}
                    </div>
                    <button onClick={handlePasswordChange} disabled={!passwords.current || !passwords.newPass || !passwords.confirm}
                      className="bg-red-600 text-white px-6 py-2.5 rounded-lg font-medium hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"><Key size={16} /> Update Password</button>
                  </div>
                </div>

                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2"><Smartphone size={20} /> Security Options</h2>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div><p className="font-medium text-gray-900">Two-Factor Authentication (2FA)</p><p className="text-sm text-gray-600 mt-1">Get an OTP via SMS when logging in from a new device.</p></div>
                      <Toggle checked={twoFA} onChange={v => { setTwoFA(v); addNotification('success', '2FA', v ? 'Two-factor authentication enabled.' : 'Two-factor authentication disabled.'); }} />
                    </div>
                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div><p className="font-medium text-gray-900">Login Alerts</p><p className="text-sm text-gray-600 mt-1">Get notified when someone logs into your account from a new device.</p></div>
                      <Toggle checked={loginAlerts} onChange={v => { setLoginAlerts(v); addNotification('success', 'Login Alerts', v ? 'Enabled.' : 'Disabled.'); }} />
                    </div>
                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div><p className="font-medium text-gray-900">Session Timeout</p><p className="text-sm text-gray-600 mt-1">Automatically log out after inactivity.</p></div>
                      <select value={sessionTimeout} onChange={e => { setSessionTimeout(e.target.value); addNotification('success', 'Session', `Timeout set to ${e.target.value} minutes.`); }}
                        className="px-3 py-2 border border-gray-300 rounded-lg text-sm"><option value="15">15 min</option><option value="30">30 min</option><option value="60">1 hour</option><option value="never">Never</option></select>
                    </div>
                  </div>
                </div>

                {/* Login Activity */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2"><History size={20} /> Recent Login Activity</h2>
                  <div className="space-y-3">
                    {loginActivities.map(activity => (
                      <div key={activity.id} className={`flex items-center justify-between p-4 rounded-lg ${activity.current ? 'bg-green-50 border border-green-200' : 'bg-gray-50'}`}>
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center ${activity.current ? 'bg-green-100' : 'bg-gray-200'}`}>
                            <Smartphone size={18} className={activity.current ? 'text-green-600' : 'text-gray-500'} />
                          </div>
                          <div>
                            <p className="font-medium text-gray-900 text-sm">{activity.device} {activity.current && <span className="text-green-600 text-xs ml-1">(Current)</span>}</p>
                            <p className="text-xs text-gray-500">{activity.location} · {activity.ip} · {activity.date}</p>
                          </div>
                        </div>
                        {!activity.current && <button className="text-red-600 text-xs font-medium hover:underline">Revoke</button>}
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}

            {/* ==================== NOTIFICATIONS ==================== */}
            {activeTab === 'notifications' && (
              <>
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2"><Bell size={20} /> Notification Channels</h2>
                  <div className="space-y-3">
                    {[
                      { key: 'pushEnabled' as const, label: 'Push Notifications', desc: 'Browser & app notifications', icon: Zap },
                      { key: 'emailEnabled' as const, label: 'Email Notifications', desc: 'Receive updates via email', icon: Mail },
                      { key: 'smsEnabled' as const, label: 'SMS Notifications', desc: 'SMS alerts (standard rates apply)', icon: Phone },
                    ].map(ch => (
                      <div key={ch.key} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div className="flex items-center gap-3"><ch.icon size={18} className="text-gray-500" /><div><p className="font-medium text-gray-900">{ch.label}</p><p className="text-sm text-gray-600">{ch.desc}</p></div></div>
                        <Toggle checked={notifPrefs[ch.key]} onChange={v => setNotifPrefs({...notifPrefs, [ch.key]: v})} />
                      </div>
                    ))}
                  </div>
                </div>
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2"><Settings size={20} /> {userType === 'admin' ? 'Admin Notifications' : userType === 'seller' ? 'Seller Notifications' : 'Notification Types'}</h2>
                  <div className="space-y-3">
                    {/* Common notifications */}
                    {[
                      { key: 'orderUpdates' as const, label: 'Order Updates', desc: 'Status changes, delivery updates' },
                      { key: 'disputeUpdates' as const, label: 'Dispute Updates', desc: 'Resolution progress' },
                      { key: 'securityAlerts' as const, label: 'Security Alerts', desc: 'Login attempts, password changes' },
                    ].map(item => (
                      <div key={item.key} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div><p className="font-medium text-gray-900">{item.label}</p><p className="text-sm text-gray-600">{item.desc}</p></div>
                        <Toggle checked={notifPrefs[item.key]} onChange={v => setNotifPrefs({...notifPrefs, [item.key]: v})} />
                      </div>
                    ))}
                    {/* Customer-specific */}
                    {userType === 'customer' && [
                      { key: 'priceDrops' as const, label: 'Price Drop Alerts', desc: 'When wishlist items drop in price' },
                      { key: 'promotions' as const, label: 'Promotions & Deals', desc: 'Flash sales and discounts' },
                      { key: 'reviewReminders' as const, label: 'Review Reminders', desc: 'Reminders to review purchased items' },
                      { key: 'newsletter' as const, label: 'Newsletter', desc: 'Weekly digest of top products' },
                    ].map(item => (
                      <div key={item.key} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div><p className="font-medium text-gray-900">{item.label}</p><p className="text-sm text-gray-600">{item.desc}</p></div>
                        <Toggle checked={notifPrefs[item.key]} onChange={v => setNotifPrefs({...notifPrefs, [item.key]: v})} />
                      </div>
                    ))}
                    {/* Seller-specific */}
                    {userType === 'seller' && [
                      { key: 'newOrders' as const, label: 'New Orders', desc: 'Instant alert for new orders' },
                      { key: 'lowStock' as const, label: 'Low Stock Warnings', desc: 'When product stock falls below 5' },
                      { key: 'sellerMessages' as const, label: 'Customer Messages', desc: 'New messages from buyers' },
                      { key: 'payoutNotif' as const, label: 'Payout Notifications', desc: 'When payouts are processed' },
                      { key: 'sellerTips' as const, label: 'Seller Tips', desc: 'Tips to improve your store' },
                    ].map(item => (
                      <div key={item.key} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div><p className="font-medium text-gray-900">{item.label}</p><p className="text-sm text-gray-600">{item.desc}</p></div>
                        <Toggle checked={notifPrefs[item.key]} onChange={v => setNotifPrefs({...notifPrefs, [item.key]: v})} />
                      </div>
                    ))}
                    {/* Admin-specific */}
                    {userType === 'admin' && [
                      { key: 'newDisputes' as const, label: 'New Disputes', desc: 'Immediate alert for new disputes' },
                      { key: 'sellerApps' as const, label: 'Seller Applications', desc: 'New seller verification requests' },
                      { key: 'systemAlerts' as const, label: 'System Alerts', desc: 'Server errors, downtime warnings' },
                      { key: 'dailyReport' as const, label: 'Daily Report', desc: 'Daily summary email of platform activity' },
                    ].map(item => (
                      <div key={item.key} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div><p className="font-medium text-gray-900">{item.label}</p><p className="text-sm text-gray-600">{item.desc}</p></div>
                        <Toggle checked={notifPrefs[item.key]} onChange={v => setNotifPrefs({...notifPrefs, [item.key]: v})} />
                      </div>
                    ))}
                  </div>
                  <div className="mt-6 flex justify-end"><SaveButton onClick={simulateSave} label="Save Preferences" /></div>
                </div>
              </>
            )}

            {/* ==================== ADDRESSES (Customer & Seller) ==================== */}
            {activeTab === 'addresses' && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2"><MapPin size={20} /> Saved Addresses</h2>
                  <button onClick={() => { setEditingAddress(null); setAddressForm({ label: '', fullName: user?.name || '', phone: '', address: '', city: '', landmark: '' }); setShowAddressForm(true); }}
                    className="bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-red-700 flex items-center gap-2"><Plus size={16} /> Add Address</button>
                </div>
                {showAddressForm && (
                  <div className="mb-6 p-5 border border-gray-200 rounded-xl bg-gray-50">
                    <h3 className="font-medium text-gray-900 mb-4">{editingAddress ? 'Edit Address' : 'New Address'}</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">Label *</label><input type="text" value={addressForm.label} onChange={e => setAddressForm({...addressForm, label: e.target.value})} className="w-full px-3 py-2.5 border border-gray-300 rounded-lg" placeholder="Home, Office, etc." /></div>
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">Full Name *</label><input type="text" value={addressForm.fullName} onChange={e => setAddressForm({...addressForm, fullName: e.target.value})} className="w-full px-3 py-2.5 border border-gray-300 rounded-lg" /></div>
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">Phone *</label><input type="tel" value={addressForm.phone} onChange={e => setAddressForm({...addressForm, phone: e.target.value})} className="w-full px-3 py-2.5 border border-gray-300 rounded-lg" placeholder="98XXXXXXXX" /></div>
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">City *</label>
                        <select value={addressForm.city} onChange={e => setAddressForm({...addressForm, city: e.target.value})} className="w-full px-3 py-2.5 border border-gray-300 rounded-lg">
                          <option value="">Select city</option>{['Kathmandu','Lalitpur','Bhaktapur','Pokhara','Biratnagar','Birgunj','Dharan','Butwal','Dhangadhi','Nepalgunj'].map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                      </div>
                      <div className="md:col-span-2"><label className="block text-sm font-medium text-gray-700 mb-1">Street Address *</label><input type="text" value={addressForm.address} onChange={e => setAddressForm({...addressForm, address: e.target.value})} className="w-full px-3 py-2.5 border border-gray-300 rounded-lg" placeholder="House no., Street, Tole" /></div>
                      <div className="md:col-span-2"><label className="block text-sm font-medium text-gray-700 mb-1">Landmark</label><input type="text" value={addressForm.landmark} onChange={e => setAddressForm({...addressForm, landmark: e.target.value})} className="w-full px-3 py-2.5 border border-gray-300 rounded-lg" placeholder="Near..." /></div>
                    </div>
                    <div className="mt-4 flex gap-3 justify-end">
                      <button onClick={() => { setShowAddressForm(false); setEditingAddress(null); }} className="px-4 py-2 bg-gray-100 rounded-lg text-sm font-medium hover:bg-gray-200">Cancel</button>
                      <button onClick={handleSaveAddress} className="px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-medium hover:bg-red-700">Save Address</button>
                    </div>
                  </div>
                )}
                <div className="space-y-3">
                  {addresses.map(addr => (
                    <div key={addr.id} className={`p-4 border-2 rounded-xl transition-colors ${addr.isDefault ? 'border-red-200 bg-red-50/50' : 'border-gray-200 hover:border-gray-300'}`}>
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="flex items-center gap-2"><span className="font-semibold text-gray-900">{addr.label}</span>{addr.isDefault && <span className="text-xs bg-red-100 text-red-700 px-2 py-0.5 rounded-full font-medium">Default</span>}</div>
                          <p className="text-gray-700 mt-1">{addr.fullName}</p>
                          <p className="text-gray-600 text-sm">{addr.address}, {addr.city}</p>
                          {addr.landmark && <p className="text-gray-500 text-sm">📍 Near: {addr.landmark}</p>}
                          <p className="text-gray-500 text-sm mt-1">📞 {addr.phone}</p>
                        </div>
                        <div className="flex gap-2 items-center">
                          {!addr.isDefault && <button onClick={() => handleSetDefaultAddress(addr.id)} className="text-sm text-red-600 hover:underline font-medium">Set Default</button>}
                          <button onClick={() => { setEditingAddress(addr); setAddressForm(addr); setShowAddressForm(true); }} className="p-1.5 hover:bg-gray-100 rounded text-gray-500"><Settings size={16} /></button>
                          <button onClick={() => handleDeleteAddress(addr.id)} className="p-1.5 hover:bg-red-100 rounded text-gray-500 hover:text-red-600"><Trash2 size={16} /></button>
                        </div>
                      </div>
                    </div>
                  ))}
                  {addresses.length === 0 && <div className="text-center py-12 text-gray-500"><MapPin className="w-12 h-12 mx-auto mb-3 text-gray-300" /><p>No saved addresses yet.</p><p className="text-sm mt-1">Add an address for faster checkout.</p></div>}
                </div>
              </div>
            )}

            {/* ==================== PAYMENTS (Customer & Seller) ==================== */}
            {activeTab === 'payments' && (
              <>
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2"><CreditCard size={20} /> Payment Methods</h2>
                    <button onClick={() => { setPaymentForm({ type: 'esewa', label: '', detail: '' }); setShowPaymentForm(true); }}
                      className="bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-red-700 flex items-center gap-2"><Plus size={16} /> Add Payment</button>
                  </div>
                  {showPaymentForm && (
                    <div className="mb-6 p-5 border border-gray-200 rounded-xl bg-gray-50">
                      <h3 className="font-medium text-gray-900 mb-4">Add Payment Method</h3>
                      <div className="grid md:grid-cols-3 gap-4">
                        <div><label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
                          <select value={paymentForm.type} onChange={e => setPaymentForm({...paymentForm, type: e.target.value as PaymentMethod['type']})} className="w-full px-3 py-2.5 border border-gray-300 rounded-lg">
                            <option value="esewa">eSewa</option><option value="khalti">Khalti</option><option value="bank">Bank Account</option><option value="cod">Cash on Delivery</option>
                          </select>
                        </div>
                        <div><label className="block text-sm font-medium text-gray-700 mb-1">Label</label><input type="text" value={paymentForm.label} onChange={e => setPaymentForm({...paymentForm, label: e.target.value})} className="w-full px-3 py-2.5 border border-gray-300 rounded-lg" placeholder="My eSewa" /></div>
                        <div><label className="block text-sm font-medium text-gray-700 mb-1">{paymentForm.type === 'bank' ? 'Account Number' : paymentForm.type === 'cod' ? 'Phone for COD' : 'Phone Number'}</label><input type="text" value={paymentForm.detail} onChange={e => setPaymentForm({...paymentForm, detail: e.target.value})} className="w-full px-3 py-2.5 border border-gray-300 rounded-lg" /></div>
                      </div>
                      <div className="mt-4 flex gap-3 justify-end">
                        <button onClick={() => setShowPaymentForm(false)} className="px-4 py-2 bg-gray-100 rounded-lg text-sm font-medium hover:bg-gray-200">Cancel</button>
                        <button onClick={handleAddPayment} className="px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-medium hover:bg-red-700">Add Method</button>
                      </div>
                    </div>
                  )}
                  <div className="space-y-3">
                    {payments.map(pm => (
                      <div key={pm.id} className={`p-4 border-2 rounded-xl flex items-center justify-between ${pm.isDefault ? 'border-red-200 bg-red-50/50' : 'border-gray-200'}`}>
                        <div className="flex items-center gap-4">
                          <div className={`w-12 h-12 rounded-lg flex items-center justify-center text-white font-bold text-sm ${pm.type === 'esewa' ? 'bg-green-500' : pm.type === 'khalti' ? 'bg-purple-600' : pm.type === 'bank' ? 'bg-blue-600' : 'bg-gray-600'}`}>
                            {pm.type === 'esewa' ? 'e₹' : pm.type === 'khalti' ? 'K' : pm.type === 'bank' ? '🏦' : '💵'}
                          </div>
                          <div><p className="font-medium text-gray-900">{pm.label}</p><p className="text-sm text-gray-500">{pm.detail}</p></div>
                          {pm.isDefault && <span className="text-xs bg-red-100 text-red-700 px-2 py-0.5 rounded-full font-medium">Default</span>}
                        </div>
                        <div className="flex gap-2 items-center">
                          {!pm.isDefault && <button onClick={() => handleSetDefaultPayment(pm.id)} className="text-sm text-red-600 hover:underline font-medium">Set Default</button>}
                          <button onClick={() => handleDeletePayment(pm.id)} className="p-1.5 hover:bg-red-100 rounded text-gray-500 hover:text-red-600"><Trash2 size={16} /></button>
                        </div>
                      </div>
                    ))}
                    {payments.length === 0 && <div className="text-center py-12 text-gray-500"><CreditCard className="w-12 h-12 mx-auto mb-3 text-gray-300" /><p>No payment methods saved.</p></div>}
                  </div>
                </div>
                <div className="bg-green-50 border border-green-200 rounded-xl p-4 flex items-start gap-3">
                  <Shield className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                  <div className="text-sm text-green-800"><p className="font-medium">Your payment data is encrypted & secure</p><p className="mt-1">BazaarCo uses 256-bit encryption. We never store full payment details on our servers.</p></div>
                </div>
              </>
            )}

            {/* ==================== ORDER PREFERENCES (Customer only) ==================== */}
            {activeTab === 'orders' && userType === 'customer' && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2"><ShoppingBag size={20} /> Order Preferences</h2>
                <div className="space-y-4">
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">Default Payment Method</label>
                    <select value={orderPrefs.defaultPayment} onChange={e => setOrderPrefs({...orderPrefs, defaultPayment: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                      <option value="esewa">eSewa</option><option value="khalti">Khalti</option><option value="bank">Bank Transfer</option><option value="cod">Cash on Delivery</option>
                    </select>
                  </div>
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">Default Shipping Speed</label>
                    <select value={orderPrefs.defaultShippingSpeed} onChange={e => setOrderPrefs({...orderPrefs, defaultShippingSpeed: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                      <option value="standard">Standard (3-5 days)</option><option value="express">Express (1-2 days)</option><option value="same_day">Same Day (where available)</option>
                    </select>
                  </div>
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">Order Update Frequency</label>
                    <select value={orderPrefs.orderUpdatesFrequency} onChange={e => setOrderPrefs({...orderPrefs, orderUpdatesFrequency: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                      <option value="every_update">Every status change</option><option value="key_updates">Key updates only (shipped, delivered)</option><option value="delivered_only">Delivered only</option>
                    </select>
                  </div>
                  <div className="space-y-3 pt-2">
                    {[
                      { key: 'autoApplyBestCoupon' as const, label: 'Auto-apply best coupon', desc: 'Automatically use the highest-value applicable coupon at checkout' },
                      { key: 'saveOrderHistory' as const, label: 'Save order history', desc: 'Keep records of all past orders for easy reordering' },
                      { key: 'giftWrapping' as const, label: 'Default gift wrapping', desc: 'Add gift wrapping to all orders by default' },
                    ].map(item => (
                      <div key={item.key} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div><p className="font-medium text-gray-900">{item.label}</p><p className="text-sm text-gray-600">{item.desc}</p></div>
                        <Toggle checked={orderPrefs[item.key]} onChange={v => setOrderPrefs({...orderPrefs, [item.key]: v})} />
                      </div>
                    ))}
                  </div>
                </div>
                <div className="mt-6 flex justify-end"><SaveButton onClick={simulateSave} /></div>
              </div>
            )}

            {/* ==================== PRIVACY (Customer only) ==================== */}
            {activeTab === 'privacy' && userType === 'customer' && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2"><Eye size={20} /> Privacy Settings</h2>
                <div className="space-y-4">
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">Profile Visibility</label>
                    <select value={privacySettings.profileVisibility} onChange={e => setPrivacySettings({...privacySettings, profileVisibility: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                      <option value="public">Public — Visible to sellers and other users</option>
                      <option value="private">Private — Only visible to you and sellers you've bought from</option>
                      <option value="hidden">Hidden — Only visible to you</option>
                    </select>
                  </div>
                  <div className="space-y-3">
                    {[
                      { key: 'showPurchaseHistory' as const, label: 'Show purchase history on profile', desc: 'Let others see what you\'ve bought' },
                      { key: 'showWishlist' as const, label: 'Public wishlist', desc: 'Others can see your wishlisted items' },
                      { key: 'showReviews' as const, label: 'Show my reviews publicly', desc: 'Display your reviews with your name' },
                      { key: 'allowMessaging' as const, label: 'Allow messaging from sellers', desc: 'Sellers can send you messages about orders and products' },
                      { key: 'shareDataWithSellers' as const, label: 'Share browsing data with sellers', desc: 'Help sellers improve their products based on your activity' },
                      { key: 'personalizedAds' as const, label: 'Personalized recommendations', desc: 'Get product suggestions based on your browsing' },
                      { key: 'analyticsTracking' as const, label: 'Analytics & improvement', desc: 'Help BazaarCo improve the platform with anonymous usage data' },
                    ].map(item => (
                      <div key={item.key} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div><p className="font-medium text-gray-900">{item.label}</p><p className="text-sm text-gray-600">{item.desc}</p></div>
                        <Toggle checked={privacySettings[item.key] as boolean} onChange={v => setPrivacySettings({...privacySettings, [item.key]: v})} />
                      </div>
                    ))}
                  </div>
                </div>
                <div className="mt-6 flex justify-end"><SaveButton onClick={simulateSave} /></div>
              </div>
            )}

            {/* ==================== STORE INFO (Seller only) ==================== */}
            {activeTab === 'store' && userType === 'seller' && (
              <div className="space-y-6">
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2"><Store size={20} /> Store Information</h2>
                  <div className="space-y-4">
                    {/* Store banner / logo */}
                    <div className="flex flex-col sm:flex-row gap-6">
                      <div className="text-center">
                        <div className="w-24 h-24 bg-gradient-to-br from-red-500 to-red-600 rounded-xl flex items-center justify-center text-white text-3xl font-bold mx-auto">{storeSettings.storeName.charAt(0)}</div>
                        <button className="mt-2 text-sm text-red-600 font-medium hover:underline flex items-center gap-1 mx-auto"><Image size={14} />Change Logo</button>
                      </div>
                      <div className="flex-1">
                        <div className="w-full h-24 bg-gradient-to-r from-gray-200 to-gray-300 rounded-xl flex items-center justify-center"><button className="text-sm text-gray-600 font-medium flex items-center gap-1"><Upload size={14} />Upload Store Banner</button></div>
                        <p className="text-xs text-gray-500 mt-1">Recommended: 1200×300px, JPG/PNG</p>
                      </div>
                    </div>
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">Store Name *</label><input type="text" value={storeSettings.storeName} onChange={e => setStoreSettings({...storeSettings, storeName: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">Store Description *</label><textarea value={storeSettings.description} onChange={e => setStoreSettings({...storeSettings, description: e.target.value})} rows={3} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /><p className="text-xs text-gray-400 mt-1">{storeSettings.description.length}/500 characters</p></div>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                        <select value={storeSettings.category} onChange={e => setStoreSettings({...storeSettings, category: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                          <option value="handicrafts">Handicrafts</option><option value="fashion">Fashion & Clothing</option><option value="electronics">Electronics</option><option value="home">Home & Kitchen</option><option value="beauty">Beauty & Health</option><option value="food">Food & Beverages</option><option value="other">Other</option>
                        </select>
                      </div>
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">Website (optional)</label><input type="url" value={storeSettings.website} onChange={e => setStoreSettings({...storeSettings, website: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="https://" /></div>
                    </div>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div><label className="block text-sm font-medium text-gray-700 mb-1"><MapPin size={14} className="inline mr-1" />Store Address</label><input type="text" value={storeSettings.storeAddress} onChange={e => setStoreSettings({...storeSettings, storeAddress: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                      <div><label className="block text-sm font-medium text-gray-700 mb-1"><Phone size={14} className="inline mr-1" />Phone</label><input type="tel" value={storeSettings.storePhone} onChange={e => setStoreSettings({...storeSettings, storePhone: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                    </div>
                    <div><label className="block text-sm font-medium text-gray-700 mb-1"><Mail size={14} className="inline mr-1" />Store Email</label><input type="email" value={storeSettings.storeEmail} onChange={e => setStoreSettings({...storeSettings, storeEmail: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">PAN Number</label><input type="text" value={storeSettings.panNumber} onChange={e => setStoreSettings({...storeSettings, panNumber: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                      <div className="flex items-center gap-3 pt-6">
                        <Toggle checked={storeSettings.vatRegistered} onChange={v => setStoreSettings({...storeSettings, vatRegistered: v})} />
                        <span className="text-sm font-medium text-gray-700">VAT Registered</span>
                      </div>
                    </div>
                  </div>
                  <div className="mt-6 flex justify-end"><SaveButton onClick={simulateSave} /></div>
                </div>
              </div>
            )}

            {/* ==================== BANK & PAYOUT (Seller only) ==================== */}
            {activeTab === 'bank' && userType === 'seller' && (
              <div className="space-y-6">
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2"><Building2 size={20} /> Bank Account Details</h2>
                  <div className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">Bank Name</label><input type="text" value={bankSettings.bankName} onChange={e => setBankSettings({...bankSettings, bankName: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">Branch Name</label><input type="text" value={bankSettings.branchName} onChange={e => setBankSettings({...bankSettings, branchName: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                    </div>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">Account Number</label><input type="text" value={bankSettings.accountNumber} onChange={e => setBankSettings({...bankSettings, accountNumber: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">Account Holder Name</label><input type="text" value={bankSettings.accountName} onChange={e => setBankSettings({...bankSettings, accountName: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                    </div>
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">SWIFT Code (optional)</label><input type="text" value={bankSettings.swiftCode} onChange={e => setBankSettings({...bankSettings, swiftCode: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                  </div>
                </div>
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2"><CreditCard size={20} /> Digital Wallets</h2>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div><label className="block text-sm font-medium text-gray-700 mb-1"><span className="text-green-600 font-bold">eSewa</span> ID</label><input type="text" value={bankSettings.esewaId} onChange={e => setBankSettings({...bankSettings, esewaId: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                    <div><label className="block text-sm font-medium text-gray-700 mb-1"><span className="text-purple-600 font-bold">Khalti</span> ID</label><input type="text" value={bankSettings.khaltiId} onChange={e => setBankSettings({...bankSettings, khaltiId: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                  </div>
                </div>
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2"><DollarSign size={20} /> Payout Settings</h2>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">Payout Frequency</label>
                      <select value={bankSettings.payoutFrequency} onChange={e => setBankSettings({...bankSettings, payoutFrequency: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                        <option value="daily">Daily</option><option value="weekly">Weekly</option><option value="biweekly">Bi-weekly</option><option value="monthly">Monthly</option>
                      </select>
                    </div>
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">Minimum Payout (Rs.)</label><input type="number" value={bankSettings.minPayout} onChange={e => setBankSettings({...bankSettings, minPayout: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                  </div>
                  <div className="mt-4 bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm text-blue-800"><Shield className="w-4 h-4 inline mr-1" />Payouts are held in escrow until buyer confirms delivery (max 48 hours after delivery).</div>
                </div>
                <div className="flex justify-end"><SaveButton onClick={simulateSave} /></div>
              </div>
            )}

            {/* ==================== SHIPPING & RETURNS (Seller only) ==================== */}
            {activeTab === 'shipping' && userType === 'seller' && (
              <div className="space-y-6">
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2"><Truck size={20} /> Shipping Settings</h2>
                  <div className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">Handling Time</label>
                        <select value={shippingSettings.handlingTime} onChange={e => setShippingSettings({...shippingSettings, handlingTime: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                          <option value="same_day">Same day</option><option value="1">1 day</option><option value="1-2">1-2 days</option><option value="2-3">2-3 days</option><option value="3-5">3-5 days</option>
                        </select>
                      </div>
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">Free Shipping Threshold (Rs.)</label><input type="number" value={shippingSettings.freeShippingThreshold} onChange={e => setShippingSettings({...shippingSettings, freeShippingThreshold: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Shipping Zones & Rates</label>
                      <div className="space-y-2">
                        {shippingSettings.shippingZones.map((zone, i) => (
                          <div key={i} className="grid grid-cols-3 gap-3 p-3 bg-gray-50 rounded-lg">
                            <div><label className="block text-xs text-gray-500 mb-1">Zone</label><input type="text" value={zone.zone} onChange={e => { const z = [...shippingSettings.shippingZones]; z[i] = {...z[i], zone: e.target.value}; setShippingSettings({...shippingSettings, shippingZones: z}); }} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" /></div>
                            <div><label className="block text-xs text-gray-500 mb-1">Price (Rs.)</label><input type="number" value={zone.price} onChange={e => { const z = [...shippingSettings.shippingZones]; z[i] = {...z[i], price: e.target.value}; setShippingSettings({...shippingSettings, shippingZones: z}); }} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" /></div>
                            <div><label className="block text-xs text-gray-500 mb-1">Est. Days</label><input type="text" value={zone.days} onChange={e => { const z = [...shippingSettings.shippingZones]; z[i] = {...z[i], days: e.target.value}; setShippingSettings({...shippingSettings, shippingZones: z}); }} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" /></div>
                          </div>
                        ))}
                        <button onClick={() => setShippingSettings({...shippingSettings, shippingZones: [...shippingSettings.shippingZones, { zone: '', price: '', days: '' }]})} className="text-sm text-red-600 font-medium flex items-center gap-1"><Plus size={14} />Add Zone</button>
                      </div>
                    </div>
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">Shipping Policy</label><textarea value={shippingSettings.shippingPolicy} onChange={e => setShippingSettings({...shippingSettings, shippingPolicy: e.target.value})} rows={3} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                  </div>
                </div>
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2"><RefreshCw size={20} /> Return Policy</h2>
                  <div className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">Return Window (days)</label><input type="number" value={shippingSettings.returnWindow} onChange={e => setShippingSettings({...shippingSettings, returnWindow: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                      <div className="flex items-center gap-3 pt-6">
                        <Toggle checked={shippingSettings.autoAcceptReturns} onChange={v => setShippingSettings({...shippingSettings, autoAcceptReturns: v})} />
                        <span className="text-sm font-medium text-gray-700">Auto-accept return requests</span>
                      </div>
                    </div>
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">Return Policy Text</label><textarea value={shippingSettings.returnPolicy} onChange={e => setShippingSettings({...shippingSettings, returnPolicy: e.target.value})} rows={3} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                  </div>
                </div>
                <div className="flex justify-end"><SaveButton onClick={simulateSave} /></div>
              </div>
            )}

            {/* ==================== VERIFICATION (Seller only) ==================== */}
            {activeTab === 'verification' && userType === 'seller' && (
              <div className="space-y-6">
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-2 flex items-center gap-2"><Award size={20} /> Verification Status</h2>
                  <p className="text-sm text-gray-600 mb-6">Complete all verification steps to earn the ✅ Verified Seller badge and boost your Trust Score.</p>
                  <div className="space-y-3">
                    {[
                      { key: 'email', label: 'Email Verification', desc: 'Verify your email address', icon: Mail },
                      { key: 'phone', label: 'Phone Verification', desc: 'Verify via OTP sent to your phone', icon: Phone },
                      { key: 'identity', label: 'Identity Verification', desc: 'Upload citizenship/passport', icon: User },
                      { key: 'pan', label: 'PAN/VAT Verification', desc: 'Business tax registration', icon: FileText },
                      { key: 'bank', label: 'Bank Account Verification', desc: 'Verify bank account ownership', icon: Building2 },
                      { key: 'address', label: 'Address Verification', desc: 'Verify your store/business address', icon: MapPin },
                    ].map(item => {
                      const verified = verificationStatus[item.key as keyof typeof verificationStatus];
                      return (
                        <div key={item.key} className={`flex items-center justify-between p-4 rounded-xl border-2 ${verified ? 'border-green-200 bg-green-50' : 'border-gray-200 bg-gray-50'}`}>
                          <div className="flex items-center gap-3">
                            <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${verified ? 'bg-green-100' : 'bg-gray-200'}`}><item.icon size={18} className={verified ? 'text-green-600' : 'text-gray-500'} /></div>
                            <div><p className="font-medium text-gray-900">{item.label}</p><p className="text-sm text-gray-600">{item.desc}</p></div>
                          </div>
                          {verified
                            ? <span className="flex items-center gap-1 text-green-700 text-sm font-medium"><CheckCircle2 size={16} />Verified</span>
                            : <button className="px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-medium hover:bg-red-700">Verify Now</button>
                          }
                        </div>
                      );
                    })}
                  </div>
                </div>
                <div className="bg-gradient-to-r from-green-600 to-green-700 rounded-xl p-6 text-white">
                  <div className="flex items-center gap-3 mb-3"><Shield className="w-6 h-6" /><h3 className="text-lg font-semibold">Trust Score Impact</h3></div>
                  <p className="text-green-100 text-sm mb-4">Each verification step improves your Trust Score by approximately 10-15 points. Higher scores mean more visibility and customer confidence.</p>
                  <div className="grid grid-cols-3 gap-3">
                    <div className="bg-white/10 rounded-lg p-3"><p className="text-green-100 text-xs">Current Score</p><p className="text-2xl font-bold">94%</p></div>
                    <div className="bg-white/10 rounded-lg p-3"><p className="text-green-100 text-xs">Verified Steps</p><p className="text-2xl font-bold">5/6</p></div>
                    <div className="bg-white/10 rounded-lg p-3"><p className="text-green-100 text-xs">Badge Level</p><p className="text-2xl font-bold">Gold</p></div>
                  </div>
                </div>
              </div>
            )}

            {/* ==================== PLATFORM SETTINGS (Admin only) ==================== */}
            {activeTab === 'platform' && userType === 'admin' && (
              <div className="space-y-6">
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2"><Settings size={20} /> General Platform Settings</h2>
                  <div className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">Site Name</label><input type="text" value={platformSettings.siteName} onChange={e => setPlatformSettings({...platformSettings, siteName: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">Tagline</label><input type="text" value={platformSettings.tagline} onChange={e => setPlatformSettings({...platformSettings, tagline: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                    </div>
                    <div className="space-y-3">
                      {[
                        { key: 'maintenanceMode', label: '🔧 Maintenance Mode', desc: 'Take the site offline for maintenance (shows maintenance page)' },
                        { key: 'registrationOpen', label: '📝 Open Customer Registration', desc: 'Allow new customer signups' },
                        { key: 'sellerRegistrationOpen', label: '🏪 Open Seller Registration', desc: 'Allow new seller applications' },
                      ].map(item => (
                        <div key={item.key} className={`flex items-center justify-between p-4 rounded-lg ${item.key === 'maintenanceMode' && platformSettings.maintenanceMode ? 'bg-red-50 border border-red-200' : 'bg-gray-50'}`}>
                          <div><p className="font-medium text-gray-900">{item.label}</p><p className="text-sm text-gray-600">{item.desc}</p></div>
                          <Toggle checked={platformSettings[item.key as keyof typeof platformSettings] as boolean} onChange={v => setPlatformSettings({...platformSettings, [item.key]: v})} />
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2"><DollarSign size={20} /> Commission & Limits</h2>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">Platform Commission (%)</label><input type="number" value={platformSettings.commission} onChange={e => setPlatformSettings({...platformSettings, commission: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">Max Listings per Seller</label><input type="number" value={platformSettings.maxListings} onChange={e => setPlatformSettings({...platformSettings, maxListings: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">Min Product Price (Rs.)</label><input type="number" value={platformSettings.minProductPrice} onChange={e => setPlatformSettings({...platformSettings, minProductPrice: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">Max Product Price (Rs.)</label><input type="number" value={platformSettings.maxProductPrice} onChange={e => setPlatformSettings({...platformSettings, maxProductPrice: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                  </div>
                </div>
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2"><Shield size={20} /> Trust & Safety Rules</h2>
                  <div className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">Min Trust Score for Selling (%)</label><input type="number" value={platformSettings.minTrustScore} onChange={e => setPlatformSettings({...platformSettings, minTrustScore: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">Dispute Window (days)</label><input type="number" value={platformSettings.disputeWindow} onChange={e => setPlatformSettings({...platformSettings, disputeWindow: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">Escrow Hold Period (hours)</label><input type="number" value={platformSettings.escrowHold} onChange={e => setPlatformSettings({...platformSettings, escrowHold: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">Auto-flag Report Threshold</label><input type="number" value={platformSettings.autoFlagThreshold} onChange={e => setPlatformSettings({...platformSettings, autoFlagThreshold: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                    </div>
                    <div className="space-y-3">
                      {[
                        { key: 'requireIdVerification', label: 'Require ID Verification', desc: 'Sellers must verify identity before listing products' },
                        { key: 'autoApproveVerifiedSellers', label: 'Auto-approve Verified Sellers', desc: 'Skip manual review for sellers who complete all verifications' },
                      ].map(item => (
                        <div key={item.key} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                          <div><p className="font-medium text-gray-900">{item.label}</p><p className="text-sm text-gray-600">{item.desc}</p></div>
                          <Toggle checked={platformSettings[item.key as keyof typeof platformSettings] as boolean} onChange={v => setPlatformSettings({...platformSettings, [item.key]: v})} />
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="flex justify-end"><SaveButton onClick={simulateSave} label="Save Platform Settings" /></div>
              </div>
            )}

            {/* ==================== MODERATION (Admin only) ==================== */}
            {activeTab === 'moderation' && userType === 'admin' && (
              <div className="space-y-6">
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2"><Shield size={20} /> Content Moderation</h2>
                  <div className="space-y-3">
                    {[
                      { key: 'autoModerate' as const, label: 'Auto-Moderate Listings', desc: 'AI-powered screening of new product listings' },
                      { key: 'profanityFilter' as const, label: 'Profanity Filter', desc: 'Block profane language in product names, descriptions, and reviews' },
                      { key: 'spamDetection' as const, label: 'Spam Detection', desc: 'Detect and flag duplicate or spammy listings' },
                      { key: 'imageModeration' as const, label: 'Image Moderation', desc: 'Screen uploaded images for inappropriate content and stock photos' },
                      { key: 'reviewModeration' as const, label: 'Review Moderation', desc: 'Require approval before reviews are published' },
                      { key: 'requireCategoryApproval' as const, label: 'Category Approval', desc: 'Require admin approval for certain product categories' },
                    ].map(item => (
                      <div key={item.key} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div><p className="font-medium text-gray-900">{item.label}</p><p className="text-sm text-gray-600">{item.desc}</p></div>
                        <Toggle checked={moderationSettings[item.key]} onChange={v => setModerationSettings({...moderationSettings, [item.key]: v})} />
                      </div>
                    ))}
                  </div>
                </div>
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2"><FileText size={20} /> Listing Rules</h2>
                  <div className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">Max Images per Product</label><input type="number" value={moderationSettings.maxImagesPerProduct} onChange={e => setModerationSettings({...moderationSettings, maxImagesPerProduct: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">Min Description Length (chars)</label><input type="number" value={moderationSettings.minDescriptionLength} onChange={e => setModerationSettings({...moderationSettings, minDescriptionLength: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                    </div>
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">Banned Words (comma separated)</label><textarea value={moderationSettings.bannedWords} onChange={e => setModerationSettings({...moderationSettings, bannedWords: e.target.value})} rows={3} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="scam, fake, replica..." /></div>
                  </div>
                </div>
                <div className="flex justify-end"><SaveButton onClick={simulateSave} label="Save Moderation Settings" /></div>
              </div>
            )}

            {/* ==================== EMAIL CONFIG (Admin only) ==================== */}
            {activeTab === 'email' && userType === 'admin' && (
              <div className="space-y-6">
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2"><Mail size={20} /> SMTP Configuration</h2>
                  <div className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">SMTP Host</label><input type="text" value={emailSettings.smtpHost} onChange={e => setEmailSettings({...emailSettings, smtpHost: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">SMTP Port</label><input type="text" value={emailSettings.smtpPort} onChange={e => setEmailSettings({...emailSettings, smtpPort: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                    </div>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">SMTP Username</label><input type="text" value={emailSettings.smtpUser} onChange={e => setEmailSettings({...emailSettings, smtpUser: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">Sender Name</label><input type="text" value={emailSettings.senderName} onChange={e => setEmailSettings({...emailSettings, senderName: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                    </div>
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">Support Email</label><input type="email" value={emailSettings.supportEmail} onChange={e => setEmailSettings({...emailSettings, supportEmail: e.target.value})} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" /></div>
                  </div>
                </div>
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2"><Bell size={20} /> Email Templates</h2>
                  <div className="space-y-3">
                    {[
                      { key: 'welcomeEmailEnabled' as const, label: 'Welcome Email', desc: 'Sent to new users after registration' },
                      { key: 'orderConfirmEnabled' as const, label: 'Order Confirmation', desc: 'Sent to buyer after placing an order' },
                      { key: 'disputeEmailEnabled' as const, label: 'Dispute Notifications', desc: 'Alert emails for dispute updates' },
                    ].map(item => (
                      <div key={item.key} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div><p className="font-medium text-gray-900">{item.label}</p><p className="text-sm text-gray-600">{item.desc}</p></div>
                        <Toggle checked={emailSettings[item.key]} onChange={v => setEmailSettings({...emailSettings, [item.key]: v})} />
                      </div>
                    ))}
                  </div>
                </div>
                <div className="flex justify-end"><SaveButton onClick={simulateSave} label="Save Email Settings" /></div>
              </div>
            )}

            {/* ==================== DATA & ACCOUNT (All roles) ==================== */}
            {activeTab === 'data' && (
              <div className="space-y-6">
                {/* Data Export */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2"><Download size={20} /> Export Your Data</h2>
                  <p className="text-sm text-gray-600 mb-4">Download a copy of all your data stored on BazaarCo, including profile info, orders, reviews, and activity.</p>
                  <button onClick={() => setShowExportModal(true)} className="bg-blue-600 text-white px-6 py-2.5 rounded-lg font-medium hover:bg-blue-700 flex items-center gap-2"><Download size={16} /> Request Data Export</button>
                </div>

                {/* Connected accounts */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2"><ExternalLink size={20} /> Connected Accounts</h2>
                  <div className="space-y-3">
                    {[
                      { name: 'Google', connected: false, icon: '🔍' },
                      { name: 'Facebook', connected: false, icon: '📘' },
                    ].map(acct => (
                      <div key={acct.name} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <span className="text-xl">{acct.icon}</span>
                          <div><p className="font-medium text-gray-900">{acct.name}</p><p className="text-sm text-gray-500">{acct.connected ? 'Connected' : 'Not connected'}</p></div>
                        </div>
                        <button className={`px-4 py-2 rounded-lg text-sm font-medium ${acct.connected ? 'bg-red-100 text-red-700 hover:bg-red-200' : 'bg-blue-100 text-blue-700 hover:bg-blue-200'}`}>{acct.connected ? 'Disconnect' : 'Connect'}</button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Danger Zone */}
                <div className="bg-white rounded-xl shadow-sm border border-red-200 p-6">
                  <h2 className="text-lg font-semibold text-red-600 mb-4 flex items-center gap-2"><AlertTriangle size={20} /> Danger Zone</h2>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 border border-amber-200 rounded-lg bg-amber-50">
                      <div><p className="font-medium text-gray-900">Deactivate Account</p><p className="text-sm text-gray-600">Temporarily hide your account. You can reactivate anytime.</p></div>
                      <button className="px-4 py-2 border border-amber-400 text-amber-700 rounded-lg text-sm font-medium hover:bg-amber-100">Deactivate</button>
                    </div>
                    <div className="flex items-center justify-between p-4 border border-red-200 rounded-lg bg-red-50">
                      <div><p className="font-medium text-gray-900">Delete Account Permanently</p><p className="text-sm text-gray-600">This will permanently delete your account and all data. <strong>This cannot be undone.</strong></p></div>
                      <button onClick={() => setShowDeleteModal(true)} className="px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-medium hover:bg-red-700">Delete Account</button>
                    </div>
                  </div>
                </div>

                {/* Logout */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <div className="flex items-center justify-between">
                    <div><h3 className="font-medium text-gray-900">Sign Out</h3><p className="text-sm text-gray-600">Log out of your BazaarCo account on this device.</p></div>
                    <button onClick={() => { logout(); navigate('/'); }} className="px-4 py-2 bg-gray-800 text-white rounded-lg text-sm font-medium hover:bg-gray-900 flex items-center gap-2"><LogOut size={16} /> Sign Out</button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
      <Footer />

      {/* ==================== DELETE ACCOUNT MODAL ==================== */}
      {showDeleteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white rounded-2xl max-w-md w-full p-6">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4"><AlertTriangle className="w-8 h-8 text-red-600" /></div>
              <h2 className="text-xl font-bold text-gray-900">Delete Your Account?</h2>
              <p className="text-gray-600 mt-2 text-sm">This will permanently delete your account, order history, reviews, and all associated data. This action <strong>cannot be reversed</strong>.</p>
            </div>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Type <strong>DELETE</strong> to confirm</label>
              <input type="text" value={deleteConfirmText} onChange={e => setDeleteConfirmText(e.target.value)} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500" placeholder="DELETE" />
            </div>
            <div className="flex gap-3">
              <button onClick={() => { setShowDeleteModal(false); setDeleteConfirmText(''); }} className="flex-1 px-4 py-2.5 bg-gray-100 rounded-lg font-medium hover:bg-gray-200">Cancel</button>
              <button onClick={handleDeleteAccount} disabled={deleteConfirmText !== 'DELETE' || saving} className="flex-1 px-4 py-2.5 bg-red-600 text-white rounded-lg font-medium hover:bg-red-700 disabled:opacity-50 flex items-center justify-center gap-2">
                {saving ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <Trash2 size={16} />}
                {saving ? 'Deleting...' : 'Delete Forever'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================== EXPORT DATA MODAL ==================== */}
      {showExportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white rounded-2xl max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-6"><h2 className="text-lg font-bold text-gray-900">Export Your Data</h2><button onClick={() => setShowExportModal(false)} className="p-2 hover:bg-gray-100 rounded-full"><X size={20} /></button></div>
            <p className="text-sm text-gray-600 mb-4">Select what data you want to export. We'll email you a download link within 24 hours.</p>
            <div className="space-y-2 mb-6">
              {['Profile Information', 'Order History', 'Reviews & Ratings', 'Wishlist', 'Messages', 'Activity Log'].map(item => (
                <label key={item} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100">
                  <input type="checkbox" defaultChecked className="w-4 h-4 text-red-600 rounded" /><span className="text-sm font-medium text-gray-900">{item}</span>
                </label>
              ))}
            </div>
            <div className="flex gap-3">
              <button onClick={() => setShowExportModal(false)} className="flex-1 px-4 py-2.5 bg-gray-100 rounded-lg font-medium hover:bg-gray-200">Cancel</button>
              <button onClick={handleExportData} disabled={saving} className="flex-1 px-4 py-2.5 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50 flex items-center justify-center gap-2">
                {saving ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <Download size={16} />}
                {saving ? 'Preparing...' : 'Export Data'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
