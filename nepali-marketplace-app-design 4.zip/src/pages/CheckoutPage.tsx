import { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Shield, 
  Truck, 
  CreditCard,
  Smartphone,
  Building2,
  MapPin,
  Clock,
  CheckCircle2,
  Lock,
  ArrowRight,
  ArrowLeft,
  AlertCircle,
  Package,
  RotateCcw,
  MessageCircle,
  ChevronDown,
  ChevronUp,
  ShoppingBag
} from 'lucide-react';
import { Navbar } from '@/components/Navbar';
import { useApp, ShippingAddress } from '@/context/AppContext';

type PaymentMethod = 'esewa' | 'khalti' | 'bank' | 'cod';

export function CheckoutPage() {
  const { state, getCartTotal, placeOrder, getCartCount } = useApp();
  
  const [step, setStep] = useState(1);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod | null>(null);
  const [showOrderSummary, setShowOrderSummary] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [orderComplete, setOrderComplete] = useState(false);
  const [orderId, setOrderId] = useState('');
  
  const [shippingInfo, setShippingInfo] = useState<ShippingAddress>({
    fullName: state.user?.name || '',
    phone: state.user?.phone || '',
    email: state.user?.email || '',
    address: '',
    city: '',
    landmark: '',
    instructions: ''
  });

  const cartItems = state.cart;
  const subtotal = getCartTotal();
  const deliveryFee = subtotal > 2000 ? 0 : 100;
  const codFee = paymentMethod === 'cod' ? 50 : 0;
  const total = subtotal + deliveryFee + codFee;

  const handlePlaceOrder = () => {
    setIsProcessing(true);
    setTimeout(() => {
      const order = placeOrder(shippingInfo, paymentMethod || 'cod');
      setOrderId(order.id);
      setIsProcessing(false);
      setOrderComplete(true);
    }, 2000);
  };

  // Redirect if cart is empty
  if (cartItems.length === 0 && !orderComplete) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="max-w-2xl mx-auto px-4 py-16 text-center">
          <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <ShoppingBag className="w-12 h-12 text-gray-400" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Your cart is empty</h1>
          <p className="text-gray-600 mb-6">Add some items to your cart before checkout.</p>
          <Link
            to="/"
            className="inline-flex items-center gap-2 bg-red-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-red-700 transition-colors"
          >
            Start Shopping
            <ArrowRight size={18} />
          </Link>
        </div>
      </div>
    );
  }

  if (orderComplete) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="max-w-2xl mx-auto px-4 py-16 text-center">
          {/* Success Animation */}
          <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6 animate-bounce">
            <CheckCircle2 className="w-12 h-12 text-green-600" />
          </div>
          
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Order Placed Successfully!</h1>
          <p className="text-gray-600 mb-2">Order #{orderId}</p>
          
          {/* Trust Reassurance */}
          <div className="bg-green-50 border border-green-200 rounded-xl p-6 my-8 text-left">
            <h3 className="font-semibold text-green-900 mb-4 flex items-center gap-2">
              <Shield className="w-5 h-5" />
              Your Order is Protected
            </h3>
            <div className="space-y-3 text-sm">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium text-green-900">Payment Secured</p>
                  <p className="text-green-800">Your payment is held safely until you receive your order</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium text-green-900">Verified Sellers</p>
                  <p className="text-green-800">All sellers in your order are verified by BazaarCo</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium text-green-900">Easy Returns</p>
                  <p className="text-green-800">7-day hassle-free returns if something's not right</p>
                </div>
              </div>
            </div>
          </div>

          {/* What's Next */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-8">
            <h3 className="font-semibold text-gray-900 mb-4">What happens next?</h3>
            <div className="flex items-center justify-between text-sm">
              <div className="flex flex-col items-center gap-2">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                </div>
                <span className="text-gray-600">Order Placed</span>
              </div>
              <div className="flex-1 h-1 bg-gray-200 mx-2" />
              <div className="flex flex-col items-center gap-2">
                <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                  <Package className="w-5 h-5 text-gray-400" />
                </div>
                <span className="text-gray-600">Processing</span>
              </div>
              <div className="flex-1 h-1 bg-gray-200 mx-2" />
              <div className="flex flex-col items-center gap-2">
                <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                  <Truck className="w-5 h-5 text-gray-400" />
                </div>
                <span className="text-gray-600">Shipped</span>
              </div>
              <div className="flex-1 h-1 bg-gray-200 mx-2" />
              <div className="flex flex-col items-center gap-2">
                <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                  <CheckCircle2 className="w-5 h-5 text-gray-400" />
                </div>
                <span className="text-gray-600">Delivered</span>
              </div>
            </div>
            <p className="text-sm text-gray-600 mt-4">
              <Clock className="w-4 h-4 inline mr-1" />
              Estimated delivery: <strong>3-5 business days</strong>
            </p>
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link
              to="/"
              className="inline-flex items-center justify-center gap-2 bg-red-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-red-700 transition-colors"
            >
              Continue Shopping
            </Link>
            <Link
              to="/orders"
              className="inline-flex items-center justify-center gap-2 bg-gray-100 text-gray-700 px-6 py-3 rounded-lg font-semibold hover:bg-gray-200 transition-colors"
            >
              <Package size={18} />
              Track Order
            </Link>
          </div>

          {/* Quick Support */}
          <div className="mt-8 p-4 bg-blue-50 rounded-xl">
            <p className="text-blue-800 text-sm">
              <MessageCircle className="w-4 h-4 inline mr-1" />
              Have questions? <button className="font-semibold underline">Chat with us</button> or call 01-4XXXXXX
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="max-w-6xl mx-auto px-4 py-8">
        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-center">
            <div className="flex items-center">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${step >= 1 ? 'bg-red-600 text-white' : 'bg-gray-200 text-gray-600'}`}>
                1
              </div>
              <span className={`ml-2 font-medium ${step >= 1 ? 'text-gray-900' : 'text-gray-500'}`}>Shipping</span>
            </div>
            <div className={`w-16 h-1 mx-4 ${step >= 2 ? 'bg-red-600' : 'bg-gray-200'}`} />
            <div className="flex items-center">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${step >= 2 ? 'bg-red-600 text-white' : 'bg-gray-200 text-gray-600'}`}>
                2
              </div>
              <span className={`ml-2 font-medium ${step >= 2 ? 'text-gray-900' : 'text-gray-500'}`}>Payment</span>
            </div>
            <div className={`w-16 h-1 mx-4 ${step >= 3 ? 'bg-red-600' : 'bg-gray-200'}`} />
            <div className="flex items-center">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${step >= 3 ? 'bg-red-600 text-white' : 'bg-gray-200 text-gray-600'}`}>
                3
              </div>
              <span className={`ml-2 font-medium ${step >= 3 ? 'text-gray-900' : 'text-gray-500'}`}>Review</span>
            </div>
          </div>
        </div>

        {/* Trust Banner */}
        <div className="bg-green-50 border border-green-200 rounded-xl p-4 mb-6">
          <div className="flex items-center justify-center gap-2 text-green-800">
            <Lock className="w-5 h-5 text-green-600" />
            <span className="font-medium">Secure Checkout</span>
            <span className="text-green-700">— Your information is encrypted and protected</span>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Step 1: Shipping */}
            {step === 1 && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-red-600" />
                  Shipping Information
                </h2>

                <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); setStep(2); }}>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Full Name *</label>
                      <input
                        type="text"
                        value={shippingInfo.fullName}
                        onChange={(e) => setShippingInfo({...shippingInfo, fullName: e.target.value})}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                        placeholder="Ram Bahadur Shrestha"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number *</label>
                      <input
                        type="tel"
                        value={shippingInfo.phone}
                        onChange={(e) => setShippingInfo({...shippingInfo, phone: e.target.value})}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                        placeholder="98XXXXXXXX"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                    <input
                      type="email"
                      value={shippingInfo.email}
                      onChange={(e) => setShippingInfo({...shippingInfo, email: e.target.value})}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                      placeholder="you@example.com (for order updates)"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Delivery Address *</label>
                    <input
                      type="text"
                      value={shippingInfo.address}
                      onChange={(e) => setShippingInfo({...shippingInfo, address: e.target.value})}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                      placeholder="House no., Street name, Area"
                      required
                    />
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">City *</label>
                      <select
                        value={shippingInfo.city}
                        onChange={(e) => setShippingInfo({...shippingInfo, city: e.target.value})}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                        required
                      >
                        <option value="">Select city</option>
                        <option value="Kathmandu">Kathmandu</option>
                        <option value="Lalitpur">Lalitpur</option>
                        <option value="Bhaktapur">Bhaktapur</option>
                        <option value="Pokhara">Pokhara</option>
                        <option value="Biratnagar">Biratnagar</option>
                        <option value="Birgunj">Birgunj</option>
                        <option value="Dharan">Dharan</option>
                        <option value="Butwal">Butwal</option>
                        <option value="Hetauda">Hetauda</option>
                        <option value="Nepalgunj">Nepalgunj</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Nearest Landmark</label>
                      <input
                        type="text"
                        value={shippingInfo.landmark}
                        onChange={(e) => setShippingInfo({...shippingInfo, landmark: e.target.value})}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                        placeholder="Near temple, school, etc."
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Delivery Instructions (Optional)</label>
                    <textarea
                      value={shippingInfo.instructions}
                      onChange={(e) => setShippingInfo({...shippingInfo, instructions: e.target.value})}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                      placeholder="Any special instructions for delivery"
                      rows={2}
                    />
                  </div>

                  <div className="mt-6 flex justify-between">
                    <Link to="/cart" className="flex items-center gap-2 text-gray-600 hover:text-gray-800">
                      <ArrowLeft size={18} />
                      Back to Cart
                    </Link>
                    <button
                      type="submit"
                      className="bg-red-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-red-700 transition-colors flex items-center gap-2"
                    >
                      Continue to Payment
                      <ArrowRight size={18} />
                    </button>
                  </div>
                </form>
              </div>
            )}

            {/* Step 2: Payment */}
            {step === 2 && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-red-600" />
                  Payment Method
                </h2>

                {/* Payment Protection Notice */}
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                  <div className="flex gap-3">
                    <Shield className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-blue-900">Payment Protection Guarantee</h4>
                      <p className="text-sm text-blue-800 mt-1">
                        Your payment is held securely by BazaarCo. Seller receives payment only after you confirm delivery and satisfaction.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  {/* eSewa */}
                  <label className={`flex items-center gap-4 p-4 border-2 rounded-xl cursor-pointer transition-all ${paymentMethod === 'esewa' ? 'border-red-500 bg-red-50' : 'border-gray-200 hover:border-gray-300'}`}>
                    <input
                      type="radio"
                      name="payment"
                      checked={paymentMethod === 'esewa'}
                      onChange={() => setPaymentMethod('esewa')}
                      className="w-5 h-5 text-red-600"
                    />
                    <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center text-white font-bold">
                      e₹
                    </div>
                    <div className="flex-1">
                      <div className="font-medium text-gray-900">eSewa</div>
                      <div className="text-sm text-gray-600">Pay with your eSewa wallet</div>
                    </div>
                    <span className="text-xs text-green-600 font-medium bg-green-100 px-2 py-1 rounded">Popular</span>
                  </label>

                  {/* Khalti */}
                  <label className={`flex items-center gap-4 p-4 border-2 rounded-xl cursor-pointer transition-all ${paymentMethod === 'khalti' ? 'border-red-500 bg-red-50' : 'border-gray-200 hover:border-gray-300'}`}>
                    <input
                      type="radio"
                      name="payment"
                      checked={paymentMethod === 'khalti'}
                      onChange={() => setPaymentMethod('khalti')}
                      className="w-5 h-5 text-red-600"
                    />
                    <div className="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center">
                      <Smartphone className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="font-medium text-gray-900">Khalti</div>
                      <div className="text-sm text-gray-600">Pay with Khalti digital wallet</div>
                    </div>
                  </label>

                  {/* Bank Transfer */}
                  <label className={`flex items-center gap-4 p-4 border-2 rounded-xl cursor-pointer transition-all ${paymentMethod === 'bank' ? 'border-red-500 bg-red-50' : 'border-gray-200 hover:border-gray-300'}`}>
                    <input
                      type="radio"
                      name="payment"
                      checked={paymentMethod === 'bank'}
                      onChange={() => setPaymentMethod('bank')}
                      className="w-5 h-5 text-red-600"
                    />
                    <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center">
                      <Building2 className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="font-medium text-gray-900">Bank Transfer / Card</div>
                      <div className="text-sm text-gray-600">Pay via bank or debit/credit card</div>
                    </div>
                  </label>

                  {/* COD */}
                  <label className={`flex items-center gap-4 p-4 border-2 rounded-xl cursor-pointer transition-all ${paymentMethod === 'cod' ? 'border-red-500 bg-red-50' : 'border-gray-200 hover:border-gray-300'}`}>
                    <input
                      type="radio"
                      name="payment"
                      checked={paymentMethod === 'cod'}
                      onChange={() => setPaymentMethod('cod')}
                      className="w-5 h-5 text-red-600"
                    />
                    <div className="w-12 h-12 bg-amber-500 rounded-lg flex items-center justify-center text-white font-bold">
                      ₨
                    </div>
                    <div className="flex-1">
                      <div className="font-medium text-gray-900">Cash on Delivery</div>
                      <div className="text-sm text-gray-600">Pay when you receive your order</div>
                    </div>
                    <span className="text-xs text-amber-700 font-medium bg-amber-100 px-2 py-1 rounded">+Rs. 50</span>
                  </label>
                </div>

                {paymentMethod === 'cod' && (
                  <div className="mt-4 bg-amber-50 border border-amber-200 rounded-lg p-4 flex gap-3">
                    <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium">Cash on Delivery Fee: Rs. 50</p>
                      <p className="mt-1">Please keep exact change ready. Our delivery partner will collect payment upon delivery.</p>
                    </div>
                  </div>
                )}

                <div className="mt-6 flex justify-between">
                  <button onClick={() => setStep(1)} className="flex items-center gap-2 text-gray-600 hover:text-gray-800">
                    <ArrowLeft size={18} />
                    Back
                  </button>
                  <button
                    onClick={() => setStep(3)}
                    disabled={!paymentMethod}
                    className="bg-red-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-red-700 transition-colors flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Review Order
                    <ArrowRight size={18} />
                  </button>
                </div>
              </div>
            )}

            {/* Step 3: Review */}
            {step === 3 && (
              <div className="space-y-6">
                {/* Order Review */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <h2 className="text-xl font-bold text-gray-900 mb-6">Review Your Order</h2>

                  {/* Items */}
                  <div className="space-y-4 mb-6">
                    {cartItems.map((item) => (
                      <div key={item.product.id} className="flex gap-4">
                        <img src={item.product.image} alt={item.product.name} className="w-16 h-16 object-cover rounded-lg" />
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900">{item.product.name}</h4>
                          <p className="text-sm text-gray-600">
                            Sold by: {item.product.seller}
                            {item.product.isVerified && (
                              <span className="inline-flex items-center gap-1 ml-2 text-green-700">
                                <CheckCircle2 size={12} /> Verified
                              </span>
                            )}
                          </p>
                          <p className="text-sm text-gray-600">Qty: {item.quantity}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold">Rs. {(item.product.price * item.quantity).toLocaleString()}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Shipping Summary */}
                  <div className="border-t border-gray-100 pt-4">
                    <h4 className="font-medium text-gray-900 mb-2">Shipping to:</h4>
                    <p className="text-gray-600">{shippingInfo.fullName}</p>
                    <p className="text-gray-600">{shippingInfo.address}</p>
                    <p className="text-gray-600">{shippingInfo.city}</p>
                    <p className="text-gray-600">Phone: {shippingInfo.phone}</p>
                  </div>
                </div>

                {/* Before You Pay - Trust Checklist */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <h3 className="font-bold text-gray-900 mb-4">Before You Pay — Our Promise to You</h3>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="font-medium text-gray-900">All sellers verified</p>
                        <p className="text-sm text-gray-600">Every seller in your order has passed our verification process</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="font-medium text-gray-900">7-day easy returns</p>
                        <p className="text-sm text-gray-600">Not satisfied? Return within 7 days for a full refund</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="font-medium text-gray-900">Payment protected</p>
                        <p className="text-sm text-gray-600">Your money is safe until you confirm satisfaction</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="font-medium text-gray-900">1-tap dispute</p>
                        <p className="text-sm text-gray-600">Any issues? Report in 1 tap from your order page</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex justify-between items-center">
                  <button onClick={() => setStep(2)} className="flex items-center gap-2 text-gray-600 hover:text-gray-800">
                    <ArrowLeft size={18} />
                    Back
                  </button>
                  <button
                    onClick={handlePlaceOrder}
                    disabled={isProcessing}
                    className="bg-gradient-to-r from-red-600 to-red-700 text-white px-8 py-4 rounded-xl font-semibold hover:from-red-700 hover:to-red-800 transition-all flex items-center gap-2 shadow-lg shadow-red-600/25 disabled:opacity-70"
                  >
                    {isProcessing ? (
                      <>
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Lock size={18} />
                        Place Order — Rs. {total.toLocaleString()}
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Order Summary Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 sticky top-24">
              {/* Mobile Toggle */}
              <button 
                className="lg:hidden w-full flex items-center justify-between mb-4"
                onClick={() => setShowOrderSummary(!showOrderSummary)}
              >
                <span className="font-bold text-gray-900">Order Summary ({getCartCount()} items)</span>
                {showOrderSummary ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
              </button>

              <div className={`${showOrderSummary ? 'block' : 'hidden lg:block'}`}>
                <h3 className="font-bold text-gray-900 mb-4 hidden lg:block">Order Summary</h3>

                {/* Items Preview */}
                <div className="space-y-3 mb-4 max-h-60 overflow-y-auto">
                  {cartItems.map((item) => (
                    <div key={item.product.id} className="flex gap-3">
                      <img src={item.product.image} alt={item.product.name} className="w-12 h-12 object-cover rounded-lg" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900 truncate">{item.product.name}</p>
                        <p className="text-xs text-gray-600">Qty: {item.quantity}</p>
                      </div>
                      <p className="text-sm font-medium">Rs. {(item.product.price * item.quantity).toLocaleString()}</p>
                    </div>
                  ))}
                </div>

                {/* Totals */}
                <div className="border-t border-gray-100 pt-4 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Subtotal</span>
                    <span>Rs. {subtotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Delivery</span>
                    {deliveryFee === 0 ? (
                      <span className="text-green-600">FREE</span>
                    ) : (
                      <span>Rs. {deliveryFee}</span>
                    )}
                  </div>
                  {codFee > 0 && (
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">COD Fee</span>
                      <span>Rs. {codFee}</span>
                    </div>
                  )}
                  <div className="flex justify-between font-bold text-lg pt-2 border-t border-gray-100">
                    <span>Total</span>
                    <span>Rs. {total.toLocaleString()}</span>
                  </div>
                </div>

                {/* Trust Icons */}
                <div className="mt-6 pt-4 border-t border-gray-100 space-y-2">
                  <div className="flex items-center gap-2 text-xs text-gray-600">
                    <Shield size={14} className="text-green-600" />
                    <span>100% Purchase Protection</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-gray-600">
                    <RotateCcw size={14} className="text-blue-600" />
                    <span>7-Day Easy Returns</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-gray-600">
                    <Truck size={14} className="text-purple-600" />
                    <span>Tracked Delivery</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
