/**
 * BazaarCo Service Layer
 * ----------------------
 * All backend operations abstracted here.
 * Currently uses localStorage. To switch to a real backend,
 * replace the method implementations — all consumers stay the same.
 */

// ========== STORAGE HELPERS ==========
const store = {
  get: <T>(key: string, fallback: T): T => {
    try { const d = localStorage.getItem(`bzc_${key}`); return d ? JSON.parse(d) : fallback; } catch { return fallback; }
  },
  set: <T>(key: string, value: T) => {
    try { localStorage.setItem(`bzc_${key}`, JSON.stringify(value)); } catch (e) { console.error('Storage error:', e); }
  },
  remove: (key: string) => localStorage.removeItem(`bzc_${key}`),
};

// ========== TYPES ==========
export interface Review {
  id: string;
  productId: string;
  userId: string;
  userName: string;
  rating: number;
  title: string;
  comment: string;
  photos: string[];
  verified: boolean;
  helpful: number;
  createdAt: string;
  sellerReply?: string;
  sellerReplyDate?: string;
}

export interface ChatMessage {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  senderType: 'buyer' | 'seller' | 'system';
  message: string;
  timestamp: string;
  read: boolean;
  attachments?: string[];
}

export interface Conversation {
  id: string;
  buyerId: string;
  buyerName: string;
  sellerId: string;
  sellerName: string;
  productId?: string;
  productName?: string;
  orderId?: string;
  lastMessage: string;
  lastMessageTime: string;
  unreadBuyer: number;
  unreadSeller: number;
  status: 'active' | 'closed';
}

export interface EscrowTransaction {
  id: string;
  orderId: string;
  buyerId: string;
  sellerId: string;
  amount: number;
  status: 'held' | 'released' | 'refunded' | 'disputed';
  createdAt: string;
  releasedAt?: string;
  buyerConfirmed: boolean;
  autoReleaseDate: string;
}

export interface PaymentTransaction {
  id: string;
  orderId: string;
  method: 'esewa' | 'khalti' | 'bank' | 'cod';
  amount: number;
  status: 'pending' | 'processing' | 'completed' | 'failed' | 'refunded';
  transactionRef?: string;
  createdAt: string;
}

// ========== SEED DATA ==========
const seedReviews: Review[] = [
  { id: 'rv1', productId: 'p1', userId: 'u1', userName: 'Ram B.', rating: 5, title: 'Excellent phone!', comment: 'Battery life is amazing, camera quality is top-notch. Delivery was fast and well-packaged.', photos: [], verified: true, helpful: 12, createdAt: '2024-02-10T10:00:00Z' },
  { id: 'rv2', productId: 'p1', userId: 'u2', userName: 'Sita K.', rating: 4, title: 'Good but pricey', comment: 'Great phone overall. The display is beautiful. Only downside is the price.', photos: [], verified: true, helpful: 5, createdAt: '2024-02-08T14:30:00Z' },
  { id: 'rv3', productId: 'p1', userId: 'u3', userName: 'Hari P.', rating: 5, title: 'Best purchase this year', comment: 'Fast shipping, product exactly as described. The 5G speed is incredible in Kathmandu.', photos: [], verified: true, helpful: 8, createdAt: '2024-01-25T09:15:00Z' },
  { id: 'rv4', productId: 'p4', userId: 'u4', userName: 'Maya T.', rating: 5, title: 'Authentic quality!', comment: 'Beautiful handwoven topi. The craftsmanship is outstanding. Perfect for Dashain.', photos: [], verified: true, helpful: 15, createdAt: '2024-02-12T11:00:00Z', sellerReply: 'Thank you Maya ji! We are glad you loved it. Namaste!', sellerReplyDate: '2024-02-12T15:00:00Z' },
  { id: 'rv5', productId: 'p5', userId: 'u5', userName: 'John D.', rating: 5, title: 'Incredibly soft', comment: 'This pashmina is the real deal. So soft and warm. Bought it as a gift and the recipient loved it.', photos: [], verified: true, helpful: 20, createdAt: '2024-02-01T16:45:00Z' },
  { id: 'rv6', productId: 'p2', userId: 'u1', userName: 'Ram B.', rating: 4, title: 'Great sound quality', comment: 'ANC works well. Battery life is good. Comfortable for long use.', photos: [], verified: true, helpful: 7, createdAt: '2024-02-05T08:20:00Z' },
  { id: 'rv7', productId: 'p9', userId: 'u2', userName: 'Sita K.', rating: 5, title: 'Perfect for meditation', comment: 'The sound resonance is beautiful. Authentic Bhaktapur craftsmanship.', photos: [], verified: true, helpful: 11, createdAt: '2024-01-28T13:10:00Z' },
  { id: 'rv8', productId: 's5', userId: 'u3', userName: 'Hari P.', rating: 4, title: 'Great condition for used', comment: 'Battery at 89% as described. No scratches. Escrow payment made me feel safe.', photos: [], verified: true, helpful: 6, createdAt: '2024-02-11T10:30:00Z' },
];

const seedConversations: Conversation[] = [
  { id: 'conv1', buyerId: 'u1', buyerName: 'Ram Bahadur', sellerId: 'seller-1', sellerName: 'Tech Hub Nepal', productId: 'p1', productName: 'Smartphone Pro Max', lastMessage: 'Is this available in blue color?', lastMessageTime: '2024-02-15T10:30:00Z', unreadBuyer: 1, unreadSeller: 0, status: 'active' },
  { id: 'conv2', buyerId: 'u2', buyerName: 'Sita Kumari', sellerId: 'seller-4', sellerName: 'Himalayan Crafts', productId: 'p4', productName: 'Dhaka Topi', lastMessage: 'Thank you! Order received in perfect condition.', lastMessageTime: '2024-02-14T15:00:00Z', unreadBuyer: 0, unreadSeller: 0, status: 'active' },
  { id: 'conv3', buyerId: 'u3', buyerName: 'Hari Prasad', sellerId: 'seller-5', sellerName: 'Himalayan Wonders', orderId: 'ORD-7819', productName: 'Pashmina Shawl', lastMessage: 'I have initiated a dispute regarding the color mismatch.', lastMessageTime: '2024-02-13T09:00:00Z', unreadBuyer: 0, unreadSeller: 1, status: 'active' },
];

const seedMessages: ChatMessage[] = [
  { id: 'm1', conversationId: 'conv1', senderId: 'u1', senderName: 'Ram Bahadur', senderType: 'buyer', message: 'Hi, is this phone available in Ocean Blue color?', timestamp: '2024-02-15T10:00:00Z', read: true },
  { id: 'm2', conversationId: 'conv1', senderId: 'seller-1', senderName: 'Tech Hub Nepal', senderType: 'seller', message: 'Yes! Ocean Blue is in stock. Would you like to order?', timestamp: '2024-02-15T10:15:00Z', read: true },
  { id: 'm3', conversationId: 'conv1', senderId: 'u1', senderName: 'Ram Bahadur', senderType: 'buyer', message: 'Great! Can you confirm warranty details?', timestamp: '2024-02-15T10:25:00Z', read: true },
  { id: 'm4', conversationId: 'conv1', senderId: 'seller-1', senderName: 'Tech Hub Nepal', senderType: 'seller', message: 'Full 2-year manufacturer warranty. We also provide 7-day BazaarCo return guarantee.', timestamp: '2024-02-15T10:30:00Z', read: false },
  { id: 'm5', conversationId: 'conv2', senderId: 'u2', senderName: 'Sita Kumari', senderType: 'buyer', message: 'What sizes are available for the Dhaka Topi?', timestamp: '2024-02-14T09:00:00Z', read: true },
  { id: 'm6', conversationId: 'conv2', senderId: 'seller-4', senderName: 'Himalayan Crafts', senderType: 'seller', message: 'We have S, M, L, and XL. For reference, M fits head circumference 56-58cm.', timestamp: '2024-02-14T09:30:00Z', read: true },
  { id: 'm7', conversationId: 'conv2', senderId: 'u2', senderName: 'Sita Kumari', senderType: 'buyer', message: 'Thank you! Order received in perfect condition.', timestamp: '2024-02-14T15:00:00Z', read: true },
  { id: 'm8', conversationId: 'conv3', senderId: 'u3', senderName: 'Hari Prasad', senderType: 'buyer', message: 'The shawl color is different from the photos. I ordered Navy Blue but received Black.', timestamp: '2024-02-13T08:30:00Z', read: true },
  { id: 'm9', conversationId: 'conv3', senderId: 'system', senderName: 'BazaarCo System', senderType: 'system', message: '⚠️ A dispute has been opened for this conversation. Seller payout is paused.', timestamp: '2024-02-13T08:35:00Z', read: true },
  { id: 'm10', conversationId: 'conv3', senderId: 'u3', senderName: 'Hari Prasad', senderType: 'buyer', message: 'I have initiated a dispute regarding the color mismatch.', timestamp: '2024-02-13T09:00:00Z', read: true },
];

// ========== REVIEW SERVICE ==========
export const ReviewService = {
  getByProduct: (productId: string): Review[] => {
    const all = store.get<Review[]>('reviews', seedReviews);
    return all.filter(r => r.productId === productId).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  },

  getStats: (productId: string) => {
    const reviews = ReviewService.getByProduct(productId);
    if (reviews.length === 0) return { avg: 0, count: 0, distribution: [0, 0, 0, 0, 0] };
    const avg = reviews.reduce((s, r) => s + r.rating, 0) / reviews.length;
    const distribution = [5, 4, 3, 2, 1].map(star => reviews.filter(r => r.rating === star).length);
    return { avg: Math.round(avg * 10) / 10, count: reviews.length, distribution };
  },

  add: (review: Omit<Review, 'id' | 'createdAt' | 'helpful' | 'verified'>): Review => {
    const all = store.get<Review[]>('reviews', seedReviews);
    const newReview: Review = {
      ...review,
      id: `rv-${Date.now()}`,
      createdAt: new Date().toISOString(),
      helpful: 0,
      verified: true,
    };
    all.unshift(newReview);
    store.set('reviews', all);
    return newReview;
  },

  markHelpful: (reviewId: string) => {
    const all = store.get<Review[]>('reviews', seedReviews);
    const idx = all.findIndex(r => r.id === reviewId);
    if (idx >= 0) { all[idx].helpful++; store.set('reviews', all); }
  },

  addSellerReply: (reviewId: string, reply: string) => {
    const all = store.get<Review[]>('reviews', seedReviews);
    const idx = all.findIndex(r => r.id === reviewId);
    if (idx >= 0) { all[idx].sellerReply = reply; all[idx].sellerReplyDate = new Date().toISOString(); store.set('reviews', all); }
  },
};

// ========== CHAT SERVICE ==========
export const ChatService = {
  getConversations: (userId: string, role: 'buyer' | 'seller' = 'buyer'): Conversation[] => {
    const all = store.get<Conversation[]>('conversations', seedConversations);
    return all.filter(c => role === 'buyer' ? c.buyerId === userId : c.sellerId === userId)
      .sort((a, b) => new Date(b.lastMessageTime).getTime() - new Date(a.lastMessageTime).getTime());
  },

  getAllConversations: (): Conversation[] => {
    return store.get<Conversation[]>('conversations', seedConversations);
  },

  getMessages: (conversationId: string): ChatMessage[] => {
    const all = store.get<ChatMessage[]>('messages', seedMessages);
    return all.filter(m => m.conversationId === conversationId)
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  },

  sendMessage: (conversationId: string, senderId: string, senderName: string, senderType: 'buyer' | 'seller', message: string, attachments?: string[]): ChatMessage => {
    const allMsgs = store.get<ChatMessage[]>('messages', seedMessages);
    const allConvs = store.get<Conversation[]>('conversations', seedConversations);
    const newMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      conversationId,
      senderId,
      senderName,
      senderType,
      message,
      timestamp: new Date().toISOString(),
      read: false,
      attachments,
    };
    allMsgs.push(newMsg);
    store.set('messages', allMsgs);

    // Update conversation
    const convIdx = allConvs.findIndex(c => c.id === conversationId);
    if (convIdx >= 0) {
      allConvs[convIdx].lastMessage = message;
      allConvs[convIdx].lastMessageTime = newMsg.timestamp;
      if (senderType === 'buyer') allConvs[convIdx].unreadSeller++;
      else allConvs[convIdx].unreadBuyer++;
      store.set('conversations', allConvs);
    }
    return newMsg;
  },

  startConversation: (buyerId: string, buyerName: string, sellerId: string, sellerName: string, productId?: string, productName?: string, initialMessage?: string): Conversation => {
    const all = store.get<Conversation[]>('conversations', seedConversations);
    // Check if conversation exists
    const existing = all.find(c => c.buyerId === buyerId && c.sellerId === sellerId && c.productId === productId);
    if (existing) return existing;

    const conv: Conversation = {
      id: `conv-${Date.now()}`,
      buyerId, buyerName, sellerId, sellerName,
      productId, productName,
      lastMessage: initialMessage || 'Conversation started',
      lastMessageTime: new Date().toISOString(),
      unreadBuyer: 0, unreadSeller: initialMessage ? 1 : 0,
      status: 'active',
    };
    all.unshift(conv);
    store.set('conversations', all);

    if (initialMessage) {
      ChatService.sendMessage(conv.id, buyerId, buyerName, 'buyer', initialMessage);
    }
    return conv;
  },

  markRead: (conversationId: string, role: 'buyer' | 'seller') => {
    const allConvs = store.get<Conversation[]>('conversations', seedConversations);
    const idx = allConvs.findIndex(c => c.id === conversationId);
    if (idx >= 0) {
      if (role === 'buyer') allConvs[idx].unreadBuyer = 0;
      else allConvs[idx].unreadSeller = 0;
      store.set('conversations', allConvs);
    }
    const allMsgs = store.get<ChatMessage[]>('messages', seedMessages);
    allMsgs.forEach(m => {
      if (m.conversationId === conversationId) m.read = true;
    });
    store.set('messages', allMsgs);
  },

  getTotalUnread: (userId: string, role: 'buyer' | 'seller'): number => {
    const convs = ChatService.getConversations(userId, role);
    return convs.reduce((sum, c) => sum + (role === 'buyer' ? c.unreadBuyer : c.unreadSeller), 0);
  },
};

// ========== ESCROW SERVICE ==========
export const EscrowService = {
  create: (orderId: string, buyerId: string, sellerId: string, amount: number): EscrowTransaction => {
    const all = store.get<EscrowTransaction[]>('escrow', []);
    const txn: EscrowTransaction = {
      id: `esc-${Date.now()}`,
      orderId, buyerId, sellerId, amount,
      status: 'held',
      createdAt: new Date().toISOString(),
      buyerConfirmed: false,
      autoReleaseDate: new Date(Date.now() + 48 * 60 * 60 * 1000).toISOString(),
    };
    all.push(txn);
    store.set('escrow', all);
    return txn;
  },

  getByOrder: (orderId: string): EscrowTransaction | undefined => {
    const all = store.get<EscrowTransaction[]>('escrow', []);
    return all.find(e => e.orderId === orderId);
  },

  buyerConfirm: (escrowId: string): EscrowTransaction | undefined => {
    const all = store.get<EscrowTransaction[]>('escrow', []);
    const idx = all.findIndex(e => e.id === escrowId);
    if (idx >= 0) {
      all[idx].buyerConfirmed = true;
      all[idx].status = 'released';
      all[idx].releasedAt = new Date().toISOString();
      store.set('escrow', all);
      return all[idx];
    }
    return undefined;
  },

  dispute: (escrowId: string): EscrowTransaction | undefined => {
    const all = store.get<EscrowTransaction[]>('escrow', []);
    const idx = all.findIndex(e => e.id === escrowId);
    if (idx >= 0) {
      all[idx].status = 'disputed';
      store.set('escrow', all);
      return all[idx];
    }
    return undefined;
  },

  refund: (escrowId: string): EscrowTransaction | undefined => {
    const all = store.get<EscrowTransaction[]>('escrow', []);
    const idx = all.findIndex(e => e.id === escrowId);
    if (idx >= 0) {
      all[idx].status = 'refunded';
      store.set('escrow', all);
      return all[idx];
    }
    return undefined;
  },
};

// ========== PAYMENT SERVICE ==========
export const PaymentService = {
  initiate: (orderId: string, method: PaymentTransaction['method'], amount: number): PaymentTransaction => {
    const all = store.get<PaymentTransaction[]>('payments', []);
    const txn: PaymentTransaction = {
      id: `pay-${Date.now()}`,
      orderId, method, amount,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };
    all.push(txn);
    store.set('payments', all);
    return txn;
  },

  process: (paymentId: string): Promise<PaymentTransaction> => {
    return new Promise((resolve) => {
      setTimeout(() => {
        const all = store.get<PaymentTransaction[]>('payments', []);
        const idx = all.findIndex(p => p.id === paymentId);
        if (idx >= 0) {
          all[idx].status = 'completed';
          all[idx].transactionRef = `TXN${Date.now().toString(36).toUpperCase()}`;
          store.set('payments', all);
          resolve(all[idx]);
        }
      }, 1500);
    });
  },

  getByOrder: (orderId: string): PaymentTransaction | undefined => {
    const all = store.get<PaymentTransaction[]>('payments', []);
    return all.find(p => p.orderId === orderId);
  },

  /** Simulates eSewa payment flow */
  esewaCheckout: (_amount: number, _orderId: string): Promise<{ success: boolean; ref: string }> => {
    return new Promise(resolve => {
      setTimeout(() => resolve({ success: true, ref: `ESEWA-${Date.now().toString(36).toUpperCase()}` }), 2000);
    });
  },

  /** Simulates Khalti payment flow */
  khaltiCheckout: (_amount: number, _orderId: string): Promise<{ success: boolean; ref: string }> => {
    return new Promise(resolve => {
      setTimeout(() => resolve({ success: true, ref: `KHALTI-${Date.now().toString(36).toUpperCase()}` }), 2000);
    });
  },
};

// ========== IMAGE SERVICE ==========
export const ImageService = {
  /** Reads file and returns base64 data URL */
  toBase64: (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  },

  /** Validates image file */
  validate: (file: File): { valid: boolean; error?: string } => {
    const maxSize = 5 * 1024 * 1024; // 5MB
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!allowedTypes.includes(file.type)) return { valid: false, error: 'Only JPG, PNG, GIF, or WebP images are allowed.' };
    if (file.size > maxSize) return { valid: false, error: 'Image must be under 5MB.' };
    return { valid: true };
  },

  /** Simulates upload to Cloudinary — returns a URL */
  upload: async (file: File): Promise<{ url: string; publicId: string }> => {
    const base64 = await ImageService.toBase64(file);
    // In production, replace with actual Cloudinary upload:
    // const formData = new FormData();
    // formData.append('file', file);
    // formData.append('upload_preset', 'your_preset');
    // const res = await fetch('https://api.cloudinary.com/v1_1/your_cloud/image/upload', { method: 'POST', body: formData });
    // return await res.json();
    return { url: base64, publicId: `img_${Date.now()}` };
  },

  /** Upload multiple images */
  uploadMultiple: async (files: File[]): Promise<{ url: string; publicId: string }[]> => {
    return Promise.all(files.map(f => ImageService.upload(f)));
  },
};

// ========== NOTIFICATION SERVICE ==========
export const NotificationService = {
  /** Request browser push permission */
  requestPermission: async (): Promise<boolean> => {
    if (!('Notification' in window)) return false;
    const permission = await Notification.requestPermission();
    return permission === 'granted';
  },

  /** Send browser push notification */
  sendPush: (title: string, body: string, icon?: string) => {
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(title, { body, icon: icon || '/bazaarco-logo.svg', badge: '/bazaarco-logo.svg' });
    }
  },

  /** Simulate email notification (logs to console) */
  sendEmail: (to: string, subject: string, body: string) => {
    console.log(`📧 Email to ${to}: [${subject}] ${body}`);
    // In production: POST to /api/email with real SMTP
  },
};
