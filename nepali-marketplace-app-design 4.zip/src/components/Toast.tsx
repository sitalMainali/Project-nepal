import { useEffect, useState } from 'react';
import { CheckCircle2, AlertCircle, AlertTriangle, Info, X } from 'lucide-react';
import { useApp } from '@/context/AppContext';

export function Toast() {
  const { state, dispatch } = useApp();
  const [visible, setVisible] = useState<string[]>([]);

  useEffect(() => {
    // Show new notifications
    const unreadIds = state.notifications
      .filter(n => !n.read)
      .map(n => n.id)
      .slice(0, 3); // Show max 3 toasts

    setVisible(prev => [...new Set([...prev, ...unreadIds])]);

    // Auto-hide after 4 seconds
    const timers = unreadIds.map(id => {
      return setTimeout(() => {
        setVisible(prev => prev.filter(v => v !== id));
        dispatch({ type: 'MARK_NOTIFICATION_READ', payload: id });
      }, 4000);
    });

    return () => timers.forEach(t => clearTimeout(t));
  }, [state.notifications, dispatch]);

  const getIcon = (type: string) => {
    switch (type) {
      case 'success': return <CheckCircle2 className="w-5 h-5 text-green-600" />;
      case 'error': return <AlertCircle className="w-5 h-5 text-red-600" />;
      case 'warning': return <AlertTriangle className="w-5 h-5 text-amber-600" />;
      default: return <Info className="w-5 h-5 text-blue-600" />;
    }
  };

  const getBgColor = (type: string) => {
    switch (type) {
      case 'success': return 'bg-green-50 border-green-200';
      case 'error': return 'bg-red-50 border-red-200';
      case 'warning': return 'bg-amber-50 border-amber-200';
      default: return 'bg-blue-50 border-blue-200';
    }
  };

  const dismiss = (id: string) => {
    setVisible(prev => prev.filter(v => v !== id));
    dispatch({ type: 'MARK_NOTIFICATION_READ', payload: id });
  };

  const visibleNotifications = state.notifications.filter(n => visible.includes(n.id));

  if (visibleNotifications.length === 0) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm">
      {visibleNotifications.map(notification => (
        <div
          key={notification.id}
          className={`${getBgColor(notification.type)} border rounded-lg p-4 shadow-lg animate-in slide-in-from-right duration-300`}
        >
          <div className="flex items-start gap-3">
            {getIcon(notification.type)}
            <div className="flex-1 min-w-0">
              <p className="font-medium text-gray-900">{notification.title}</p>
              <p className="text-sm text-gray-600 mt-0.5">{notification.message}</p>
            </div>
            <button
              onClick={() => dismiss(notification.id)}
              className="text-gray-400 hover:text-gray-600"
            >
              <X size={16} />
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
