import { useState, useEffect, useRef } from 'react';
import { MessageCircle, X, Send, Image, ChevronLeft, Shield, Phone } from 'lucide-react';
import { ChatService, type Conversation, type ChatMessage } from '@/services/api';
import { useApp } from '@/context/AppContext';

export function ChatWidget() {
  const { state } = useApp();
  const user = state.user;
  const [isOpen, setIsOpen] = useState(false);
  const [activeConv, setActiveConv] = useState<string | null>(null);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const role = user?.type === 'seller' ? 'seller' : 'buyer';
  const userId = user?.id || 'guest';

  useEffect(() => {
    if (isOpen && user) {
      const convs = user.type === 'seller'
        ? ChatService.getAllConversations()
        : ChatService.getConversations(userId, role);
      setConversations(convs);
    }
  }, [isOpen, user, userId, role]);

  useEffect(() => {
    if (activeConv) {
      const msgs = ChatService.getMessages(activeConv);
      setMessages(msgs);
      ChatService.markRead(activeConv, role);
      // Refresh conversations to update unread counts
      const convs = user?.type === 'seller'
        ? ChatService.getAllConversations()
        : ChatService.getConversations(userId, role);
      setConversations(convs);
    }
  }, [activeConv, role, userId, user?.type]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const totalUnread = conversations.reduce((sum, c) => sum + (role === 'buyer' ? c.unreadBuyer : c.unreadSeller), 0);

  const handleSend = () => {
    if (!newMessage.trim() || !activeConv || !user) return;
    const msg = ChatService.sendMessage(
      activeConv, user.id, user.name, role, newMessage.trim()
    );
    setMessages(prev => [...prev, msg]);
    setNewMessage('');
    // Update conversation list
    setConversations(prev => prev.map(c =>
      c.id === activeConv ? { ...c, lastMessage: newMessage.trim(), lastMessageTime: msg.timestamp } : c
    ));
    inputRef.current?.focus();
  };

  const activeConversation = conversations.find(c => c.id === activeConv);

  const formatTime = (ts: string) => {
    const d = new Date(ts);
    const now = new Date();
    const diffMs = now.getTime() - d.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHrs = Math.floor(diffMins / 60);
    if (diffHrs < 24) return `${diffHrs}h ago`;
    return d.toLocaleDateString();
  };

  if (!user) return null;

  return (
    <>
      {/* Floating Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 z-40 w-14 h-14 bg-gradient-to-r from-red-600 to-red-700 text-white rounded-full shadow-xl hover:shadow-2xl transition-all flex items-center justify-center group"
      >
        {isOpen ? <X size={24} /> : <MessageCircle size={24} />}
        {totalUnread > 0 && !isOpen && (
          <span className="absolute -top-1 -right-1 w-6 h-6 bg-blue-600 text-white text-xs rounded-full flex items-center justify-center font-bold animate-bounce">
            {totalUnread}
          </span>
        )}
      </button>

      {/* Chat Panel */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 z-40 w-[380px] max-w-[calc(100vw-48px)] h-[520px] max-h-[calc(100vh-120px)] bg-white rounded-2xl shadow-2xl border border-gray-200 flex flex-col overflow-hidden animate-in slide-in-from-bottom duration-300">
          {/* Header */}
          <div className="bg-gradient-to-r from-red-600 to-red-700 text-white p-4 flex items-center gap-3 flex-shrink-0">
            {activeConv ? (
              <>
                <button onClick={() => setActiveConv(null)} className="p-1 hover:bg-white/20 rounded-full">
                  <ChevronLeft size={20} />
                </button>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold truncate">
                    {role === 'buyer' ? activeConversation?.sellerName : activeConversation?.buyerName}
                  </p>
                  {activeConversation?.productName && (
                    <p className="text-xs text-white/80 truncate">Re: {activeConversation.productName}</p>
                  )}
                </div>
                <div className="flex items-center gap-1">
                  <button className="p-1.5 hover:bg-white/20 rounded-full"><Phone size={16} /></button>
                </div>
              </>
            ) : (
              <>
                <MessageCircle size={22} />
                <div className="flex-1">
                  <p className="font-semibold">Messages</p>
                  <p className="text-xs text-white/80">{conversations.length} conversation{conversations.length !== 1 ? 's' : ''}</p>
                </div>
              </>
            )}
          </div>

          {/* Trust Banner */}
          <div className="bg-green-50 px-4 py-2 text-xs text-green-800 flex items-center gap-2 border-b border-green-100 flex-shrink-0">
            <Shield size={12} className="text-green-600" />
            <span>All chats are monitored to ensure safety. Never share payment info directly.</span>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto">
            {!activeConv ? (
              /* Conversation List */
              <div className="divide-y divide-gray-100">
                {conversations.length === 0 ? (
                  <div className="p-8 text-center text-gray-500">
                    <MessageCircle className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                    <p className="font-medium">No conversations yet</p>
                    <p className="text-sm mt-1">Start a chat from any product page</p>
                  </div>
                ) : (
                  conversations.map(conv => {
                    const unread = role === 'buyer' ? conv.unreadBuyer : conv.unreadSeller;
                    const otherName = role === 'buyer' ? conv.sellerName : conv.buyerName;
                    return (
                      <button
                        key={conv.id}
                        onClick={() => setActiveConv(conv.id)}
                        className="w-full p-4 flex gap-3 hover:bg-gray-50 transition-colors text-left"
                      >
                        <div className="w-10 h-10 bg-gradient-to-br from-red-400 to-red-500 rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
                          {otherName.charAt(0)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <span className="font-medium text-gray-900 text-sm truncate">{otherName}</span>
                            <span className="text-xs text-gray-400 flex-shrink-0">{formatTime(conv.lastMessageTime)}</span>
                          </div>
                          {conv.productName && (
                            <p className="text-xs text-blue-600 truncate">Re: {conv.productName}</p>
                          )}
                          <p className={`text-sm truncate mt-0.5 ${unread > 0 ? 'text-gray-900 font-medium' : 'text-gray-500'}`}>
                            {conv.lastMessage}
                          </p>
                        </div>
                        {unread > 0 && (
                          <span className="w-5 h-5 bg-red-600 text-white text-xs rounded-full flex items-center justify-center font-medium flex-shrink-0 self-center">
                            {unread}
                          </span>
                        )}
                      </button>
                    );
                  })
                )}
              </div>
            ) : (
              /* Messages */
              <div className="p-4 space-y-3">
                {messages.map(msg => {
                  const isMe = msg.senderId === user.id;
                  const isSystem = msg.senderType === 'system';
                  if (isSystem) {
                    return (
                      <div key={msg.id} className="text-center">
                        <div className="inline-block bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 text-xs text-amber-800">
                          {msg.message}
                        </div>
                      </div>
                    );
                  }
                  return (
                    <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-[80%] rounded-2xl px-4 py-2.5 ${
                        isMe
                          ? 'bg-red-600 text-white rounded-br-md'
                          : 'bg-gray-100 text-gray-900 rounded-bl-md'
                      }`}>
                        {!isMe && <p className="text-xs font-medium mb-1 opacity-70">{msg.senderName}</p>}
                        <p className="text-sm leading-relaxed">{msg.message}</p>
                        {msg.attachments && msg.attachments.length > 0 && (
                          <div className="mt-2 grid grid-cols-2 gap-1">
                            {msg.attachments.map((url, i) => (
                              <img key={i} src={url} alt="" className="rounded-lg w-full h-20 object-cover" />
                            ))}
                          </div>
                        )}
                        <p className={`text-xs mt-1 ${isMe ? 'text-white/60' : 'text-gray-400'}`}>
                          {formatTime(msg.timestamp)}
                        </p>
                      </div>
                    </div>
                  );
                })}
                <div ref={messagesEndRef} />
              </div>
            )}
          </div>

          {/* Input */}
          {activeConv && (
            <div className="p-3 border-t border-gray-200 flex items-center gap-2 flex-shrink-0 bg-white">
              <button className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full">
                <Image size={18} />
              </button>
              <input
                ref={inputRef}
                type="text"
                value={newMessage}
                onChange={e => setNewMessage(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleSend()}
                placeholder="Type a message..."
                className="flex-1 px-4 py-2 bg-gray-100 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-red-500"
              />
              <button
                onClick={handleSend}
                disabled={!newMessage.trim()}
                className="p-2 bg-red-600 text-white rounded-full hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <Send size={16} />
              </button>
            </div>
          )}
        </div>
      )}
    </>
  );
}
