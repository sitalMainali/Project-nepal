import { useState, useRef, useCallback } from 'react';
import { Camera, X, Upload, Image, AlertCircle } from 'lucide-react';
import { ImageService } from '@/services/api';

interface ImageUploaderProps {
  images: string[];
  onChange: (images: string[]) => void;
  maxImages?: number;
  label?: string;
  required?: boolean;
  minImages?: number;
  className?: string;
}

export function ImageUploader({
  images,
  onChange,
  maxImages = 6,
  label = 'Upload Photos',
  required = false,
  minImages = 0,
  className = '',
}: ImageUploaderProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleFiles = useCallback(async (files: File[]) => {
    setError(null);
    const remaining = maxImages - images.length;
    if (files.length > remaining) {
      setError(`You can only add ${remaining} more image${remaining !== 1 ? 's' : ''}.`);
      return;
    }

    setUploading(true);
    const newImages: string[] = [];

    for (const file of files) {
      const validation = ImageService.validate(file);
      if (!validation.valid) {
        setError(validation.error || 'Invalid file.');
        continue;
      }
      try {
        const result = await ImageService.upload(file);
        newImages.push(result.url);
      } catch {
        setError('Failed to upload image. Please try again.');
      }
    }

    if (newImages.length > 0) {
      onChange([...images, ...newImages]);
    }
    setUploading(false);
  }, [images, maxImages, onChange]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = Array.from(e.dataTransfer.files).filter(f => f.type.startsWith('image/'));
    if (files.length > 0) handleFiles(files);
  }, [handleFiles]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length > 0) handleFiles(files);
    if (fileRef.current) fileRef.current.value = '';
  };

  const removeImage = (index: number) => {
    onChange(images.filter((_, i) => i !== index));
  };

  const moveImage = (from: number, to: number) => {
    if (to < 0 || to >= images.length) return;
    const newImages = [...images];
    const [removed] = newImages.splice(from, 1);
    newImages.splice(to, 0, removed);
    onChange(newImages);
  };

  return (
    <div className={className}>
      <label className="block text-sm font-medium text-gray-700 mb-2">
        {label} {required && <span className="text-red-500">*</span>}
        <span className="text-gray-400 font-normal ml-1">({images.length}/{maxImages})</span>
      </label>

      {/* Image Grid */}
      {images.length > 0 && (
        <div className="grid grid-cols-3 sm:grid-cols-4 gap-3 mb-3">
          {images.map((img, i) => (
            <div key={i} className="relative aspect-square rounded-xl overflow-hidden border-2 border-gray-200 group">
              <img src={img} alt="" className="w-full h-full object-cover" />
              {i === 0 && (
                <span className="absolute top-1 left-1 bg-red-600 text-white text-[10px] px-1.5 py-0.5 rounded font-medium">
                  Cover
                </span>
              )}
              {/* Overlay */}
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                {i > 0 && (
                  <button onClick={() => moveImage(i, i - 1)} className="p-1.5 bg-white rounded-full text-gray-700 hover:bg-gray-100 text-xs">←</button>
                )}
                <button onClick={() => removeImage(i)} className="p-1.5 bg-red-600 rounded-full text-white hover:bg-red-700">
                  <X size={14} />
                </button>
                {i < images.length - 1 && (
                  <button onClick={() => moveImage(i, i + 1)} className="p-1.5 bg-white rounded-full text-gray-700 hover:bg-gray-100 text-xs">→</button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Upload Area */}
      {images.length < maxImages && (
        <div
          onDragOver={e => { e.preventDefault(); setIsDragging(true); }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          onClick={() => fileRef.current?.click()}
          className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all ${
            isDragging
              ? 'border-red-400 bg-red-50'
              : 'border-gray-300 bg-gray-50 hover:border-red-400 hover:bg-red-50/50'
          } ${uploading ? 'opacity-70 pointer-events-none' : ''}`}
        >
          {uploading ? (
            <div className="flex flex-col items-center gap-2">
              <div className="w-8 h-8 border-3 border-red-600 border-t-transparent rounded-full animate-spin" />
              <p className="text-sm text-gray-600">Uploading...</p>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-2">
              {isDragging ? <Upload size={32} className="text-red-500" /> : <Camera size={32} className="text-gray-400" />}
              <div>
                <p className="text-sm font-medium text-gray-700">
                  {isDragging ? 'Drop images here' : 'Click to upload or drag & drop'}
                </p>
                <p className="text-xs text-gray-500 mt-1">JPG, PNG, WebP up to 5MB each</p>
              </div>
            </div>
          )}
        </div>
      )}

      <input ref={fileRef} type="file" accept="image/*" multiple onChange={handleInputChange} className="hidden" />

      {/* Error */}
      {error && (
        <div className="mt-2 flex items-center gap-2 text-sm text-red-600">
          <AlertCircle size={14} /> {error}
        </div>
      )}

      {/* Minimum images warning */}
      {minImages > 0 && images.length < minImages && (
        <div className="mt-2 flex items-center gap-2 text-sm text-amber-600">
          <Image size={14} /> At least {minImages} photo{minImages > 1 ? 's' : ''} required. Real photos only — stock images are rejected.
        </div>
      )}
    </div>
  );
}
