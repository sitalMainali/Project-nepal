import { Star } from 'lucide-react';

interface StarRatingProps {
  rating: number;
  maxStars?: number;
  size?: number;
  showCount?: boolean;
  reviewCount?: number;
}

export function StarRating({ rating, maxStars = 5, size = 16, showCount = false, reviewCount }: StarRatingProps) {
  const fullStars = Math.floor(rating);
  const hasHalfStar = rating % 1 >= 0.5;
  
  return (
    <div className="flex items-center gap-1">
      {Array.from({ length: maxStars }).map((_, index) => {
        if (index < fullStars) {
          return <Star key={index} size={size} fill="#f59e0b" className="text-amber-500" />;
        }
        if (index === fullStars && hasHalfStar) {
          return <Star key={index} size={size} fill="#f59e0b" className="text-amber-500" />;
        }
        return <Star key={index} size={size} className="text-gray-300" />;
      })}
      {showCount && reviewCount && (
        <span className="text-sm text-gray-500 ml-1">({reviewCount})</span>
      )}
    </div>
  );
}
