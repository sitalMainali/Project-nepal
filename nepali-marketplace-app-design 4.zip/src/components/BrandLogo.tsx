import { cn } from "@/utils/cn";

type BrandLogoProps = {
  className?: string;
  markClassName?: string;
  wordmarkClassName?: string;
  showWordmark?: boolean;
};

export function BrandLogo({
  className,
  markClassName,
  wordmarkClassName,
  showWordmark = true,
}: BrandLogoProps) {
  return (
    <div className={cn("inline-flex items-center gap-2", className)} aria-label="BazaarCo">
      {/* Mark: Nepal-inspired shield + bazaar canopy */}
      <svg
        width="40"
        height="40"
        viewBox="0 0 40 40"
        className={cn("shrink-0", markClassName)}
        role="img"
        aria-label="BazaarCo logo"
      >
        <defs>
          <linearGradient id="bc_grad" x1="6" y1="6" x2="34" y2="34" gradientUnits="userSpaceOnUse">
            <stop stopColor="#DC143C" />
            <stop offset="1" stopColor="#003893" />
          </linearGradient>
          <clipPath id="bc_clip">
            <path d="M20 3.5c6.7 0 12.5 3.7 15 9.3v8.6c0 8.3-6.1 14.8-15 15.6C11.1 36.2 5 29.7 5 21.4v-8.6C7.5 7.2 13.3 3.5 20 3.5Z" />
          </clipPath>
        </defs>

        {/* Shield */}
        <path
          d="M20 3.5c6.7 0 12.5 3.7 15 9.3v8.6c0 8.3-6.1 14.8-15 15.6C11.1 36.2 5 29.7 5 21.4v-8.6C7.5 7.2 13.3 3.5 20 3.5Z"
          fill="url(#bc_grad)"
        />

        {/* Inner */}
        <g clipPath="url(#bc_clip)">
          {/* Canopy stripes */}
          <path d="M0 14h40v4H0z" fill="#ffffff" opacity="0.95" />
          <path d="M0 18h40v4H0z" fill="#ffffff" opacity="0.7" />

          {/* Canopy scallop */}
          <path
            d="M7 14c1.6 2.6 3.6 2.6 5.2 0c1.6 2.6 3.6 2.6 5.2 0c1.6 2.6 3.6 2.6 5.2 0c1.6 2.6 3.6 2.6 5.2 0c1.6 2.6 3.6 2.6 5.2 0"
            fill="none"
            stroke="#ffffff"
            strokeWidth="2"
            strokeLinecap="round"
            opacity="0.95"
          />

          {/* Store base */}
          <path
            d="M12.5 23.5c0-1.1.9-2 2-2h11c1.1 0 2 .9 2 2v7c0 1.1-.9 2-2 2h-11c-1.1 0-2-.9-2-2v-7Z"
            fill="#ffffff"
            opacity="0.95"
          />
          {/* Door */}
          <path d="M19 25.5h2v7h-2z" fill="#003893" opacity="0.9" />

          {/* Check mark = trust */}
          <path
            d="M16 28.2l2 2.1 5.7-6"
            fill="none"
            stroke="#006600"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </g>
      </svg>

      {showWordmark && (
        <span
          className={cn(
            "text-xl font-extrabold bg-gradient-to-r from-red-600 to-blue-600 bg-clip-text text-transparent tracking-tight",
            wordmarkClassName
          )}
        >
          BazaarCo
        </span>
      )}
    </div>
  );
}
