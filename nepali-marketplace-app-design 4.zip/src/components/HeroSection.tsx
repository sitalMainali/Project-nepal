import { Search, ShoppingBag, Truck, Shield } from 'lucide-react';
import { Button } from '@/components/ui/Button';

interface HeroSectionProps {
  onSearch: (query: string) => void;
  onModeChange: (mode: 'new' | 'secondHand') => void;
  currentMode: 'new' | 'secondHand';
}

export function HeroSection({ onSearch, onModeChange, currentMode }: HeroSectionProps) {
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const input = (e.target as HTMLFormElement).querySelector('input');
    if (input) onSearch(input.value);
  };

  return (
    <div className="relative bg-gradient-to-br from-red-700 via-red-600 to-blue-800 text-white overflow-hidden">
      {/* Nepalese Flag Elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-32 h-32 rounded-full bg-white" />
        <div className="absolute top-20 left-20 w-24 h-24 rounded-full bg-blue-500" />
        <div className="absolute bottom-10 right-10 w-24 h-24 rounded-full bg-white" />
      </div>

      <div className="max-w-7xl mx-auto px-4 py-12 relative z-10">
        {/* Mode Toggle */}
        <div className="flex justify-center mb-8">
          <div className="bg-white/10 backdrop-blur-sm rounded-full p-1 inline-flex">
            <button
              onClick={() => onModeChange('new')}
              className={`px-6 py-2 rounded-full font-medium transition-all ${
                currentMode === 'new' 
                  ? 'bg-white text-red-700 shadow-lg' 
                  : 'text-white hover:bg-white/20'
              }`}
            >
              🛍️ New Market
            </button>
            <button
              onClick={() => onModeChange('secondHand')}
              className={`px-6 py-2 rounded-full font-medium transition-all ${
                currentMode === 'secondHand' 
                  ? 'bg-white text-red-700 shadow-lg' 
                  : 'text-white hover:bg-white/20'
              }`}
            >
              🔄 Second Hand
            </button>
          </div>
        </div>

        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2 mb-4">
            <Shield size={16} className="text-white" />
            <span className="text-sm font-semibold">BazaarCo promise:</span>
            <span className="text-sm text-white/90">Shop without fear</span>
          </div>

          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            {currentMode === 'new' ? 'Shop clear. Shop safe.' : 'Second-hand, minus the stress.'}
          </h1>
          <p className="text-lg text-white/80 max-w-2xl mx-auto">
            {currentMode === 'new'
              ? 'Verified sellers, clear specs, and protected payments — built for Nepal.'
              : 'Condition labels, local pickup guidance, and dispute support — so you can buy with confidence.'}
          </p>
        </div>

        {/* Search Bar */}
        <form onSubmit={handleSearch} className="max-w-2xl mx-auto mb-8">
          <div className="flex gap-2">
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                placeholder="Search for products..."
                className="w-full pl-12 pr-4 py-3 rounded-xl text-gray-800 focus:outline-none focus:ring-4 focus:ring-white/30"
              />
            </div>
            <Button type="submit" size="lg" className="px-8">
              Search
            </Button>
          </div>
        </form>

        {/* Features */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
          <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-lg p-3">
            <ShoppingBag size={20} />
            <span className="text-sm font-medium">Wide Selection</span>
          </div>
          <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-lg p-3">
            <Truck size={20} />
            <span className="text-sm font-medium">Fast Delivery</span>
          </div>
          <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-lg p-3">
            <Shield size={20} />
            <span className="text-sm font-medium">Secure Payment</span>
          </div>
          <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-lg p-3">
            <span className="text-xl">🇳🇵</span>
            <span className="text-sm font-medium">Made in Nepal</span>
          </div>
        </div>
      </div>
    </div>
  );
}
