import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, Heart, ShoppingCart, User, Menu, X, Shield, LayoutDashboard, LogOut, Package, ChevronDown, Settings, MessageCircle } from 'lucide-react';
import { NotificationCenter } from '@/components/NotificationCenter';
import { BrandLogo } from '@/components/BrandLogo';
import { useApp } from '@/context/AppContext';

export function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const navigate = useNavigate();
  const { state, getCartCount, logout } = useApp();

  const cartCount = getCartCount();
  const wishlistCount = state.wishlist.length;
  const user = state.user;

  const handleLogout = () => {
    logout();
    setIsUserMenuOpen(false);
    navigate('/');
  };

  return (
    <nav className="bg-white shadow-md sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2" aria-label="BazaarCo home">
            <BrandLogo />
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-6">
            <Link to="/" className="text-gray-700 hover:text-red-600 font-medium transition-colors">Home</Link>
            <Link to="/?mode=new" className="text-gray-700 hover:text-red-600 font-medium transition-colors">New Market</Link>
            <Link to="/?mode=secondHand" className="text-gray-700 hover:text-red-600 font-medium transition-colors">Verified Resale</Link>
            <button
              type="button"
              className="inline-flex items-center gap-2 text-gray-700 hover:text-red-600 font-medium transition-colors"
              onClick={() => {
                window.dispatchEvent(new CustomEvent('bazaarco:open-trust-playbook'));
              }}
            >
              <Shield size={16} /> Trust & Support
            </button>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2">
            <button className="p-2 hover:bg-gray-100 rounded-full transition-colors hidden md:block">
              <Search size={20} className="text-gray-600" />
            </button>

            {/* Chat */}
            {user && (
              <Link to="/messages" className="p-2 hover:bg-gray-100 rounded-full transition-colors hidden md:block relative">
                <MessageCircle size={20} className="text-gray-600" />
              </Link>
            )}

            {/* Notifications */}
            {user && (
              <div className="hidden md:block">
                <NotificationCenter />
              </div>
            )}
            
            {/* Wishlist */}
            <Link to="/" className="p-2 hover:bg-gray-100 rounded-full transition-colors hidden md:block relative">
              <Heart size={20} className="text-gray-600" />
              {wishlistCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-600 text-white text-xs rounded-full flex items-center justify-center">
                  {wishlistCount}
                </span>
              )}
            </Link>
            
            {/* Cart */}
            <Link to="/cart" className="p-2 hover:bg-gray-100 rounded-full transition-colors relative">
              <ShoppingCart size={20} className="text-gray-600" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-600 text-white text-xs rounded-full flex items-center justify-center">
                  {cartCount > 99 ? '99+' : cartCount}
                </span>
              )}
            </Link>

            {/* User Menu */}
            {user ? (
              <div className="relative hidden md:block">
                <button
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center gap-2 p-2 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <div className="w-8 h-8 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center text-white font-medium text-sm">
                    {user.name.charAt(0).toUpperCase()}
                  </div>
                  <ChevronDown size={16} className="text-gray-600" />
                </button>
                
                {isUserMenuOpen && (
                  <>
                    <div 
                      className="fixed inset-0 z-40" 
                      onClick={() => setIsUserMenuOpen(false)}
                    />
                    <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-lg border border-gray-100 py-2 z-50">
                      <div className="px-4 py-2 border-b border-gray-100">
                        <p className="font-medium text-gray-900">{user.name}</p>
                        <p className="text-sm text-gray-500">{user.email}</p>
                      </div>
                      <Link
                        to="/orders"
                        onClick={() => setIsUserMenuOpen(false)}
                        className="flex items-center gap-2 px-4 py-2 text-gray-700 hover:bg-gray-50"
                      >
                        <Package size={18} />
                        My Orders
                      </Link>
                      {user.type === 'seller' && (
                        <Link
                          to="/seller/dashboard"
                          onClick={() => setIsUserMenuOpen(false)}
                          className="flex items-center gap-2 px-4 py-2 text-gray-700 hover:bg-gray-50"
                        >
                          <LayoutDashboard size={18} />
                          Seller Dashboard
                        </Link>
                      )}
                      {user.type === 'admin' && (
                        <Link
                          to="/admin"
                          onClick={() => setIsUserMenuOpen(false)}
                          className="flex items-center gap-2 px-4 py-2 text-gray-700 hover:bg-gray-50"
                        >
                          <Shield size={18} />
                          Admin Panel
                        </Link>
                      )}
                      <Link
                        to="/settings"
                        onClick={() => setIsUserMenuOpen(false)}
                        className="flex items-center gap-2 px-4 py-2 text-gray-700 hover:bg-gray-50"
                      >
                        <Settings size={18} />
                        Settings
                      </Link>
                      <button
                        onClick={handleLogout}
                        className="flex items-center gap-2 px-4 py-2 text-red-600 hover:bg-red-50 w-full"
                      >
                        <LogOut size={18} />
                        Sign Out
                      </button>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <Link to="/login" className="p-2 hover:bg-gray-100 rounded-full transition-colors hidden md:block">
                <User size={20} className="text-gray-600" />
              </Link>
            )}

            {/* Quick Links Dropdown for demo - show seller/admin links */}
            {!user && (
              <div className="hidden md:flex items-center gap-1 ml-2 pl-2 border-l border-gray-200">
                <Link
                  to="/seller/dashboard"
                  className="text-xs text-gray-500 hover:text-red-600 px-2 py-1 rounded hover:bg-gray-100"
                >
                  Seller
                </Link>
                <Link
                  to="/admin"
                  className="text-xs text-gray-500 hover:text-red-600 px-2 py-1 rounded hover:bg-gray-100"
                >
                  Admin
                </Link>
              </div>
            )}
            
            {/* Mobile Menu Button */}
            <button 
              className="md:hidden p-2 hover:bg-gray-100 rounded-full transition-colors"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden pb-4">
            <div className="flex flex-col gap-2">
              <Link to="/" className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg font-medium" onClick={() => setIsMenuOpen(false)}>Home</Link>
              <Link to="/?mode=new" className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg font-medium" onClick={() => setIsMenuOpen(false)}>New Market</Link>
              <Link to="/?mode=secondHand" className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg font-medium" onClick={() => setIsMenuOpen(false)}>Verified Resale</Link>
              <button
                type="button"
                className="px-4 py-2 text-left text-gray-700 hover:bg-gray-100 rounded-lg font-medium inline-flex items-center gap-2"
                onClick={() => {
                  window.dispatchEvent(new CustomEvent('bazaarco:open-trust-playbook'));
                  setIsMenuOpen(false);
                }}
              >
                <Shield size={16} /> Trust & Support
              </button>
              <div className="border-t border-gray-100 my-2" />
              
              {user ? (
                <>
                  <div className="px-4 py-2 flex items-center gap-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center text-white font-medium">
                      {user.name.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{user.name}</p>
                      <p className="text-sm text-gray-500">{user.email}</p>
                    </div>
                  </div>
                  <Link to="/orders" className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg font-medium flex items-center gap-2" onClick={() => setIsMenuOpen(false)}>
                    <Package size={16} /> My Orders
                  </Link>
                  {user.type === 'seller' && (
                    <Link to="/seller/dashboard" className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg font-medium flex items-center gap-2" onClick={() => setIsMenuOpen(false)}>
                      <LayoutDashboard size={16} /> Seller Dashboard
                    </Link>
                  )}
                  {user.type === 'admin' && (
                    <Link to="/admin" className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg font-medium flex items-center gap-2" onClick={() => setIsMenuOpen(false)}>
                      <Shield size={16} /> Admin Panel
                    </Link>
                  )}
                  <Link to="/settings" className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg font-medium flex items-center gap-2" onClick={() => setIsMenuOpen(false)}>
                    <Settings size={16} /> Settings
                  </Link>
                  <button
                    onClick={() => {
                      handleLogout();
                      setIsMenuOpen(false);
                    }}
                    className="px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg font-medium flex items-center gap-2 w-full text-left"
                  >
                    <LogOut size={16} /> Sign Out
                  </button>
                </>
              ) : (
                <>
                  <Link to="/login" className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg font-medium flex items-center gap-2" onClick={() => setIsMenuOpen(false)}>
                    <User size={16} /> Login / Register
                  </Link>
                  <Link to="/seller/dashboard" className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg font-medium flex items-center gap-2" onClick={() => setIsMenuOpen(false)}>
                    <LayoutDashboard size={16} /> Seller Dashboard
                  </Link>
                  <Link to="/admin" className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg font-medium flex items-center gap-2" onClick={() => setIsMenuOpen(false)}>
                    <Shield size={16} /> Admin Panel
                  </Link>
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
