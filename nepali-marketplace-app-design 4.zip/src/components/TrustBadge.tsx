import { Shield, Award, CheckCircle } from 'lucide-react';

export function TrustBadge() {
  return (
    <div className="bg-gradient-to-r from-red-50 to-blue-50 border-y border-red-100 py-4">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
          <div className="flex flex-col items-center gap-2">
            <div className="p-3 bg-red-600 rounded-full text-white trust-glow">
              <Shield size={24} />
            </div>
            <div>
              <p className="font-semibold text-gray-800">Protected Payments</p>
              <p className="text-sm text-gray-500">Release only after you confirm</p>
            </div>
          </div>
          <div className="flex flex-col items-center gap-2">
            <div className="p-3 bg-blue-600 rounded-full text-white trust-glow">
              <Award size={24} />
            </div>
            <div>
              <p className="font-semibold text-gray-800">Verified Sellers</p>
              <p className="text-sm text-gray-500">Identity verified</p>
            </div>
          </div>
          <div className="flex flex-col items-center gap-2">
            <div className="p-3 bg-green-600 rounded-full text-white trust-glow">
              <CheckCircle size={24} />
            </div>
            <div>
              <p className="font-semibold text-gray-800">Dispute Support</p>
              <p className="text-sm text-gray-500">Fair help when something goes wrong</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
