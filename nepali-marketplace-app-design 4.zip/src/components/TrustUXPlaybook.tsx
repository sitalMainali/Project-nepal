import { Shield, CheckCircle2, Truck, BadgeCheck, AlertTriangle, Headphones, Timer, Scale, Camera, Ruler, PackageCheck, HandHeart } from "lucide-react";

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="bg-white rounded-2xl shadow-md border border-gray-100 p-6">
      <h3 className="text-xl font-bold text-gray-900 mb-4">{title}</h3>
      <div className="space-y-4 text-gray-700 leading-relaxed">{children}</div>
    </section>
  );
}

function CopyBlock({ label, items }: { label: string; items: string[] }) {
  return (
    <div className="rounded-xl border border-gray-200 bg-gray-50 p-4">
      <div className="text-xs font-semibold uppercase tracking-wide text-gray-500 mb-2">{label}</div>
      <ul className="space-y-2">
        {items.map((t) => (
          <li key={t} className="flex gap-2">
            <span className="mt-1 text-green-600">
              <CheckCircle2 size={16} />
            </span>
            <span>{t}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function TrustUXPlaybook({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="max-w-5xl mx-auto">
        <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
          <div className="p-5 md:p-6 border-b border-gray-100 flex items-start justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-2 text-sm font-semibold text-red-700 bg-red-50 border border-red-100 rounded-full px-3 py-1">
                <Shield size={16} /> BazaarCo Trust UX Playbook
              </div>
              <h2 className="text-2xl md:text-3xl font-extrabold text-gray-900 mt-2">“Shop without fear” — UX + microcopy system</h2>
              <p className="text-gray-600 mt-2 max-w-3xl">
                Every screen should reduce fear by answering: <span className="font-semibold">Is this real?</span> <span className="font-semibold">Is the seller legit?</span> <span className="font-semibold">Will it arrive?</span> <span className="font-semibold">What if something goes wrong?</span>
              </p>
            </div>
            <button
              onClick={onClose}
              className="shrink-0 rounded-xl px-4 py-2 font-semibold border border-gray-200 hover:bg-gray-50"
            >
              Close
            </button>
          </div>

          <div className="p-5 md:p-6 space-y-6 bg-gray-50">
            {/* 2) HOMEPAGE UX */}
            <Section title="2) HOMEPAGE UX">
              <div className="grid md:grid-cols-2 gap-4">
                <CopyBlock
                  label="Above-the-fold messaging (exact copy)"
                  items={[
                    "Headline: Shop without fear.",
                    "Subhead: Verified sellers, real photos, clear sizes/quantities, and protected payments — built for Nepal.",
                    "Primary CTA: Browse safe listings",
                    "Secondary CTA: How protection works",
                    "Search placeholder: “Search by item, model, or area (e.g., iPhone 12, Bhaktapur)”",
                  ]}
                />
                <CopyBlock
                  label="Trust signals (top row, always visible)"
                  items={[
                    "Protected Payment: Money released only after you confirm.",
                    "Verified Sellers: ID + phone verified badges.",
                    "No Stock Photos: Real item photos required.",
                    "Fast Help: Report an issue in 2 taps.",
                  ]}
                />
              </div>

              <div className="rounded-xl border border-gray-200 bg-white p-4">
                <div className="text-sm font-semibold text-gray-900 mb-2">Section-by-section breakdown</div>
                <ol className="list-decimal pl-5 space-y-2">
                  <li><span className="font-semibold">Hero</span>: Promise + search + category chips. Keep 1 line of reassurance under CTAs.</li>
                  <li><span className="font-semibold">Trust strip</span>: 3–4 icon cards (Protected Payment, Verified Sellers, Real Photos, Dispute Support).</li>
                  <li><span className="font-semibold">Separate modes</span>: “New Market” vs “Verified Resale” tabs. Explain in one sentence each.</li>
                  <li><span className="font-semibold">Proof</span>: “Today’s verified listings” + count of verified sellers + average delivery days.</li>
                  <li><span className="font-semibold">How it works</span>: 3 steps with timelines (Order → Inspect → Confirm/Report).</li>
                  <li><span className="font-semibold">Safety education</span>: small banner: “Buying tips in Nepal” (COD checks, pickup points, scam patterns).</li>
                </ol>
              </div>

              <CopyBlock
                label="Homepage reassurance microcopy"
                items={[
                  "“You’ll see the seller’s verification, real photos, and delivery ETA before you pay.”",
                  "“If the item is wrong or damaged, start a dispute from the order screen.”",
                  "“No pressure: you can cancel before dispatch.”",
                ]}
              />
            </Section>

            {/* 3) PRODUCT PAGE DESIGN */}
            <Section title="3) PRODUCT PAGE DESIGN">
              <div className="grid md:grid-cols-2 gap-4">
                <CopyBlock
                  label="Mandatory real product images (no stock)"
                  items={[
                    "Require 4+ photos: front, back, label/serial, defects (if any).",
                    "Banner copy: “Real photos only — stock images are rejected.”",
                    "If AI/stock suspected: “This listing is under photo review.” (block purchase until verified)",
                  ]}
                />
                <CopyBlock
                  label="Trust information ABOVE Buy Now"
                  items={[
                    "Delivery ETA with confidence: “Arrives in 2–4 days (KTM Valley)” + “7–10 days (Outside Valley)”.",
                    "Return window: “Return within 7 days if wrong/damaged.”",
                    "Dispute: “Report an issue in 2 taps. Human support within 24h.”",
                    "Payment protection: “Payment held until you confirm.”",
                  ]}
                />
              </div>

              <div className="rounded-xl border border-gray-200 bg-white p-4 space-y-3">
                <div className="text-sm font-semibold text-gray-900">Visual size & quantity (reduce mismatch fear)</div>
                <ul className="space-y-2">
                  <li className="flex gap-2"><Ruler className="text-blue-600" size={18} /> Use size chips with measurements: “M (Chest 38–40)” not just “M”.</li>
                  <li className="flex gap-2"><PackageCheck className="text-green-700" size={18} /> Quantity shown as tiles: “1 pc”, “2 pcs”, “Pack of 6”.</li>
                  <li className="flex gap-2"><Camera className="text-gray-700" size={18} /> “Photo proof” slot for size label + included box items.</li>
                </ul>
              </div>

              <div className="rounded-xl border border-gray-200 bg-white p-4 space-y-2">
                <div className="text-sm font-semibold text-gray-900">Seller verification indicators</div>
                <ul className="space-y-2">
                  <li className="flex gap-2"><BadgeCheck className="text-green-700" size={18} /> “Verified Seller” badge with what’s verified (ID, phone, bank).</li>
                  <li className="flex gap-2"><Timer className="text-purple-700" size={18} /> “On-time dispatch rate” + “Avg response time”.</li>
                  <li className="flex gap-2"><Scale className="text-gray-800" size={18} /> “Dispute fairness” metric: disputes resolved / refunds approved.</li>
                </ul>
              </div>

              <CopyBlock
                label="Trust badges + microcopy"
                items={[
                  "Badge: “Real Photos Verified” → “Photos checked by BazaarCo moderation.”",
                  "Badge: “Protected Payment” → “Seller is paid only after you confirm.”",
                  "Badge: “Easy Returns” → “Wrong/damaged? Start return from Order in 1 tap.”",
                  "Badge: “Verified Seller” → “Identity and contact verified.”",
                ]}
              />
            </Section>

            {/* 4) CHECKOUT & POST-PURCHASE FLOW */}
            <Section title="4) CHECKOUT & POST-PURCHASE FLOW">
              <CopyBlock
                label="Fear-reduction steps before payment"
                items={[
                  "Step 1: Confirm address + pin on map (reduce delivery mistakes).",
                  "Step 2: Show item checklist: size, color, quantity, inclusions (buyer confirms).",
                  "Step 3: Show delivery ETA + handling time clearly.",
                  "Step 4: Show protection summary: “Held payment + dispute window + human support.”",
                ]}
              />

              <div className="rounded-xl border border-gray-200 bg-white p-4">
                <div className="text-sm font-semibold text-gray-900 mb-2">Order confirmation reassurance (exact copy)</div>
                <ul className="space-y-2">
                  <li>“Order placed. Your payment is protected.”</li>
                  <li>“Next: Seller must dispatch by <span className='font-semibold'>Tomorrow 5 PM</span> or you can cancel.”</li>
                  <li>“When it arrives: Inspect first. Confirm to release payment.”</li>
                </ul>
              </div>

              <CopyBlock
                label="Tracking UX"
                items={[
                  "Timeline: Ordered → Packed → Picked up → In transit → Out for delivery → Delivered → Confirm/Report.",
                  "Each step shows date + ‘what this means’.",
                  "One persistent CTA: “Report an issue” (always visible).",
                ]}
              />

              <CopyBlock
                label="Dispute/report issue flow (1–2 taps)"
                items={[
                  "Order screen → “Report an issue” → choose reason (Wrong item / Damaged / Missing / Not as described / Delivery issue).",
                  "Auto-request 3 photos + short note.",
                  "Instant confirmation: “We’ve paused seller payout while we review.”",
                ]}
              />
            </Section>

            {/* 5) SELLER PROFILE & DASHBOARD UX */}
            <Section title="5) SELLER PROFILE & DASHBOARD UX">
              <CopyBlock
                label="Seller credibility indicators"
                items={[
                  "Verification stack: Phone ✓, ID ✓, Bank ✓, Address ✓.",
                  "Performance: On-time dispatch %, Chat response time, Return rate, Dispute win rate.",
                  "Transparency: “Last active”, “Total verified sales”.",
                ]}
              />

              <div className="rounded-xl border border-gray-200 bg-white p-4 space-y-2">
                <div className="text-sm font-semibold text-gray-900">Trust score (simple & explainable)</div>
                <p className="text-gray-700">
                  Show a single <span className="font-semibold">Trust Score (0–100)</span> with 3 drivers: Shipping reliability, Listing accuracy, Support behavior.
                </p>
                <p className="text-gray-600 text-sm">Copy: “Trust Score is based on real order outcomes — not paid ads.”</p>
              </div>

              <CopyBlock
                label="Seller education prompts"
                items={[
                  "“Add label photo to reduce returns.”",
                  "“Add a short defect note — it increases buyer confidence.”",
                  "“Ship within 24h to improve Trust Score.”",
                ]}
              />

              <CopyBlock
                label="Warning & penalty UX (clear expectations)"
                items={[
                  "Soft warning: “Your listing is missing real photos. Sales are paused until fixed.”",
                  "Penalty ladder: Warning → Temporary visibility reduction → Selling pause → Account review.",
                  "Explain ‘why’: “This protects buyers and serious sellers.”",
                ]}
              />
            </Section>

            {/* 6) SECOND-HAND / RESALE UX */}
            <Section title="6) SECOND-HAND / RESALE UX">
              <CopyBlock
                label="Separate “Verified Resale” section"
                items={[
                  "Navigation label: Verified Resale (not just ‘Second Hand’).",
                  "Explain: “Checked listings + escrow-style payment.”",
                  "Default filters: Location, Condition (A/B/C), Verified sellers only.",
                ]}
              />

              <CopyBlock
                label="Condition grading system (A/B/C)"
                items={[
                  "A: Like new (no visible defects) — must include close-up photos.",
                  "B: Good (minor wear) — disclose scratches/marks.",
                  "C: Used (visible wear) — disclose issues; priced accordingly.",
                ]}
              />

              <div className="rounded-xl border border-gray-200 bg-white p-4 space-y-2">
                <div className="text-sm font-semibold text-gray-900">Escrow-style payment flow</div>
                <ol className="list-decimal pl-5 space-y-2">
                  <li>Buyer pays → BazaarCo holds payment.</li>
                  <li>Seller ships / meets for verified handover.</li>
                  <li>Buyer confirms within 24–48h (or dispute) → payout released.</li>
                </ol>
                <p className="text-sm text-gray-600">Microcopy: “Seller payout is paused until you confirm. That’s the point.”</p>
              </div>

              <CopyBlock
                label="Buyer confirmation before seller payout"
                items={[
                  "Button: “Confirm item matches photos”",
                  "Secondary: “Report mismatch”",
                  "Helper: “No rush — confirm only after you check.”",
                ]}
              />
            </Section>

            {/* 7) DISPUTE & SUPPORT UX */}
            <Section title="7) DISPUTE & SUPPORT UX">
              <CopyBlock
                label="Simple dispute initiation"
                items={[
                  "Always accessible from Order: “Report an issue”.",
                  "Use plain language reasons + examples.",
                  "Show what to upload (photos) before user starts.",
                ]}
              />

              <CopyBlock
                label="Timeline-based resolution"
                items={[
                  "Day 0: Issue reported → payout paused.",
                  "Day 1: We review evidence + contact seller.",
                  "Day 2–3: Resolution proposal (refund/replace/partial).",
                  "Day 3–7: Return pickup or final decision.",
                ]}
              />

              <CopyBlock
                label="Human support visibility"
                items={[
                  "Show agent name + SLA: “A human will reply within 24h.”",
                  "Offer callback: “Request a call (9 AM–6 PM)”",
                  "In-app chat for dispute only (keeps evidence).",
                ]}
              />

              <CopyBlock
                label="Status tracking"
                items={[
                  "Dispute status chip: Submitted → Reviewing → Waiting on seller → Proposed solution → Resolved.",
                  "Each status explains: “What happens now”.",
                ]}
              />
            </Section>

            {/* 8) MICROCOPY & TRUST LANGUAGE */}
            <Section title="8) MICROCOPY & TRUST LANGUAGE">
              <div className="grid md:grid-cols-2 gap-4">
                <CopyBlock
                  label="Button text (trust-first)"
                  items={[
                    "Instead of “Buy Now” → “Buy with protection”",
                    "Instead of “Pay” → “Pay securely (held until confirmed)”",
                    "“Confirm delivery & release payment”",
                    "“Report an issue” (always, never hidden)",
                    "“View seller verification”",
                  ]}
                />
                <CopyBlock
                  label="Warnings (clear, calm, non-accusatory)"
                  items={[
                    "“Please confirm size and quantity. Most issues happen here.”",
                    "“If anything is wrong, don’t worry — report it from your order.”",
                    "“Avoid paying outside BazaarCo. Off-platform payments aren’t protected.”",
                  ]}
                />
              </div>

              <div className="rounded-xl border border-gray-200 bg-white p-4">
                <div className="text-sm font-semibold text-gray-900 mb-2">Reassurance message library (drop-in snippets)</div>
                <ul className="space-y-2">
                  <li className="flex gap-2"><HandHeart size={18} className="text-red-700" /> “We hold your payment until you confirm — that’s how we prevent scams.”</li>
                  <li className="flex gap-2"><Truck size={18} className="text-blue-700" /> “Clear ETA, clear accountability. Seller must dispatch on time.”</li>
                  <li className="flex gap-2"><AlertTriangle size={18} className="text-amber-700" /> “See something off? Tap Report — it pauses payout immediately.”</li>
                  <li className="flex gap-2"><Headphones size={18} className="text-gray-900" /> “Human support, not bots. You’ll see who is handling your case.”</li>
                </ul>
              </div>
            </Section>
          </div>
        </div>
      </div>
    </div>
  );
}
