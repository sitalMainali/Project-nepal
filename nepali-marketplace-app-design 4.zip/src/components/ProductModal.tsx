import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Product } from '@/data/products';
import { X, Heart, Shield, MapPin, Calendar, Award, Truck, ShoppingCart, Zap } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { StarRating } from '@/components/ui/StarRating';
import { useApp } from '@/context/AppContext';

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
}

export function ProductModal({ product, onClose }: ProductModalProps) {
  const { addToCart, toggleWishlist, isInWishlist } = useApp();
  const [quantity, setQuantity] = useState(1);

  if (!product) return null;

  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  const inWishlist = isInWishlist(product.id);

  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  const handleAddToCart = () => {
    addToCart(product, quantity);
    onClose();
  };

  const handleBuyNow = () => {
    addToCart(product, quantity);
    onClose();
    window.location.href = '/checkout';
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={handleBackdropClick}
    >
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl animate-in slide-in-from-bottom duration-300">
        <div className="sticky top-0 bg-white border-b border-gray-100 p-4 flex items-center justify-between z-10">
          <h2 className="text-xl font-bold text-gray-800">Product Details</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        <div className="grid md:grid-cols-2 gap-6 p-6">
          {/* Image */}
          <div>
            <div className="aspect-square rounded-xl overflow-hidden bg-gray-100">
              <img 
                src={product.image} 
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex gap-2 mt-4 flex-wrap">
              {product.isNew && <Badge variant="success">New</Badge>}
              {product.isSecondHand && <Badge variant="warning">Grade {product.conditionGrade}</Badge>}
              {product.isFeatured && <Badge variant="nepal">Featured</Badge>}
              {discount > 0 && <Badge variant="danger">-{discount}% OFF</Badge>}
            </div>
          </div>

          {/* Details */}
          <div className="space-y-4">
            <div>
              <h3 className="text-2xl font-bold text-gray-800 mb-2">{product.name}</h3>
              <p className="text-gray-600">{product.description}</p>
            </div>

            {/* Price */}
            <div className="bg-gray-50 rounded-xl p-4">
              <div className="flex items-baseline gap-3">
                <span className="text-3xl font-bold text-red-600">
                  Rs. {product.price.toLocaleString()}
                </span>
                {product.originalPrice && (
                  <span className="text-lg text-gray-400 line-through">
                    Rs. {product.originalPrice.toLocaleString()}
                  </span>
                )}
                {discount > 0 && (
                  <Badge variant="danger" className="text-sm">
                    Save {discount}%
                  </Badge>
                )}
              </div>
            </div>

            {/* Seller Info */}
            <div className="border border-gray-200 rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold text-gray-800">{product.seller}</p>
                  <p className="text-sm text-gray-500 flex items-center gap-1">
                    <MapPin size={14} />
                    {product.location}
                  </p>
                </div>
                {product.isVerified && (
                  <Badge variant="success" className="flex items-center gap-1">
                    <Shield size={12} />
                    Verified
                  </Badge>
                )}
              </div>

              {product.rating && (
                <div className="flex items-center gap-2">
                  <StarRating rating={product.rating} size={16} />
                  <span className="text-sm text-gray-600">
                    {product.rating} ({product.reviewCount} reviews)
                  </span>
                </div>
              )}
            </div>

            {/* Additional Info */}
            <div className="grid grid-cols-2 gap-3">
              {product.warranty && (
                <div className="flex items-center gap-2 text-sm text-gray-600 bg-gray-50 p-2 rounded-lg">
                  <Shield size={16} className="text-green-600" />
                  {product.warranty} Warranty
                </div>
              )}
              {product.stock !== undefined && (
                <div className="flex items-center gap-2 text-sm text-gray-600 bg-gray-50 p-2 rounded-lg">
                  <Truck size={16} className="text-blue-600" />
                  {product.stock > 0 ? `${product.stock} in stock` : 'Out of stock'}
                </div>
              )}
              {product.createdAt && (
                <div className="flex items-center gap-2 text-sm text-gray-600 bg-gray-50 p-2 rounded-lg">
                  <Calendar size={16} className="text-purple-600" />
                  Listed {new Date(product.createdAt).toLocaleDateString()}
                </div>
              )}
              {product.isSecondHand && (
                <div className="flex items-center gap-2 text-sm text-gray-600 bg-gray-50 p-2 rounded-lg">
                  <Award size={16} className="text-amber-600" />
                  Pre-owned
                </div>
              )}
            </div>

            {/* Quantity */}
            <div className="flex items-center gap-4">
              <span className="text-sm font-medium text-gray-700">Quantity:</span>
              <div className="flex items-center border border-gray-300 rounded-lg">
                <button 
                  onClick={() => setQuantity(q => Math.max(1, q - 1))}
                  className="px-3 py-1 hover:bg-gray-100"
                  disabled={quantity <= 1}
                >
                  -
                </button>
                <span className="px-4 py-1 border-x border-gray-300">{quantity}</span>
                <button 
                  onClick={() => setQuantity(q => Math.min(product.stock || 10, q + 1))}
                  className="px-3 py-1 hover:bg-gray-100"
                  disabled={quantity >= (product.stock || 10)}
                >
                  +
                </button>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-3 pt-2">
              <Button onClick={handleAddToCart} variant="outline" className="flex-1" size="lg">
                <ShoppingCart size={18} className="mr-2" />
                Add to Cart
              </Button>
              <Button onClick={handleBuyNow} className="flex-1" size="lg">
                <Zap size={18} className="mr-2" />
                Buy Now
              </Button>
              <Button 
                variant="ghost" 
                size="lg" 
                className={`px-4 ${inWishlist ? 'text-red-500' : ''}`}
                onClick={() => toggleWishlist(product.id)}
              >
                <Heart size={20} fill={inWishlist ? 'currentColor' : 'none'} />
              </Button>
            </div>

            {/* View Full Page Link */}
            <Link 
              to={`/product/${product.id}`}
              onClick={onClose}
              className="block text-center text-red-600 hover:text-red-700 font-medium text-sm"
            >
              View full product page →
            </Link>

            {/* Trust Note */}
            <div className="bg-gradient-to-r from-red-50 to-blue-50 rounded-xl p-4 text-sm">
              <p className="font-semibold text-gray-800 mb-1">🔒 Secure Transaction</p>
              <p className="text-gray-600">
                Your payment is protected. We only release funds to the seller after you confirm receipt.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
