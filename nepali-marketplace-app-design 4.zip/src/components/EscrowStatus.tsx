import { useState } from 'react';
import {
  Shield, CheckCircle2, Clock, AlertTriangle, DollarSign, Lock, Unlock, XCircle
} from 'lucide-react';
import { EscrowService, type EscrowTransaction } from '@/services/api';
import { useApp } from '@/context/AppContext';

interface EscrowStatusProps {
  orderId: string;
  amount: number;
  buyerId: string;
  sellerId: string;
  isSecondHand?: boolean;
}

export function EscrowStatus({ orderId, amount, buyerId, sellerId, isSecondHand }: EscrowStatusProps) {
  const { addNotification } = useApp();

  // Get or create escrow
  const [escrow, setEscrow] = useState<EscrowTransaction>(() => {
    const existing = EscrowService.getByOrder(orderId);
    if (existing) return existing;
    return EscrowService.create(orderId, buyerId, sellerId, amount);
  });

  const [confirming, setConfirming] = useState(false);

  const handleConfirm = async () => {
    setConfirming(true);
    await new Promise(r => setTimeout(r, 1000));
    const updated = EscrowService.buyerConfirm(escrow.id);
    if (updated) {
      setEscrow(updated);
      addNotification('success', 'Payment Released', 'You confirmed receipt. Seller payment has been released.');
    }
    setConfirming(false);
  };

  const handleDispute = () => {
    const updated = EscrowService.dispute(escrow.id);
    if (updated) {
      setEscrow(updated);
      addNotification('warning', 'Dispute Filed', 'Payment is paused while we review your dispute.');
    }
  };

  const steps = [
    { key: 'held', label: 'Payment Held', desc: 'Funds secured by BazaarCo', icon: Lock },
    { key: 'delivered', label: 'Item Delivered', desc: 'Inspect your item', icon: CheckCircle2 },
    { key: 'confirmed', label: 'Buyer Confirms', desc: 'Confirm item matches', icon: Shield },
    { key: 'released', label: 'Seller Paid', desc: 'Funds released to seller', icon: Unlock },
  ];

  const getActiveStep = () => {
    if (escrow.status === 'released') return 4;
    if (escrow.status === 'refunded') return -1;
    if (escrow.status === 'disputed') return -2;
    if (escrow.buyerConfirmed) return 3;
    return 1;
  };

  const activeStep = getActiveStep();
  const autoReleaseDate = new Date(escrow.autoReleaseDate);
  const hoursLeft = Math.max(0, Math.floor((autoReleaseDate.getTime() - Date.now()) / (1000 * 60 * 60)));

  if (escrow.status === 'disputed') {
    return (
      <div className="bg-red-50 border border-red-200 rounded-xl p-5">
        <div className="flex items-center gap-3 mb-3">
          <AlertTriangle className="w-6 h-6 text-red-600" />
          <h3 className="font-semibold text-red-900">Dispute in Progress</h3>
        </div>
        <p className="text-sm text-red-800 mb-3">
          Payment of <strong>Rs. {amount.toLocaleString()}</strong> is paused. Our team is reviewing your dispute.
          A human support agent will respond within 24 hours.
        </p>
        <div className="bg-white rounded-lg p-3 text-sm">
          <div className="flex items-center gap-2 text-red-700">
            <Clock size={14} />
            <span>Expected resolution: 2-3 business days</span>
          </div>
        </div>
      </div>
    );
  }

  if (escrow.status === 'refunded') {
    return (
      <div className="bg-green-50 border border-green-200 rounded-xl p-5">
        <div className="flex items-center gap-3 mb-2">
          <CheckCircle2 className="w-6 h-6 text-green-600" />
          <h3 className="font-semibold text-green-900">Refund Completed</h3>
        </div>
        <p className="text-sm text-green-800">
          Rs. {amount.toLocaleString()} has been refunded to your account.
        </p>
      </div>
    );
  }

  return (
    <div className={`border rounded-xl p-5 ${isSecondHand ? 'bg-amber-50 border-amber-200' : 'bg-blue-50 border-blue-200'}`}>
      {/* Header */}
      <div className="flex items-center gap-3 mb-4">
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${isSecondHand ? 'bg-amber-100' : 'bg-blue-100'}`}>
          <DollarSign className={`w-5 h-5 ${isSecondHand ? 'text-amber-600' : 'text-blue-600'}`} />
        </div>
        <div>
          <h3 className={`font-semibold ${isSecondHand ? 'text-amber-900' : 'text-blue-900'}`}>
            {isSecondHand ? 'Escrow Protection (Second-Hand)' : 'Payment Protection'}
          </h3>
          <p className={`text-sm ${isSecondHand ? 'text-amber-700' : 'text-blue-700'}`}>
            Rs. {amount.toLocaleString()} {escrow.status === 'held' ? 'held securely' : 'released to seller'}
          </p>
        </div>
      </div>

      {/* Progress Steps */}
      <div className="flex items-center mb-4">
        {steps.map((step, i) => (
          <div key={step.key} className="flex-1 flex items-center">
            <div className="flex flex-col items-center flex-1">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-1 ${
                i < activeStep
                  ? 'bg-green-500 text-white'
                  : i === activeStep
                    ? `${isSecondHand ? 'bg-amber-500' : 'bg-blue-500'} text-white animate-pulse`
                    : 'bg-gray-200 text-gray-400'
              }`}>
                {i < activeStep ? <CheckCircle2 size={16} /> : <step.icon size={16} />}
              </div>
              <p className={`text-xs text-center ${i <= activeStep ? 'text-gray-900 font-medium' : 'text-gray-400'}`}>
                {step.label}
              </p>
            </div>
            {i < steps.length - 1 && (
              <div className={`h-0.5 w-full ${i < activeStep ? 'bg-green-500' : 'bg-gray-200'}`} />
            )}
          </div>
        ))}
      </div>

      {/* Auto-release notice */}
      {escrow.status === 'held' && (
        <div className={`rounded-lg p-3 mb-4 text-sm ${isSecondHand ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'}`}>
          <div className="flex items-center gap-2">
            <Clock size={14} />
            <span>
              {hoursLeft > 0
                ? `Auto-release in ${hoursLeft} hours if no action taken.`
                : 'Auto-release period has ended.'}
              {' '}Confirm or report an issue.
            </span>
          </div>
        </div>
      )}

      {/* Action Buttons */}
      {escrow.status === 'held' && (
        <div className="flex gap-3">
          <button
            onClick={handleConfirm}
            disabled={confirming}
            className="flex-1 bg-green-600 text-white py-2.5 rounded-lg font-medium hover:bg-green-700 flex items-center justify-center gap-2 disabled:opacity-70"
          >
            {confirming ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <CheckCircle2 size={16} />
            )}
            {confirming ? 'Confirming...' : 'Confirm — Item matches photos'}
          </button>
          <button
            onClick={handleDispute}
            className="px-4 py-2.5 bg-red-100 text-red-700 rounded-lg font-medium hover:bg-red-200 flex items-center gap-2"
          >
            <XCircle size={16} />
            Report Mismatch
          </button>
        </div>
      )}

      {/* Released state */}
      {escrow.status === 'released' && (
        <div className="bg-green-100 rounded-lg p-3 text-sm text-green-800 flex items-center gap-2">
          <CheckCircle2 size={16} className="text-green-600" />
          <span>Payment released to seller on {new Date(escrow.releasedAt || '').toLocaleDateString()}</span>
        </div>
      )}

      {/* Trust note */}
      <p className={`text-xs mt-3 ${isSecondHand ? 'text-amber-600' : 'text-blue-600'}`}>
        <Shield size={12} className="inline mr-1" />
        {isSecondHand
          ? 'Seller payout is paused until you confirm. That\'s the point.'
          : 'Your payment is protected. We only release funds after you confirm.'}
      </p>
    </div>
  );
}
