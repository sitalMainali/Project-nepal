import { Link } from 'react-router-dom';
import { Product } from '@/data/products';
import { Card, CardContent } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { StarRating } from '@/components/ui/StarRating';
import { Heart, Shield, Zap, ShoppingCart } from 'lucide-react';
import { useApp } from '@/context/AppContext';

interface ProductCardProps {
  product: Product;
  onProductClick?: (product: Product) => void;
}

export function ProductCard({ product, onProductClick }: ProductCardProps) {
  const { addToCart, toggleWishlist, isInWishlist } = useApp();
  
  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  const inWishlist = isInWishlist(product.id);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product, 1);
  };

  const handleWishlistToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    toggleWishlist(product.id);
  };

  const handleClick = () => {
    if (onProductClick) {
      onProductClick(product);
    }
  };

  return (
    <Card 
      variant="hover" 
      className="cursor-pointer overflow-hidden group"
      onClick={handleClick}
    >
      <Link to={`/product/${product.id}`}>
        <div className="relative">
          {/* Image */}
          <div className="aspect-square overflow-hidden bg-gray-100">
            <img 
              src={product.image} 
              alt={product.name}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              loading="lazy"
            />
          </div>

          {/* Badges */}
          <div className="absolute top-2 left-2 flex flex-col gap-1">
            {product.isFeatured && (
              <Badge variant="nepal" className="shadow-md">
                <Zap size={12} className="mr-1" /> Featured
              </Badge>
            )}
            {product.isNew && (
              <Badge variant="success">New</Badge>
            )}
            {product.isSecondHand && product.conditionGrade && (
              <Badge variant="warning">Grade {product.conditionGrade}</Badge>
            )}
            {discount > 0 && (
              <Badge variant="danger">-{discount}%</Badge>
            )}
          </div>

          {/* Wishlist */}
          <button 
            className={`absolute top-2 right-2 p-2 rounded-full shadow-md transition-all ${
              inWishlist 
                ? 'bg-red-500 text-white' 
                : 'bg-white text-gray-400 hover:text-red-500'
            }`}
            onClick={handleWishlistToggle}
            aria-label={inWishlist ? 'Remove from wishlist' : 'Add to wishlist'}
          >
            <Heart size={16} fill={inWishlist ? 'currentColor' : 'none'} />
          </button>

          {/* Quick Add to Cart - shows on hover */}
          <button
            className="absolute bottom-2 right-2 p-2 bg-red-600 text-white rounded-full shadow-md opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-700"
            onClick={handleAddToCart}
            aria-label="Add to cart"
          >
            <ShoppingCart size={16} />
          </button>
        </div>

        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-2">
            {product.isVerified && (
              <div className="flex items-center gap-1 text-green-600 text-xs font-medium">
                <Shield size={12} />
                Verified
              </div>
            )}
            {product.seller && (
              <span className="text-xs text-gray-500 truncate">by {product.seller}</span>
            )}
          </div>

          <h3 className="font-semibold text-gray-800 line-clamp-2 mb-2 min-h-[2.5rem] group-hover:text-red-600 transition-colors">
            {product.name}
          </h3>

          {product.rating && (
            <div className="flex items-center gap-2 mb-2">
              <StarRating 
                rating={product.rating} 
                size={14}
                showCount={true}
                reviewCount={product.reviewCount}
              />
            </div>
          )}

          <div className="flex items-center gap-2 mb-2">
            <span className="text-xl font-bold text-red-600">
              Rs. {product.price.toLocaleString()}
            </span>
            {product.originalPrice && (
              <span className="text-sm text-gray-400 line-through">
                Rs. {product.originalPrice.toLocaleString()}
              </span>
            )}
          </div>

          <div className="flex items-center justify-between text-xs text-gray-500">
            <span>{product.location}</span>
            {product.stock !== undefined && product.stock < 10 && product.stock > 0 && (
              <span className="text-red-600 font-medium">Only {product.stock} left!</span>
            )}
            {product.stock === 0 && (
              <span className="text-gray-600 font-medium">Out of stock</span>
            )}
          </div>

          {product.freeDelivery && (
            <div className="mt-2 text-xs text-green-600 font-medium">
              Free Delivery
            </div>
          )}

          {product.warranty && (
            <div className="mt-1 text-xs text-gray-600 flex items-center gap-1">
              <Shield size={12} className="text-green-600" />
              {product.warranty} warranty
            </div>
          )}
        </CardContent>
      </Link>
    </Card>
  );
}
