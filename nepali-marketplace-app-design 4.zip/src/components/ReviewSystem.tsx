import { useState, useRef } from 'react';
import {
  Star, ThumbsUp, Camera, X, CheckCircle2, Shield, AlertCircle, ChevronDown, ChevronUp, MessageCircle, Send
} from 'lucide-react';
import { ReviewService, ImageService, type Review } from '@/services/api';
import { useApp } from '@/context/AppContext';

interface ReviewSystemProps {
  productId: string;
  productName: string;
  sellerId?: string;
}

export function ReviewSystem({ productId, productName }: ReviewSystemProps) {
  const { state, addNotification } = useApp();
  const user = state.user;
  const [reviews, setReviews] = useState<Review[]>(() => ReviewService.getByProduct(productId));
  const stats = ReviewService.getStats(productId);

  const [showForm, setShowForm] = useState(false);
  const [sortBy, setSortBy] = useState<'recent' | 'helpful'>('recent');
  const [filterStar, setFilterStar] = useState<number | null>(null);
  const [expandedReply, setExpandedReply] = useState<string | null>(null);

  // Form state
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [title, setTitle] = useState('');
  const [comment, setComment] = useState('');
  const [photos, setPhotos] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const sortedReviews = [...reviews]
    .filter(r => !filterStar || r.rating === filterStar)
    .sort((a, b) => sortBy === 'helpful' ? b.helpful - a.helpful : new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (photos.length + files.length > 5) {
      addNotification('warning', 'Too many photos', 'Maximum 5 photos allowed per review.');
      return;
    }
    for (const file of files) {
      const validation = ImageService.validate(file);
      if (!validation.valid) {
        addNotification('error', 'Invalid Image', validation.error || 'Invalid file.');
        continue;
      }
      const result = await ImageService.upload(file);
      setPhotos(prev => [...prev, result.url]);
    }
    if (fileRef.current) fileRef.current.value = '';
  };

  const handleSubmit = async () => {
    if (!user) { addNotification('error', 'Login Required', 'Please login to leave a review.'); return; }
    if (rating === 0) { addNotification('warning', 'Rating Required', 'Please select a star rating.'); return; }
    if (!comment.trim()) { addNotification('warning', 'Comment Required', 'Please write your review.'); return; }

    setIsSubmitting(true);
    await new Promise(r => setTimeout(r, 800));

    const newReview = ReviewService.add({
      productId,
      userId: user.id,
      userName: user.name,
      rating,
      title: title.trim() || `${rating}-star review`,
      comment: comment.trim(),
      photos,
    });

    setReviews(prev => [newReview, ...prev]);
    setRating(0); setTitle(''); setComment(''); setPhotos([]);
    setShowForm(false);
    setIsSubmitting(false);
    addNotification('success', 'Review Posted', 'Thank you for your review! It helps other buyers shop with confidence.');
  };

  const handleHelpful = (reviewId: string) => {
    ReviewService.markHelpful(reviewId);
    setReviews(prev => prev.map(r => r.id === reviewId ? { ...r, helpful: r.helpful + 1 } : r));
  };

  const formatDate = (d: string) => new Date(d).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });

  return (
    <div>
      {/* Stats Summary */}
      <div className="flex flex-col md:flex-row gap-6 mb-8">
        <div className="text-center md:text-left">
          <div className="text-5xl font-bold text-gray-900">{stats.avg || '—'}</div>
          <div className="flex items-center justify-center md:justify-start gap-1 mt-1">
            {[1, 2, 3, 4, 5].map(s => (
              <Star key={s} size={18} fill={s <= Math.round(stats.avg) ? '#f59e0b' : 'none'} className={s <= Math.round(stats.avg) ? 'text-amber-500' : 'text-gray-300'} />
            ))}
          </div>
          <p className="text-sm text-gray-600 mt-1">{stats.count} review{stats.count !== 1 ? 's' : ''}</p>
        </div>
        <div className="flex-1 space-y-1.5">
          {[5, 4, 3, 2, 1].map((star, i) => {
            const count = stats.distribution[i] || 0;
            const pct = stats.count ? (count / stats.count) * 100 : 0;
            return (
              <button key={star} onClick={() => setFilterStar(filterStar === star ? null : star)}
                className={`flex items-center gap-2 w-full group ${filterStar === star ? 'opacity-100' : 'opacity-70 hover:opacity-100'}`}>
                <span className="text-sm text-gray-600 w-8">{star}★</span>
                <div className="flex-1 h-2.5 bg-gray-200 rounded-full overflow-hidden">
                  <div className="h-full bg-amber-500 rounded-full transition-all" style={{ width: `${pct}%` }} />
                </div>
                <span className="text-xs text-gray-500 w-8 text-right">{count}</span>
              </button>
            );
          })}
        </div>
        <div className="flex flex-col gap-2 items-center md:items-end">
          <button
            onClick={() => setShowForm(!showForm)}
            className="bg-red-600 text-white px-6 py-2.5 rounded-lg font-semibold hover:bg-red-700 transition-colors flex items-center gap-2"
          >
            <Star size={16} /> Write a Review
          </button>
          {filterStar && (
            <button onClick={() => setFilterStar(null)} className="text-sm text-red-600 hover:underline">
              Clear filter ×
            </button>
          )}
        </div>
      </div>

      {/* Write Review Form */}
      {showForm && (
        <div className="bg-gray-50 border border-gray-200 rounded-xl p-6 mb-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Write Your Review</h3>
          {!user && (
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-4 flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-amber-600" />
              <span className="text-sm text-amber-800">Please <a href="/login" className="font-semibold underline">login</a> to write a review.</span>
            </div>
          )}
          {/* Star Rating */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">Your Rating *</label>
            <div className="flex items-center gap-1">
              {[1, 2, 3, 4, 5].map(s => (
                <button key={s}
                  onMouseEnter={() => setHoverRating(s)}
                  onMouseLeave={() => setHoverRating(0)}
                  onClick={() => setRating(s)}
                  className="p-1 transition-transform hover:scale-110"
                >
                  <Star size={28} fill={(hoverRating || rating) >= s ? '#f59e0b' : 'none'} className={(hoverRating || rating) >= s ? 'text-amber-500' : 'text-gray-300'} />
                </button>
              ))}
              {rating > 0 && (
                <span className="ml-3 text-sm text-gray-600">
                  {['', 'Poor', 'Fair', 'Good', 'Very Good', 'Excellent'][rating]}
                </span>
              )}
            </div>
          </div>
          {/* Title */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">Review Title</label>
            <input type="text" value={title} onChange={e => setTitle(e.target.value)} maxLength={100}
              className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              placeholder="Summarize your experience" />
          </div>
          {/* Comment */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">Your Review *</label>
            <textarea value={comment} onChange={e => setComment(e.target.value)} rows={4} maxLength={1000}
              className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              placeholder={`Share your experience with "${productName}". Was it as described? How was the quality?`} />
            <p className="text-xs text-gray-400 mt-1">{comment.length}/1000</p>
          </div>
          {/* Photo Upload */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">Add Photos (optional, max 5)</label>
            <div className="flex flex-wrap gap-3">
              {photos.map((photo, i) => (
                <div key={i} className="relative w-20 h-20 rounded-lg overflow-hidden border border-gray-200">
                  <img src={photo} alt="" className="w-full h-full object-cover" />
                  <button onClick={() => setPhotos(prev => prev.filter((_, idx) => idx !== i))}
                    className="absolute top-0.5 right-0.5 p-0.5 bg-red-600 text-white rounded-full">
                    <X size={12} />
                  </button>
                </div>
              ))}
              {photos.length < 5 && (
                <button onClick={() => fileRef.current?.click()}
                  className="w-20 h-20 border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center text-gray-400 hover:border-red-400 hover:text-red-500 transition-colors">
                  <Camera size={20} />
                  <span className="text-xs mt-1">Photo</span>
                </button>
              )}
            </div>
            <input ref={fileRef} type="file" accept="image/*" multiple onChange={handlePhotoUpload} className="hidden" />
          </div>
          <div className="flex gap-3 justify-end">
            <button onClick={() => setShowForm(false)} className="px-5 py-2.5 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200">Cancel</button>
            <button onClick={handleSubmit} disabled={isSubmitting || !rating || !comment.trim()}
              className="px-5 py-2.5 bg-red-600 text-white rounded-lg font-medium hover:bg-red-700 disabled:opacity-50 flex items-center gap-2">
              {isSubmitting ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <Send size={16} />}
              {isSubmitting ? 'Posting...' : 'Post Review'}
            </button>
          </div>
        </div>
      )}

      {/* Sort Controls */}
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm text-gray-600">
          {filterStar ? `Showing ${sortedReviews.length} ${filterStar}-star reviews` : `${sortedReviews.length} reviews`}
        </p>
        <select value={sortBy} onChange={e => setSortBy(e.target.value as 'recent' | 'helpful')}
          className="text-sm border border-gray-300 rounded-lg px-3 py-1.5">
          <option value="recent">Most Recent</option>
          <option value="helpful">Most Helpful</option>
        </select>
      </div>

      {/* Review List */}
      <div className="space-y-4">
        {sortedReviews.length === 0 && (
          <div className="text-center py-12">
            <Star className="w-12 h-12 mx-auto text-gray-300 mb-3" />
            <p className="text-gray-600 font-medium">No reviews yet</p>
            <p className="text-sm text-gray-500 mt-1">Be the first to review this product!</p>
          </div>
        )}
        {sortedReviews.map(review => (
          <div key={review.id} className="border border-gray-100 rounded-xl p-5 bg-white">
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center font-semibold text-gray-600">
                  {review.userName.charAt(0)}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-gray-900">{review.userName}</span>
                    {review.verified && (
                      <span className="flex items-center gap-0.5 text-xs text-green-700 bg-green-100 px-2 py-0.5 rounded-full">
                        <CheckCircle2 size={10} /> Verified Purchase
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-gray-500">{formatDate(review.createdAt)}</p>
                </div>
              </div>
              <div className="flex items-center gap-0.5">
                {[1, 2, 3, 4, 5].map(s => (
                  <Star key={s} size={14} fill={s <= review.rating ? '#f59e0b' : 'none'} className={s <= review.rating ? 'text-amber-500' : 'text-gray-300'} />
                ))}
              </div>
            </div>
            {review.title && <h4 className="font-semibold text-gray-900 mt-3">{review.title}</h4>}
            <p className="text-gray-700 mt-2 text-sm leading-relaxed">{review.comment}</p>
            {review.photos.length > 0 && (
              <div className="flex gap-2 mt-3">
                {review.photos.map((p, i) => (
                  <img key={i} src={p} alt="" className="w-16 h-16 rounded-lg object-cover border border-gray-200" />
                ))}
              </div>
            )}
            {/* Actions */}
            <div className="flex items-center gap-4 mt-4 pt-3 border-t border-gray-100">
              <button onClick={() => handleHelpful(review.id)}
                className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-blue-600 transition-colors">
                <ThumbsUp size={14} /> Helpful ({review.helpful})
              </button>
              {review.sellerReply && (
                <button onClick={() => setExpandedReply(expandedReply === review.id ? null : review.id)}
                  className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-700">
                  <MessageCircle size={14} /> Seller Reply
                  {expandedReply === review.id ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                </button>
              )}
            </div>
            {/* Seller Reply */}
            {review.sellerReply && expandedReply === review.id && (
              <div className="mt-3 ml-6 bg-blue-50 border border-blue-100 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Shield size={14} className="text-blue-600" />
                  <span className="text-sm font-medium text-blue-900">Seller Response</span>
                  {review.sellerReplyDate && <span className="text-xs text-blue-600">{formatDate(review.sellerReplyDate)}</span>}
                </div>
                <p className="text-sm text-blue-800">{review.sellerReply}</p>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
