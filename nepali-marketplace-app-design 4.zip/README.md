# BazaarCo — Shop without fear

A comprehensive marketplace application combining features from Daraz (new products) and Hamro Bazar (second-hand items), focused on trust with the core promise: “Shop without fear.”

## Core Positioning

BazaarCo’s main promise is: **Shop without fear**.

We tackle Nepal’s biggest e‑commerce pain: **lack of trust** (scams, misleading images, wrong sizes/quantities, fake sellers, damaged deliveries, and weak dispute handling).

## Features

### 🛍️ New Market (Daraz-style)
- **New Products**: Electronics, Fashion, Home & Kitchen, Beauty & Health, Books, Sports
- **Featured Products**: Highlighted items with special badges
- **Verified Sellers**: Trust indicators for legitimate sellers
- **Warranty Information**: Product warranty details
- **Discounts & Deals**: Percentage off badges and price comparisons

### 🔄 Second Hand (Hamro Bazar-style)
- **Pre-owned Items**: Vehicles, Electronics, Furniture, Mobile Phones, Clothes, Books
- **Condition Indicators**: Like-new, Good, Fair condition badges
- **Local Listings**: Find items in your area
- **Trusted Sellers**: Identity verification system

### 🏔️ Nepalese Theme
- **Flag Colors**: Red (#DC143C), Blue (#003893), Green (#006600)
- **Cultural Elements**: Dhaka topi, cashmere, traditional crafts
- **Modern UI**: Clean, responsive design with smooth animations
- **Trust Signals**: Security badges, verified seller indicators

### 🔒 Trust & Security
- **Secure Transactions**: Escrow protection system
- **Verified Sellers**: Identity verification badges
- **Quality Guarantee**: Return policy and warranty
- **Trust Badges**: Visual indicators for safety features

## Tech Stack

- **React 19**: Modern React with hooks
- **TypeScript**: Type-safe development
- **Tailwind CSS**: Utility-first styling
- **Vite**: Fast build tool
- **Lucide React**: Icon library

## Project Structure

```
src/
├── components/
│   ├── ui/
│   │   ├── Button.tsx
│   │   ├── Card.tsx
│   │   ├── Badge.tsx
│   │   └── StarRating.tsx
│   ├── Navbar.tsx
│   ├── HeroSection.tsx
│   ├── TrustBadge.tsx
│   ├── CategoryFilter.tsx
│   ├── ProductCard.tsx
│   ├── ProductModal.tsx
│   └── Footer.tsx
├── data/
│   └── products.ts
├── utils/
│   └── cn.ts
├── App.tsx
├── main.tsx
└── index.css
```

## Key Components

### Product Cards
- Hover effects with smooth animations
- Badges for New, Featured, Condition, Discount
- Star ratings with review counts
- Stock level indicators
- Verified seller badges

### Product Modal
- Full product details
- Seller information
- Price comparison
- Warranty and stock info
- Action buttons (Add to Cart, Buy Now, Wishlist)

### Hero Section
- Mode toggle (New Market / Second Hand)
- Search functionality
- Feature highlights
- Nepalese flag gradient background

## Usage

### Installation
```bash
npm install
```

### Development
```bash
npm run dev
```

### Build
```bash
npm run build
```

## Design Philosophy

### Color Scheme
- **Primary Red**: Represents Nepal's national pride
- **Trust Blue**: Symbolizes reliability and security
- **Saffron/Green**: From the Nepalese flag
- **Clean Whites**: Modern, trustworthy aesthetic

### User Experience
- **Mobile-First**: Responsive design for all devices
- **Fast Loading**: Single-page application with instant navigation
- **Intuitive Filters**: Easy category and search filtering
- **Visual Feedback**: Hover states, loading indicators, success messages

### Trust Building
- Clear verification badges
- Transparent seller information
- Secure transaction messaging
- Quality guarantees

## Future Enhancements

- [ ] User authentication and profiles
- [ ] Shopping cart and checkout
- [ ] Real-time chat between buyers and sellers
- [ ] Image upload for new listings
- [ ] Price negotiation system
- [ ] Delivery tracking
- [ ] Reviews and ratings system
- [ ] Wishlist functionality
- [ ] Price alerts
- [ ] Seller dashboard

## Browser Support

- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## License

MIT License - Feel free to use this project as a starting point for your own marketplace!
